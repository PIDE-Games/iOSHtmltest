gdjs.IntroCutsceneCode = {};
gdjs.IntroCutsceneCode.localVariables = [];
gdjs.IntroCutsceneCode.idToCallbackMap = new Map();
gdjs.IntroCutsceneCode.GDNewSpriteObjects1= [];
gdjs.IntroCutsceneCode.GDNewSpriteObjects2= [];
gdjs.IntroCutsceneCode.GDintroObjects1= [];
gdjs.IntroCutsceneCode.GDintroObjects2= [];
gdjs.IntroCutsceneCode.GDNewVideoObjects1= [];
gdjs.IntroCutsceneCode.GDNewVideoObjects2= [];
gdjs.IntroCutsceneCode.GDNewSprite2Objects1= [];
gdjs.IntroCutsceneCode.GDNewSprite2Objects2= [];
gdjs.IntroCutsceneCode.GDSkip_9595IntroObjects1= [];
gdjs.IntroCutsceneCode.GDSkip_9595IntroObjects2= [];


gdjs.IntroCutsceneCode.eventsList0 = function(runtimeScene) {

{

gdjs.copyArray(runtimeScene.getObjects("NewSprite"), gdjs.IntroCutsceneCode.GDNewSpriteObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.IntroCutsceneCode.GDNewSpriteObjects1.length;i<l;++i) {
    if ( gdjs.IntroCutsceneCode.GDNewSpriteObjects1[i].getBehavior("Animation").hasAnimationEnded() ) {
        isConditionTrue_0 = true;
        gdjs.IntroCutsceneCode.GDNewSpriteObjects1[k] = gdjs.IntroCutsceneCode.GDNewSpriteObjects1[i];
        ++k;
    }
}
gdjs.IntroCutsceneCode.GDNewSpriteObjects1.length = k;
if (isConditionTrue_0) {
{gdjs.evtTools.runtimeScene.replaceScene(runtimeScene, "Title screen", false);
}
}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.runtimeScene.sceneJustBegins(runtimeScene);
if (isConditionTrue_0) {
{gdjs.evtTools.sound.playMusicOnChannel(runtimeScene, "IntroShiro Kiddo.mp3", 1, true, 50, 1);
}
}

}


{

gdjs.copyArray(runtimeScene.getObjects("NewSprite"), gdjs.IntroCutsceneCode.GDNewSpriteObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.IntroCutsceneCode.GDNewSpriteObjects1.length;i<l;++i) {
    if ( gdjs.IntroCutsceneCode.GDNewSpriteObjects1[i].getAnimationFrame() == 5 ) {
        isConditionTrue_0 = true;
        gdjs.IntroCutsceneCode.GDNewSpriteObjects1[k] = gdjs.IntroCutsceneCode.GDNewSpriteObjects1[i];
        ++k;
    }
}
gdjs.IntroCutsceneCode.GDNewSpriteObjects1.length = k;
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("intro"), gdjs.IntroCutsceneCode.GDintroObjects1);
{for(var i = 0, len = gdjs.IntroCutsceneCode.GDintroObjects1.length ;i < len;++i) {
    gdjs.IntroCutsceneCode.GDintroObjects1[i].getBehavior("Text").setText("Where people stayed happily");
}
}
}

}


{

gdjs.copyArray(runtimeScene.getObjects("NewSprite"), gdjs.IntroCutsceneCode.GDNewSpriteObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.IntroCutsceneCode.GDNewSpriteObjects1.length;i<l;++i) {
    if ( gdjs.IntroCutsceneCode.GDNewSpriteObjects1[i].getAnimationFrame() == 15 ) {
        isConditionTrue_0 = true;
        gdjs.IntroCutsceneCode.GDNewSpriteObjects1[k] = gdjs.IntroCutsceneCode.GDNewSpriteObjects1[i];
        ++k;
    }
}
gdjs.IntroCutsceneCode.GDNewSpriteObjects1.length = k;
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("intro"), gdjs.IntroCutsceneCode.GDintroObjects1);
{for(var i = 0, len = gdjs.IntroCutsceneCode.GDintroObjects1.length ;i < len;++i) {
    gdjs.IntroCutsceneCode.GDintroObjects1[i].getBehavior("Text").setText("So, Shiro and Stacy Went to stay (These Tiny humans)");
}
}
}

}


{

gdjs.copyArray(runtimeScene.getObjects("NewSprite"), gdjs.IntroCutsceneCode.GDNewSpriteObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.IntroCutsceneCode.GDNewSpriteObjects1.length;i<l;++i) {
    if ( gdjs.IntroCutsceneCode.GDNewSpriteObjects1[i].getAnimationFrame() == 25 ) {
        isConditionTrue_0 = true;
        gdjs.IntroCutsceneCode.GDNewSpriteObjects1[k] = gdjs.IntroCutsceneCode.GDNewSpriteObjects1[i];
        ++k;
    }
}
gdjs.IntroCutsceneCode.GDNewSpriteObjects1.length = k;
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("intro"), gdjs.IntroCutsceneCode.GDintroObjects1);
{for(var i = 0, len = gdjs.IntroCutsceneCode.GDintroObjects1.length ;i < len;++i) {
    gdjs.IntroCutsceneCode.GDintroObjects1[i].getBehavior("Text").setText("Until, a not Welcoming creature entered,");
}
}
}

}


{

gdjs.copyArray(runtimeScene.getObjects("NewSprite"), gdjs.IntroCutsceneCode.GDNewSpriteObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.IntroCutsceneCode.GDNewSpriteObjects1.length;i<l;++i) {
    if ( gdjs.IntroCutsceneCode.GDNewSpriteObjects1[i].getAnimationFrame() == 35 ) {
        isConditionTrue_0 = true;
        gdjs.IntroCutsceneCode.GDNewSpriteObjects1[k] = gdjs.IntroCutsceneCode.GDNewSpriteObjects1[i];
        ++k;
    }
}
gdjs.IntroCutsceneCode.GDNewSpriteObjects1.length = k;
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("intro"), gdjs.IntroCutsceneCode.GDintroObjects1);
{for(var i = 0, len = gdjs.IntroCutsceneCode.GDintroObjects1.length ;i < len;++i) {
    gdjs.IntroCutsceneCode.GDintroObjects1[i].getBehavior("Text").setText("And kindnapped Stacy!(The Female Tiny human)");
}
}
}

}


{

gdjs.copyArray(runtimeScene.getObjects("NewSprite"), gdjs.IntroCutsceneCode.GDNewSpriteObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.IntroCutsceneCode.GDNewSpriteObjects1.length;i<l;++i) {
    if ( gdjs.IntroCutsceneCode.GDNewSpriteObjects1[i].getAnimationFrame() == 45 ) {
        isConditionTrue_0 = true;
        gdjs.IntroCutsceneCode.GDNewSpriteObjects1[k] = gdjs.IntroCutsceneCode.GDNewSpriteObjects1[i];
        ++k;
    }
}
gdjs.IntroCutsceneCode.GDNewSpriteObjects1.length = k;
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("intro"), gdjs.IntroCutsceneCode.GDintroObjects1);
{for(var i = 0, len = gdjs.IntroCutsceneCode.GDintroObjects1.length ;i < len;++i) {
    gdjs.IntroCutsceneCode.GDintroObjects1[i].getBehavior("Text").setText("Now Shiro the tiny human, has to rescue Stacy!!");
}
}
}

}


{


let isConditionTrue_0 = false;
{
}

}


{

gdjs.copyArray(runtimeScene.getObjects("NewSprite"), gdjs.IntroCutsceneCode.GDNewSpriteObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.IntroCutsceneCode.GDNewSpriteObjects1.length;i<l;++i) {
    if ( gdjs.IntroCutsceneCode.GDNewSpriteObjects1[i].getBehavior("Animation").getAnimationName() == "one" ) {
        isConditionTrue_0 = true;
        gdjs.IntroCutsceneCode.GDNewSpriteObjects1[k] = gdjs.IntroCutsceneCode.GDNewSpriteObjects1[i];
        ++k;
    }
}
gdjs.IntroCutsceneCode.GDNewSpriteObjects1.length = k;
if (isConditionTrue_0) {
/* Reuse gdjs.IntroCutsceneCode.GDNewSpriteObjects1 */
{for(var i = 0, len = gdjs.IntroCutsceneCode.GDNewSpriteObjects1.length ;i < len;++i) {
    gdjs.IntroCutsceneCode.GDNewSpriteObjects1[i].getBehavior("FlashOpacity").Flash("Tween", 50, 0, null);
}
}
}

}


{

gdjs.copyArray(runtimeScene.getObjects("Skip_Intro"), gdjs.IntroCutsceneCode.GDSkip_9595IntroObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.IntroCutsceneCode.GDSkip_9595IntroObjects1.length;i<l;++i) {
    if ( gdjs.IntroCutsceneCode.GDSkip_9595IntroObjects1[i].getBehavior("ButtonFSM").IsPressed(null) ) {
        isConditionTrue_0 = true;
        gdjs.IntroCutsceneCode.GDSkip_9595IntroObjects1[k] = gdjs.IntroCutsceneCode.GDSkip_9595IntroObjects1[i];
        ++k;
    }
}
gdjs.IntroCutsceneCode.GDSkip_9595IntroObjects1.length = k;
if (isConditionTrue_0) {
{gdjs.evtTools.runtimeScene.replaceScene(runtimeScene, "Title screen", false);
}
}

}


{

gdjs.copyArray(runtimeScene.getObjects("Skip_Intro"), gdjs.IntroCutsceneCode.GDSkip_9595IntroObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.IntroCutsceneCode.GDSkip_9595IntroObjects1.length;i<l;++i) {
    if ( gdjs.IntroCutsceneCode.GDSkip_9595IntroObjects1[i].getBehavior("ButtonFSM").IsFocused(null) ) {
        isConditionTrue_0 = true;
        gdjs.IntroCutsceneCode.GDSkip_9595IntroObjects1[k] = gdjs.IntroCutsceneCode.GDSkip_9595IntroObjects1[i];
        ++k;
    }
}
gdjs.IntroCutsceneCode.GDSkip_9595IntroObjects1.length = k;
if (isConditionTrue_0) {
/* Reuse gdjs.IntroCutsceneCode.GDSkip_9595IntroObjects1 */
{for(var i = 0, len = gdjs.IntroCutsceneCode.GDSkip_9595IntroObjects1.length ;i < len;++i) {
    gdjs.IntroCutsceneCode.GDSkip_9595IntroObjects1[i].getBehavior("ButtonAnimationName").SetIdleAnimationName("Skip", null);
}
}
}

}


{

gdjs.copyArray(runtimeScene.getObjects("Skip_Intro"), gdjs.IntroCutsceneCode.GDSkip_9595IntroObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.IntroCutsceneCode.GDSkip_9595IntroObjects1.length;i<l;++i) {
    if ( gdjs.IntroCutsceneCode.GDSkip_9595IntroObjects1[i].getBehavior("ButtonFSM").IsHovered(null) ) {
        isConditionTrue_0 = true;
        gdjs.IntroCutsceneCode.GDSkip_9595IntroObjects1[k] = gdjs.IntroCutsceneCode.GDSkip_9595IntroObjects1[i];
        ++k;
    }
}
gdjs.IntroCutsceneCode.GDSkip_9595IntroObjects1.length = k;
if (isConditionTrue_0) {
/* Reuse gdjs.IntroCutsceneCode.GDSkip_9595IntroObjects1 */
{for(var i = 0, len = gdjs.IntroCutsceneCode.GDSkip_9595IntroObjects1.length ;i < len;++i) {
    gdjs.IntroCutsceneCode.GDSkip_9595IntroObjects1[i].getBehavior("Animation").setAnimationName("Press");
}
}
}

}


};

gdjs.IntroCutsceneCode.func = function(runtimeScene) {
runtimeScene.getOnceTriggers().startNewFrame();

gdjs.IntroCutsceneCode.GDNewSpriteObjects1.length = 0;
gdjs.IntroCutsceneCode.GDNewSpriteObjects2.length = 0;
gdjs.IntroCutsceneCode.GDintroObjects1.length = 0;
gdjs.IntroCutsceneCode.GDintroObjects2.length = 0;
gdjs.IntroCutsceneCode.GDNewVideoObjects1.length = 0;
gdjs.IntroCutsceneCode.GDNewVideoObjects2.length = 0;
gdjs.IntroCutsceneCode.GDNewSprite2Objects1.length = 0;
gdjs.IntroCutsceneCode.GDNewSprite2Objects2.length = 0;
gdjs.IntroCutsceneCode.GDSkip_9595IntroObjects1.length = 0;
gdjs.IntroCutsceneCode.GDSkip_9595IntroObjects2.length = 0;

gdjs.IntroCutsceneCode.eventsList0(runtimeScene);
gdjs.IntroCutsceneCode.GDNewSpriteObjects1.length = 0;
gdjs.IntroCutsceneCode.GDNewSpriteObjects2.length = 0;
gdjs.IntroCutsceneCode.GDintroObjects1.length = 0;
gdjs.IntroCutsceneCode.GDintroObjects2.length = 0;
gdjs.IntroCutsceneCode.GDNewVideoObjects1.length = 0;
gdjs.IntroCutsceneCode.GDNewVideoObjects2.length = 0;
gdjs.IntroCutsceneCode.GDNewSprite2Objects1.length = 0;
gdjs.IntroCutsceneCode.GDNewSprite2Objects2.length = 0;
gdjs.IntroCutsceneCode.GDSkip_9595IntroObjects1.length = 0;
gdjs.IntroCutsceneCode.GDSkip_9595IntroObjects2.length = 0;


return;

}

gdjs['IntroCutsceneCode'] = gdjs.IntroCutsceneCode;
