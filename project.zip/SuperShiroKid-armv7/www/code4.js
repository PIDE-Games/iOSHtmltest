gdjs.Title_32screenCode = {};
gdjs.Title_32screenCode.localVariables = [];
gdjs.Title_32screenCode.idToCallbackMap = new Map();
gdjs.Title_32screenCode.GDLOGOObjects1= [];
gdjs.Title_32screenCode.GDLOGOObjects2= [];
gdjs.Title_32screenCode.GDNew3DBoxObjects1= [];
gdjs.Title_32screenCode.GDNew3DBoxObjects2= [];
gdjs.Title_32screenCode.GDcloudObjects1= [];
gdjs.Title_32screenCode.GDcloudObjects2= [];
gdjs.Title_32screenCode.GDCreditsObjects1= [];
gdjs.Title_32screenCode.GDCreditsObjects2= [];
gdjs.Title_32screenCode.GDshirotitleObjects1= [];
gdjs.Title_32screenCode.GDshirotitleObjects2= [];
gdjs.Title_32screenCode.GDNewSpriteObjects1= [];
gdjs.Title_32screenCode.GDNewSpriteObjects2= [];
gdjs.Title_32screenCode.GDPlayObjects1= [];
gdjs.Title_32screenCode.GDPlayObjects2= [];
gdjs.Title_32screenCode.GDcloud2Objects1= [];
gdjs.Title_32screenCode.GDcloud2Objects2= [];
gdjs.Title_32screenCode.GDNewSprite2Objects1= [];
gdjs.Title_32screenCode.GDNewSprite2Objects2= [];
gdjs.Title_32screenCode.GDNewSprite3Objects1= [];
gdjs.Title_32screenCode.GDNewSprite3Objects2= [];
gdjs.Title_32screenCode.GDCloudObjects1= [];
gdjs.Title_32screenCode.GDCloudObjects2= [];
gdjs.Title_32screenCode.GDNewSprite4Objects1= [];
gdjs.Title_32screenCode.GDNewSprite4Objects2= [];
gdjs.Title_32screenCode.GDNewSprite5Objects1= [];
gdjs.Title_32screenCode.GDNewSprite5Objects2= [];
gdjs.Title_32screenCode.GDNewSprite6Objects1= [];
gdjs.Title_32screenCode.GDNewSprite6Objects2= [];
gdjs.Title_32screenCode.GDTap_9595_9595Objects1= [];
gdjs.Title_32screenCode.GDTap_9595_9595Objects2= [];
gdjs.Title_32screenCode.GDNew3DBox2Objects1= [];
gdjs.Title_32screenCode.GDNew3DBox2Objects2= [];
gdjs.Title_32screenCode.GDSoundSettingObjects1= [];
gdjs.Title_32screenCode.GDSoundSettingObjects2= [];
gdjs.Title_32screenCode.GDNew3DModelObjects1= [];
gdjs.Title_32screenCode.GDNew3DModelObjects2= [];


gdjs.Title_32screenCode.mapOfGDgdjs_9546Title_959532screenCode_9546GDNewSpriteObjects1Objects = Hashtable.newFrom({"NewSprite": gdjs.Title_32screenCode.GDNewSpriteObjects1});
gdjs.Title_32screenCode.mapOfGDgdjs_9546Title_959532screenCode_9546GDcloudObjects1Objects = Hashtable.newFrom({"cloud": gdjs.Title_32screenCode.GDcloudObjects1});
gdjs.Title_32screenCode.eventsList0 = function(runtimeScene) {

{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.runtimeScene.sceneJustBegins(runtimeScene);
if (isConditionTrue_0) {
{gdjs.evtTools.sound.playMusicOnChannel(runtimeScene, "IntroShiroKiddo.mp3", 1, false, 200, 1);
}
}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.sound.isMusicOnChannelPlaying(runtimeScene, 2);
if (isConditionTrue_0) {
{gdjs.evtTools.sound.stopMusicOnChannel(runtimeScene, 1);
}
}

}


{


let isConditionTrue_0 = false;
{
}

}


{


let isConditionTrue_0 = false;
{
}

}


{

gdjs.copyArray(runtimeScene.getObjects("NewSprite"), gdjs.Title_32screenCode.GDNewSpriteObjects1);
gdjs.copyArray(runtimeScene.getObjects("cloud"), gdjs.Title_32screenCode.GDcloudObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.Title_32screenCode.mapOfGDgdjs_9546Title_959532screenCode_9546GDNewSpriteObjects1Objects, gdjs.Title_32screenCode.mapOfGDgdjs_9546Title_959532screenCode_9546GDcloudObjects1Objects, false, runtimeScene, false);
if (isConditionTrue_0) {
{gdjs.evtTools.runtimeScene.replaceScene(runtimeScene, "Settings", false);
}
}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtsExt__Gamepads__C_Axis_pushed.func(runtimeScene, 1, "Left", "Up", null);
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("Play"), gdjs.Title_32screenCode.GDPlayObjects1);
{for(var i = 0, len = gdjs.Title_32screenCode.GDPlayObjects1.length ;i < len;++i) {
    gdjs.Title_32screenCode.GDPlayObjects1[i].getBehavior("ButtonAnimationName").SetIdleAnimationName("press", null);
}
}
}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtsExt__Gamepads__C_Button_pressed.func(runtimeScene, 1, "A", null);
if (isConditionTrue_0) {
{gdjs.evtTools.runtimeScene.replaceScene(runtimeScene, "Settings", false);
}
}

}


{

gdjs.copyArray(runtimeScene.getObjects("NewSprite6"), gdjs.Title_32screenCode.GDNewSprite6Objects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.Title_32screenCode.GDNewSprite6Objects1.length;i<l;++i) {
    if ( gdjs.Title_32screenCode.GDNewSprite6Objects1[i].getBehavior("ButtonFSM").IsPressed(null) ) {
        isConditionTrue_0 = true;
        gdjs.Title_32screenCode.GDNewSprite6Objects1[k] = gdjs.Title_32screenCode.GDNewSprite6Objects1[i];
        ++k;
    }
}
gdjs.Title_32screenCode.GDNewSprite6Objects1.length = k;
if (isConditionTrue_0) {
{gdjs.evtTools.runtimeScene.replaceScene(runtimeScene, "Ending", false);
}
}

}


{

gdjs.copyArray(runtimeScene.getObjects("Play"), gdjs.Title_32screenCode.GDPlayObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.Title_32screenCode.GDPlayObjects1.length;i<l;++i) {
    if ( gdjs.Title_32screenCode.GDPlayObjects1[i].getBehavior("ButtonFSM").IsHovered(null) ) {
        isConditionTrue_0 = true;
        gdjs.Title_32screenCode.GDPlayObjects1[k] = gdjs.Title_32screenCode.GDPlayObjects1[i];
        ++k;
    }
}
gdjs.Title_32screenCode.GDPlayObjects1.length = k;
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("shirotitle"), gdjs.Title_32screenCode.GDshirotitleObjects1);
{for(var i = 0, len = gdjs.Title_32screenCode.GDshirotitleObjects1.length ;i < len;++i) {
    gdjs.Title_32screenCode.GDshirotitleObjects1[i].getBehavior("Animation").setAnimationName("NewSprite");
}
}
}

}


{

gdjs.copyArray(runtimeScene.getObjects("Play"), gdjs.Title_32screenCode.GDPlayObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.Title_32screenCode.GDPlayObjects1.length;i<l;++i) {
    if ( gdjs.Title_32screenCode.GDPlayObjects1[i].getBehavior("ButtonFSM").IsIdle(null) ) {
        isConditionTrue_0 = true;
        gdjs.Title_32screenCode.GDPlayObjects1[k] = gdjs.Title_32screenCode.GDPlayObjects1[i];
        ++k;
    }
}
gdjs.Title_32screenCode.GDPlayObjects1.length = k;
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("shirotitle"), gdjs.Title_32screenCode.GDshirotitleObjects1);
{for(var i = 0, len = gdjs.Title_32screenCode.GDshirotitleObjects1.length ;i < len;++i) {
    gdjs.Title_32screenCode.GDshirotitleObjects1[i].getBehavior("Animation").setAnimationName("NewSprite");
}
}
}

}


{

gdjs.copyArray(runtimeScene.getObjects("Play"), gdjs.Title_32screenCode.GDPlayObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.Title_32screenCode.GDPlayObjects1.length;i<l;++i) {
    if ( gdjs.Title_32screenCode.GDPlayObjects1[i].getBehavior("ButtonFSM").IsPressed(null) ) {
        isConditionTrue_0 = true;
        gdjs.Title_32screenCode.GDPlayObjects1[k] = gdjs.Title_32screenCode.GDPlayObjects1[i];
        ++k;
    }
}
gdjs.Title_32screenCode.GDPlayObjects1.length = k;
if (isConditionTrue_0) {
{gdjs.evtTools.sound.playSoundOnChannel(runtimeScene, "Selecttitle.mp3", 11, false, 100, 1);
}
}

}


{

gdjs.copyArray(runtimeScene.getObjects("Play"), gdjs.Title_32screenCode.GDPlayObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.Title_32screenCode.GDPlayObjects1.length;i<l;++i) {
    if ( gdjs.Title_32screenCode.GDPlayObjects1[i].getBehavior("ButtonFSM").IsPressed(null) ) {
        isConditionTrue_0 = true;
        gdjs.Title_32screenCode.GDPlayObjects1[k] = gdjs.Title_32screenCode.GDPlayObjects1[i];
        ++k;
    }
}
gdjs.Title_32screenCode.GDPlayObjects1.length = k;
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("NewSprite"), gdjs.Title_32screenCode.GDNewSpriteObjects1);
gdjs.copyArray(runtimeScene.getObjects("cloud"), gdjs.Title_32screenCode.GDcloudObjects1);
{for(var i = 0, len = gdjs.Title_32screenCode.GDNewSpriteObjects1.length ;i < len;++i) {
    gdjs.Title_32screenCode.GDNewSpriteObjects1[i].addForceTowardObject((gdjs.Title_32screenCode.GDcloudObjects1.length !== 0 ? gdjs.Title_32screenCode.GDcloudObjects1[0] : null), 4000, 1);
}
}
}

}


{


let isConditionTrue_0 = false;
{
}

}


{

gdjs.copyArray(runtimeScene.getObjects("SoundSetting"), gdjs.Title_32screenCode.GDSoundSettingObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.Title_32screenCode.GDSoundSettingObjects1.length;i<l;++i) {
    if ( gdjs.Title_32screenCode.GDSoundSettingObjects1[i].getBehavior("ButtonFSM").IsPressed(null) ) {
        isConditionTrue_0 = true;
        gdjs.Title_32screenCode.GDSoundSettingObjects1[k] = gdjs.Title_32screenCode.GDSoundSettingObjects1[i];
        ++k;
    }
}
gdjs.Title_32screenCode.GDSoundSettingObjects1.length = k;
if (isConditionTrue_0) {
/* Reuse gdjs.Title_32screenCode.GDSoundSettingObjects1 */
{for(var i = 0, len = gdjs.Title_32screenCode.GDSoundSettingObjects1.length ;i < len;++i) {
    gdjs.Title_32screenCode.GDSoundSettingObjects1[i].getBehavior("Animation").setAnimationName("NoSound");
}
}
}

}


{

gdjs.copyArray(runtimeScene.getObjects("SoundSetting"), gdjs.Title_32screenCode.GDSoundSettingObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.Title_32screenCode.GDSoundSettingObjects1.length;i<l;++i) {
    if ( gdjs.Title_32screenCode.GDSoundSettingObjects1[i].getBehavior("ButtonFSM").IsPressed(null) ) {
        isConditionTrue_0 = true;
        gdjs.Title_32screenCode.GDSoundSettingObjects1[k] = gdjs.Title_32screenCode.GDSoundSettingObjects1[i];
        ++k;
    }
}
gdjs.Title_32screenCode.GDSoundSettingObjects1.length = k;
if (isConditionTrue_0) {
{gdjs.evtTools.sound.setGlobalVolume(runtimeScene, 0);
}
}

}


};

gdjs.Title_32screenCode.func = function(runtimeScene) {
runtimeScene.getOnceTriggers().startNewFrame();

gdjs.Title_32screenCode.GDLOGOObjects1.length = 0;
gdjs.Title_32screenCode.GDLOGOObjects2.length = 0;
gdjs.Title_32screenCode.GDNew3DBoxObjects1.length = 0;
gdjs.Title_32screenCode.GDNew3DBoxObjects2.length = 0;
gdjs.Title_32screenCode.GDcloudObjects1.length = 0;
gdjs.Title_32screenCode.GDcloudObjects2.length = 0;
gdjs.Title_32screenCode.GDCreditsObjects1.length = 0;
gdjs.Title_32screenCode.GDCreditsObjects2.length = 0;
gdjs.Title_32screenCode.GDshirotitleObjects1.length = 0;
gdjs.Title_32screenCode.GDshirotitleObjects2.length = 0;
gdjs.Title_32screenCode.GDNewSpriteObjects1.length = 0;
gdjs.Title_32screenCode.GDNewSpriteObjects2.length = 0;
gdjs.Title_32screenCode.GDPlayObjects1.length = 0;
gdjs.Title_32screenCode.GDPlayObjects2.length = 0;
gdjs.Title_32screenCode.GDcloud2Objects1.length = 0;
gdjs.Title_32screenCode.GDcloud2Objects2.length = 0;
gdjs.Title_32screenCode.GDNewSprite2Objects1.length = 0;
gdjs.Title_32screenCode.GDNewSprite2Objects2.length = 0;
gdjs.Title_32screenCode.GDNewSprite3Objects1.length = 0;
gdjs.Title_32screenCode.GDNewSprite3Objects2.length = 0;
gdjs.Title_32screenCode.GDCloudObjects1.length = 0;
gdjs.Title_32screenCode.GDCloudObjects2.length = 0;
gdjs.Title_32screenCode.GDNewSprite4Objects1.length = 0;
gdjs.Title_32screenCode.GDNewSprite4Objects2.length = 0;
gdjs.Title_32screenCode.GDNewSprite5Objects1.length = 0;
gdjs.Title_32screenCode.GDNewSprite5Objects2.length = 0;
gdjs.Title_32screenCode.GDNewSprite6Objects1.length = 0;
gdjs.Title_32screenCode.GDNewSprite6Objects2.length = 0;
gdjs.Title_32screenCode.GDTap_9595_9595Objects1.length = 0;
gdjs.Title_32screenCode.GDTap_9595_9595Objects2.length = 0;
gdjs.Title_32screenCode.GDNew3DBox2Objects1.length = 0;
gdjs.Title_32screenCode.GDNew3DBox2Objects2.length = 0;
gdjs.Title_32screenCode.GDSoundSettingObjects1.length = 0;
gdjs.Title_32screenCode.GDSoundSettingObjects2.length = 0;
gdjs.Title_32screenCode.GDNew3DModelObjects1.length = 0;
gdjs.Title_32screenCode.GDNew3DModelObjects2.length = 0;

gdjs.Title_32screenCode.eventsList0(runtimeScene);
gdjs.Title_32screenCode.GDLOGOObjects1.length = 0;
gdjs.Title_32screenCode.GDLOGOObjects2.length = 0;
gdjs.Title_32screenCode.GDNew3DBoxObjects1.length = 0;
gdjs.Title_32screenCode.GDNew3DBoxObjects2.length = 0;
gdjs.Title_32screenCode.GDcloudObjects1.length = 0;
gdjs.Title_32screenCode.GDcloudObjects2.length = 0;
gdjs.Title_32screenCode.GDCreditsObjects1.length = 0;
gdjs.Title_32screenCode.GDCreditsObjects2.length = 0;
gdjs.Title_32screenCode.GDshirotitleObjects1.length = 0;
gdjs.Title_32screenCode.GDshirotitleObjects2.length = 0;
gdjs.Title_32screenCode.GDNewSpriteObjects1.length = 0;
gdjs.Title_32screenCode.GDNewSpriteObjects2.length = 0;
gdjs.Title_32screenCode.GDPlayObjects1.length = 0;
gdjs.Title_32screenCode.GDPlayObjects2.length = 0;
gdjs.Title_32screenCode.GDcloud2Objects1.length = 0;
gdjs.Title_32screenCode.GDcloud2Objects2.length = 0;
gdjs.Title_32screenCode.GDNewSprite2Objects1.length = 0;
gdjs.Title_32screenCode.GDNewSprite2Objects2.length = 0;
gdjs.Title_32screenCode.GDNewSprite3Objects1.length = 0;
gdjs.Title_32screenCode.GDNewSprite3Objects2.length = 0;
gdjs.Title_32screenCode.GDCloudObjects1.length = 0;
gdjs.Title_32screenCode.GDCloudObjects2.length = 0;
gdjs.Title_32screenCode.GDNewSprite4Objects1.length = 0;
gdjs.Title_32screenCode.GDNewSprite4Objects2.length = 0;
gdjs.Title_32screenCode.GDNewSprite5Objects1.length = 0;
gdjs.Title_32screenCode.GDNewSprite5Objects2.length = 0;
gdjs.Title_32screenCode.GDNewSprite6Objects1.length = 0;
gdjs.Title_32screenCode.GDNewSprite6Objects2.length = 0;
gdjs.Title_32screenCode.GDTap_9595_9595Objects1.length = 0;
gdjs.Title_32screenCode.GDTap_9595_9595Objects2.length = 0;
gdjs.Title_32screenCode.GDNew3DBox2Objects1.length = 0;
gdjs.Title_32screenCode.GDNew3DBox2Objects2.length = 0;
gdjs.Title_32screenCode.GDSoundSettingObjects1.length = 0;
gdjs.Title_32screenCode.GDSoundSettingObjects2.length = 0;
gdjs.Title_32screenCode.GDNew3DModelObjects1.length = 0;
gdjs.Title_32screenCode.GDNew3DModelObjects2.length = 0;


return;

}

gdjs['Title_32screenCode'] = gdjs.Title_32screenCode;
