gdjs.Sound_32SettingsCode = {};
gdjs.Sound_32SettingsCode.localVariables = [];
gdjs.Sound_32SettingsCode.idToCallbackMap = new Map();
gdjs.Sound_32SettingsCode.GDNewTiledSpriteObjects1= [];
gdjs.Sound_32SettingsCode.GDNewTiledSpriteObjects2= [];
gdjs.Sound_32SettingsCode.GDSoundSettingObjects1= [];
gdjs.Sound_32SettingsCode.GDSoundSettingObjects2= [];
gdjs.Sound_32SettingsCode.GDSoundSetting2Objects1= [];
gdjs.Sound_32SettingsCode.GDSoundSetting2Objects2= [];
gdjs.Sound_32SettingsCode.GDSettingSoundtextObjects1= [];
gdjs.Sound_32SettingsCode.GDSettingSoundtextObjects2= [];
gdjs.Sound_32SettingsCode.GDNewSpriteObjects1= [];
gdjs.Sound_32SettingsCode.GDNewSpriteObjects2= [];
gdjs.Sound_32SettingsCode.GDPlay_9595GameObjects1= [];
gdjs.Sound_32SettingsCode.GDPlay_9595GameObjects2= [];
gdjs.Sound_32SettingsCode.GDPlay_9595Game2Objects1= [];
gdjs.Sound_32SettingsCode.GDPlay_9595Game2Objects2= [];


gdjs.Sound_32SettingsCode.eventsList0 = function(runtimeScene) {

{

gdjs.copyArray(runtimeScene.getObjects("SoundSetting"), gdjs.Sound_32SettingsCode.GDSoundSettingObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.Sound_32SettingsCode.GDSoundSettingObjects1.length;i<l;++i) {
    if ( gdjs.Sound_32SettingsCode.GDSoundSettingObjects1[i].getBehavior("ButtonFSM").IsPressed(null) ) {
        isConditionTrue_0 = true;
        gdjs.Sound_32SettingsCode.GDSoundSettingObjects1[k] = gdjs.Sound_32SettingsCode.GDSoundSettingObjects1[i];
        ++k;
    }
}
gdjs.Sound_32SettingsCode.GDSoundSettingObjects1.length = k;
if (isConditionTrue_0) {
{gdjs.evtTools.sound.setGlobalVolume(runtimeScene, 100);
}
}

}


{

gdjs.copyArray(runtimeScene.getObjects("SoundSetting2"), gdjs.Sound_32SettingsCode.GDSoundSetting2Objects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.Sound_32SettingsCode.GDSoundSetting2Objects1.length;i<l;++i) {
    if ( gdjs.Sound_32SettingsCode.GDSoundSetting2Objects1[i].getBehavior("ButtonFSM").IsPressed(null) ) {
        isConditionTrue_0 = true;
        gdjs.Sound_32SettingsCode.GDSoundSetting2Objects1[k] = gdjs.Sound_32SettingsCode.GDSoundSetting2Objects1[i];
        ++k;
    }
}
gdjs.Sound_32SettingsCode.GDSoundSetting2Objects1.length = k;
if (isConditionTrue_0) {
{gdjs.evtTools.sound.setGlobalVolume(runtimeScene, 0);
}
}

}


{

gdjs.copyArray(runtimeScene.getObjects("Play_Game"), gdjs.Sound_32SettingsCode.GDPlay_9595GameObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.Sound_32SettingsCode.GDPlay_9595GameObjects1.length;i<l;++i) {
    if ( gdjs.Sound_32SettingsCode.GDPlay_9595GameObjects1[i].getBehavior("ButtonFSM").IsPressed(null) ) {
        isConditionTrue_0 = true;
        gdjs.Sound_32SettingsCode.GDPlay_9595GameObjects1[k] = gdjs.Sound_32SettingsCode.GDPlay_9595GameObjects1[i];
        ++k;
    }
}
gdjs.Sound_32SettingsCode.GDPlay_9595GameObjects1.length = k;
if (isConditionTrue_0) {
{gdjs.evtTools.runtimeScene.replaceScene(runtimeScene, "PIDELOGO", false);
}
{gdjs.evtTools.sound.setGlobalVolume(runtimeScene, 100);
}
}

}


{


let isConditionTrue_0 = false;
{
}

}


};

gdjs.Sound_32SettingsCode.func = function(runtimeScene) {
runtimeScene.getOnceTriggers().startNewFrame();

gdjs.Sound_32SettingsCode.GDNewTiledSpriteObjects1.length = 0;
gdjs.Sound_32SettingsCode.GDNewTiledSpriteObjects2.length = 0;
gdjs.Sound_32SettingsCode.GDSoundSettingObjects1.length = 0;
gdjs.Sound_32SettingsCode.GDSoundSettingObjects2.length = 0;
gdjs.Sound_32SettingsCode.GDSoundSetting2Objects1.length = 0;
gdjs.Sound_32SettingsCode.GDSoundSetting2Objects2.length = 0;
gdjs.Sound_32SettingsCode.GDSettingSoundtextObjects1.length = 0;
gdjs.Sound_32SettingsCode.GDSettingSoundtextObjects2.length = 0;
gdjs.Sound_32SettingsCode.GDNewSpriteObjects1.length = 0;
gdjs.Sound_32SettingsCode.GDNewSpriteObjects2.length = 0;
gdjs.Sound_32SettingsCode.GDPlay_9595GameObjects1.length = 0;
gdjs.Sound_32SettingsCode.GDPlay_9595GameObjects2.length = 0;
gdjs.Sound_32SettingsCode.GDPlay_9595Game2Objects1.length = 0;
gdjs.Sound_32SettingsCode.GDPlay_9595Game2Objects2.length = 0;

gdjs.Sound_32SettingsCode.eventsList0(runtimeScene);
gdjs.Sound_32SettingsCode.GDNewTiledSpriteObjects1.length = 0;
gdjs.Sound_32SettingsCode.GDNewTiledSpriteObjects2.length = 0;
gdjs.Sound_32SettingsCode.GDSoundSettingObjects1.length = 0;
gdjs.Sound_32SettingsCode.GDSoundSettingObjects2.length = 0;
gdjs.Sound_32SettingsCode.GDSoundSetting2Objects1.length = 0;
gdjs.Sound_32SettingsCode.GDSoundSetting2Objects2.length = 0;
gdjs.Sound_32SettingsCode.GDSettingSoundtextObjects1.length = 0;
gdjs.Sound_32SettingsCode.GDSettingSoundtextObjects2.length = 0;
gdjs.Sound_32SettingsCode.GDNewSpriteObjects1.length = 0;
gdjs.Sound_32SettingsCode.GDNewSpriteObjects2.length = 0;
gdjs.Sound_32SettingsCode.GDPlay_9595GameObjects1.length = 0;
gdjs.Sound_32SettingsCode.GDPlay_9595GameObjects2.length = 0;
gdjs.Sound_32SettingsCode.GDPlay_9595Game2Objects1.length = 0;
gdjs.Sound_32SettingsCode.GDPlay_9595Game2Objects2.length = 0;


return;

}

gdjs['Sound_32SettingsCode'] = gdjs.Sound_32SettingsCode;
