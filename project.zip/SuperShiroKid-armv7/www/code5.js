gdjs.TUTORIALCode = {};
gdjs.TUTORIALCode.localVariables = [];
gdjs.TUTORIALCode.idToCallbackMap = new Map();
gdjs.TUTORIALCode.GDPlayerObjects1= [];
gdjs.TUTORIALCode.GDPlayerObjects2= [];
gdjs.TUTORIALCode.GDCoinsObjects1= [];
gdjs.TUTORIALCode.GDCoinsObjects2= [];
gdjs.TUTORIALCode.GDPlatform_9595GroundObjects1= [];
gdjs.TUTORIALCode.GDPlatform_9595GroundObjects2= [];
gdjs.TUTORIALCode.GDNewSprite4Objects1= [];
gdjs.TUTORIALCode.GDNewSprite4Objects2= [];
gdjs.TUTORIALCode.GDNewSprite5Objects1= [];
gdjs.TUTORIALCode.GDNewSprite5Objects2= [];
gdjs.TUTORIALCode.GDNewSprite6Objects1= [];
gdjs.TUTORIALCode.GDNewSprite6Objects2= [];
gdjs.TUTORIALCode.GDspikeObjects1= [];
gdjs.TUTORIALCode.GDspikeObjects2= [];
gdjs.TUTORIALCode.GDNewSprite7Objects1= [];
gdjs.TUTORIALCode.GDNewSprite7Objects2= [];
gdjs.TUTORIALCode.GDNewSprite8Objects1= [];
gdjs.TUTORIALCode.GDNewSprite8Objects2= [];
gdjs.TUTORIALCode.GDNewSprite3Objects1= [];
gdjs.TUTORIALCode.GDNewSprite3Objects2= [];
gdjs.TUTORIALCode.GDpipeObjects1= [];
gdjs.TUTORIALCode.GDpipeObjects2= [];
gdjs.TUTORIALCode.GDStacyObjects1= [];
gdjs.TUTORIALCode.GDStacyObjects2= [];
gdjs.TUTORIALCode.GDShadedDarkJoystickObjects1= [];
gdjs.TUTORIALCode.GDShadedDarkJoystickObjects2= [];
gdjs.TUTORIALCode.GDNewSpriteObjects1= [];
gdjs.TUTORIALCode.GDNewSpriteObjects2= [];
gdjs.TUTORIALCode.GDNewSprite9Objects1= [];
gdjs.TUTORIALCode.GDNewSprite9Objects2= [];
gdjs.TUTORIALCode.GDMountain_9595dewObjects1= [];
gdjs.TUTORIALCode.GDMountain_9595dewObjects2= [];
gdjs.TUTORIALCode.GDNewSprite10Objects1= [];
gdjs.TUTORIALCode.GDNewSprite10Objects2= [];
gdjs.TUTORIALCode.GDJumpObjects1= [];
gdjs.TUTORIALCode.GDJumpObjects2= [];
gdjs.TUTORIALCode.GDTreeObjects1= [];
gdjs.TUTORIALCode.GDTreeObjects2= [];
gdjs.TUTORIALCode.GDPauseObjects1= [];
gdjs.TUTORIALCode.GDPauseObjects2= [];
gdjs.TUTORIALCode.GDNewTextObjects1= [];
gdjs.TUTORIALCode.GDNewTextObjects2= [];
gdjs.TUTORIALCode.GDNewSprite2Objects1= [];
gdjs.TUTORIALCode.GDNewSprite2Objects2= [];
gdjs.TUTORIALCode.GDNewSprite11Objects1= [];
gdjs.TUTORIALCode.GDNewSprite11Objects2= [];
gdjs.TUTORIALCode.GDNewSprite12Objects1= [];
gdjs.TUTORIALCode.GDNewSprite12Objects2= [];
gdjs.TUTORIALCode.GDNewSprite13Objects1= [];
gdjs.TUTORIALCode.GDNewSprite13Objects2= [];
gdjs.TUTORIALCode.GDspikenotvisiObjects1= [];
gdjs.TUTORIALCode.GDspikenotvisiObjects2= [];
gdjs.TUTORIALCode.GDBoomObjects1= [];
gdjs.TUTORIALCode.GDBoomObjects2= [];
gdjs.TUTORIALCode.GDNew3DBoxObjects1= [];
gdjs.TUTORIALCode.GDNew3DBoxObjects2= [];
gdjs.TUTORIALCode.GDLoadanimObjects1= [];
gdjs.TUTORIALCode.GDLoadanimObjects2= [];
gdjs.TUTORIALCode.GDNewSprite14Objects1= [];
gdjs.TUTORIALCode.GDNewSprite14Objects2= [];
gdjs.TUTORIALCode.GDBushesObjects1= [];
gdjs.TUTORIALCode.GDBushesObjects2= [];
gdjs.TUTORIALCode.GDNewSprite15Objects1= [];
gdjs.TUTORIALCode.GDNewSprite15Objects2= [];
gdjs.TUTORIALCode.GDSurpsObjects1= [];
gdjs.TUTORIALCode.GDSurpsObjects2= [];
gdjs.TUTORIALCode.GDNewSprite16Objects1= [];
gdjs.TUTORIALCode.GDNewSprite16Objects2= [];
gdjs.TUTORIALCode.GDDeathObjects1= [];
gdjs.TUTORIALCode.GDDeathObjects2= [];
gdjs.TUTORIALCode.GDmenublockObjects1= [];
gdjs.TUTORIALCode.GDmenublockObjects2= [];
gdjs.TUTORIALCode.GDTutorialObjects1= [];
gdjs.TUTORIALCode.GDTutorialObjects2= [];
gdjs.TUTORIALCode.GDNewText2Objects1= [];
gdjs.TUTORIALCode.GDNewText2Objects2= [];
gdjs.TUTORIALCode.GDNewText3Objects1= [];
gdjs.TUTORIALCode.GDNewText3Objects2= [];
gdjs.TUTORIALCode.GDNewText4Objects1= [];
gdjs.TUTORIALCode.GDNewText4Objects2= [];


gdjs.TUTORIALCode.mapOfGDgdjs_9546TUTORIALCode_9546GDPlayerObjects1Objects = Hashtable.newFrom({"Player": gdjs.TUTORIALCode.GDPlayerObjects1});
gdjs.TUTORIALCode.mapOfGDgdjs_9546TUTORIALCode_9546GDCoinsObjects1Objects = Hashtable.newFrom({"Coins": gdjs.TUTORIALCode.GDCoinsObjects1});
gdjs.TUTORIALCode.mapOfGDgdjs_9546TUTORIALCode_9546GDPlayerObjects1Objects = Hashtable.newFrom({"Player": gdjs.TUTORIALCode.GDPlayerObjects1});
gdjs.TUTORIALCode.mapOfGDgdjs_9546TUTORIALCode_9546GDNewSprite11Objects1Objects = Hashtable.newFrom({"NewSprite11": gdjs.TUTORIALCode.GDNewSprite11Objects1});
gdjs.TUTORIALCode.mapOfGDgdjs_9546TUTORIALCode_9546GDPlayerObjects1Objects = Hashtable.newFrom({"Player": gdjs.TUTORIALCode.GDPlayerObjects1});
gdjs.TUTORIALCode.mapOfGDgdjs_9546TUTORIALCode_9546GDNewSprite4Objects1Objects = Hashtable.newFrom({"NewSprite4": gdjs.TUTORIALCode.GDNewSprite4Objects1});
gdjs.TUTORIALCode.mapOfGDgdjs_9546TUTORIALCode_9546GDPlayerObjects1Objects = Hashtable.newFrom({"Player": gdjs.TUTORIALCode.GDPlayerObjects1});
gdjs.TUTORIALCode.mapOfGDgdjs_9546TUTORIALCode_9546GDNewSprite11Objects1Objects = Hashtable.newFrom({"NewSprite11": gdjs.TUTORIALCode.GDNewSprite11Objects1});
gdjs.TUTORIALCode.mapOfGDgdjs_9546TUTORIALCode_9546GDPlayerObjects1Objects = Hashtable.newFrom({"Player": gdjs.TUTORIALCode.GDPlayerObjects1});
gdjs.TUTORIALCode.mapOfGDgdjs_9546TUTORIALCode_9546GDNewSprite4Objects1Objects = Hashtable.newFrom({"NewSprite4": gdjs.TUTORIALCode.GDNewSprite4Objects1});
gdjs.TUTORIALCode.mapOfGDgdjs_9546TUTORIALCode_9546GDPlayerObjects1Objects = Hashtable.newFrom({"Player": gdjs.TUTORIALCode.GDPlayerObjects1});
gdjs.TUTORIALCode.mapOfGDgdjs_9546TUTORIALCode_9546GDspikeObjects1Objects = Hashtable.newFrom({"spike": gdjs.TUTORIALCode.GDspikeObjects1});
gdjs.TUTORIALCode.mapOfGDgdjs_9546TUTORIALCode_9546GDPlayerObjects1Objects = Hashtable.newFrom({"Player": gdjs.TUTORIALCode.GDPlayerObjects1});
gdjs.TUTORIALCode.mapOfGDgdjs_9546TUTORIALCode_9546GDspikeObjects1Objects = Hashtable.newFrom({"spike": gdjs.TUTORIALCode.GDspikeObjects1});
gdjs.TUTORIALCode.mapOfGDgdjs_9546TUTORIALCode_9546GDPlayerObjects1Objects = Hashtable.newFrom({"Player": gdjs.TUTORIALCode.GDPlayerObjects1});
gdjs.TUTORIALCode.mapOfGDgdjs_9546TUTORIALCode_9546GDPlatform_95959595GroundObjects1Objects = Hashtable.newFrom({"Platform_Ground": gdjs.TUTORIALCode.GDPlatform_9595GroundObjects1});
gdjs.TUTORIALCode.mapOfGDgdjs_9546TUTORIALCode_9546GDPlayerObjects1Objects = Hashtable.newFrom({"Player": gdjs.TUTORIALCode.GDPlayerObjects1});
gdjs.TUTORIALCode.mapOfGDgdjs_9546TUTORIALCode_9546GDPlatform_95959595GroundObjects1Objects = Hashtable.newFrom({"Platform_Ground": gdjs.TUTORIALCode.GDPlatform_9595GroundObjects1});
gdjs.TUTORIALCode.mapOfGDgdjs_9546TUTORIALCode_9546GDPlayerObjects1Objects = Hashtable.newFrom({"Player": gdjs.TUTORIALCode.GDPlayerObjects1});
gdjs.TUTORIALCode.mapOfGDgdjs_9546TUTORIALCode_9546GDspikeObjects1Objects = Hashtable.newFrom({"spike": gdjs.TUTORIALCode.GDspikeObjects1});
gdjs.TUTORIALCode.mapOfGDgdjs_9546TUTORIALCode_9546GDPlayerObjects1Objects = Hashtable.newFrom({"Player": gdjs.TUTORIALCode.GDPlayerObjects1});
gdjs.TUTORIALCode.mapOfGDgdjs_9546TUTORIALCode_9546GDNewSprite14Objects1Objects = Hashtable.newFrom({"NewSprite14": gdjs.TUTORIALCode.GDNewSprite14Objects1});
gdjs.TUTORIALCode.mapOfGDgdjs_9546TUTORIALCode_9546GDPlayerObjects1Objects = Hashtable.newFrom({"Player": gdjs.TUTORIALCode.GDPlayerObjects1});
gdjs.TUTORIALCode.mapOfGDgdjs_9546TUTORIALCode_9546GDNewSprite15Objects1Objects = Hashtable.newFrom({"NewSprite15": gdjs.TUTORIALCode.GDNewSprite15Objects1});
gdjs.TUTORIALCode.mapOfGDgdjs_9546TUTORIALCode_9546GDPlayerObjects1Objects = Hashtable.newFrom({"Player": gdjs.TUTORIALCode.GDPlayerObjects1});
gdjs.TUTORIALCode.mapOfGDgdjs_9546TUTORIALCode_9546GDspikeObjects1Objects = Hashtable.newFrom({"spike": gdjs.TUTORIALCode.GDspikeObjects1});
gdjs.TUTORIALCode.mapOfGDgdjs_9546TUTORIALCode_9546GDPlayerObjects1Objects = Hashtable.newFrom({"Player": gdjs.TUTORIALCode.GDPlayerObjects1});
gdjs.TUTORIALCode.mapOfGDgdjs_9546TUTORIALCode_9546GDspikeObjects1Objects = Hashtable.newFrom({"spike": gdjs.TUTORIALCode.GDspikeObjects1});
gdjs.TUTORIALCode.mapOfGDgdjs_9546TUTORIALCode_9546GDPlayerObjects1Objects = Hashtable.newFrom({"Player": gdjs.TUTORIALCode.GDPlayerObjects1});
gdjs.TUTORIALCode.mapOfGDgdjs_9546TUTORIALCode_9546GDDeathObjects1Objects = Hashtable.newFrom({"Death": gdjs.TUTORIALCode.GDDeathObjects1});
gdjs.TUTORIALCode.mapOfGDgdjs_9546TUTORIALCode_9546GDPlayerObjects1Objects = Hashtable.newFrom({"Player": gdjs.TUTORIALCode.GDPlayerObjects1});
gdjs.TUTORIALCode.mapOfGDgdjs_9546TUTORIALCode_9546GDmenublockObjects1Objects = Hashtable.newFrom({"menublock": gdjs.TUTORIALCode.GDmenublockObjects1});
gdjs.TUTORIALCode.mapOfGDgdjs_9546TUTORIALCode_9546GDPlayerObjects1Objects = Hashtable.newFrom({"Player": gdjs.TUTORIALCode.GDPlayerObjects1});
gdjs.TUTORIALCode.mapOfGDgdjs_9546TUTORIALCode_9546GDDeathObjects1Objects = Hashtable.newFrom({"Death": gdjs.TUTORIALCode.GDDeathObjects1});
gdjs.TUTORIALCode.mapOfGDgdjs_9546TUTORIALCode_9546GDPlayerObjects1Objects = Hashtable.newFrom({"Player": gdjs.TUTORIALCode.GDPlayerObjects1});
gdjs.TUTORIALCode.mapOfGDgdjs_9546TUTORIALCode_9546GDDeathObjects1Objects = Hashtable.newFrom({"Death": gdjs.TUTORIALCode.GDDeathObjects1});
gdjs.TUTORIALCode.mapOfGDgdjs_9546TUTORIALCode_9546GDPlayerObjects1Objects = Hashtable.newFrom({"Player": gdjs.TUTORIALCode.GDPlayerObjects1});
gdjs.TUTORIALCode.mapOfGDgdjs_9546TUTORIALCode_9546GDspikeObjects1Objects = Hashtable.newFrom({"spike": gdjs.TUTORIALCode.GDspikeObjects1});
gdjs.TUTORIALCode.eventsList0 = function(runtimeScene) {

{


let isConditionTrue_0 = false;
{
{gdjs.evtTools.camera.setCameraZoom(runtimeScene, 2.5, "", 0);
}
{gdjs.evtTools.camera.setCameraZoom(runtimeScene, 2.5, "Background", 0);
}
}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.runtimeScene.sceneJustBegins(runtimeScene);
if (isConditionTrue_0) {
}

}


{

gdjs.copyArray(runtimeScene.getObjects("Coins"), gdjs.TUTORIALCode.GDCoinsObjects1);
gdjs.copyArray(runtimeScene.getObjects("Player"), gdjs.TUTORIALCode.GDPlayerObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.TUTORIALCode.mapOfGDgdjs_9546TUTORIALCode_9546GDPlayerObjects1Objects, gdjs.TUTORIALCode.mapOfGDgdjs_9546TUTORIALCode_9546GDCoinsObjects1Objects, false, runtimeScene, false);
if (isConditionTrue_0) {
/* Reuse gdjs.TUTORIALCode.GDCoinsObjects1 */
{for(var i = 0, len = gdjs.TUTORIALCode.GDCoinsObjects1.length ;i < len;++i) {
    gdjs.TUTORIALCode.GDCoinsObjects1[i].deleteFromScene(runtimeScene);
}
}
{gdjs.evtTools.sound.playSound(runtimeScene, "Coin.wav", false, 100, 1);
}
}

}


{

gdjs.copyArray(runtimeScene.getObjects("Player"), gdjs.TUTORIALCode.GDPlayerObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.TUTORIALCode.GDPlayerObjects1.length;i<l;++i) {
    if ( gdjs.TUTORIALCode.GDPlayerObjects1[i].getBehavior("PlatformerObject").isOnFloor() ) {
        isConditionTrue_0 = true;
        gdjs.TUTORIALCode.GDPlayerObjects1[k] = gdjs.TUTORIALCode.GDPlayerObjects1[i];
        ++k;
    }
}
gdjs.TUTORIALCode.GDPlayerObjects1.length = k;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.TUTORIALCode.GDPlayerObjects1.length;i<l;++i) {
    if ( !(gdjs.TUTORIALCode.GDPlayerObjects1[i].getBehavior("PlatformerObject").isMovingEvenALittle()) ) {
        isConditionTrue_0 = true;
        gdjs.TUTORIALCode.GDPlayerObjects1[k] = gdjs.TUTORIALCode.GDPlayerObjects1[i];
        ++k;
    }
}
gdjs.TUTORIALCode.GDPlayerObjects1.length = k;
}
if (isConditionTrue_0) {
/* Reuse gdjs.TUTORIALCode.GDPlayerObjects1 */
{for(var i = 0, len = gdjs.TUTORIALCode.GDPlayerObjects1.length ;i < len;++i) {
    gdjs.TUTORIALCode.GDPlayerObjects1[i].getBehavior("Animation").setAnimationName("Idle");
}
}
}

}


{

gdjs.copyArray(runtimeScene.getObjects("Player"), gdjs.TUTORIALCode.GDPlayerObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.TUTORIALCode.GDPlayerObjects1.length;i<l;++i) {
    if ( gdjs.TUTORIALCode.GDPlayerObjects1[i].getBehavior("PlatformerObject").isMovingEvenALittle() ) {
        isConditionTrue_0 = true;
        gdjs.TUTORIALCode.GDPlayerObjects1[k] = gdjs.TUTORIALCode.GDPlayerObjects1[i];
        ++k;
    }
}
gdjs.TUTORIALCode.GDPlayerObjects1.length = k;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.TUTORIALCode.GDPlayerObjects1.length;i<l;++i) {
    if ( gdjs.TUTORIALCode.GDPlayerObjects1[i].getBehavior("PlatformerObject").isOnFloor() ) {
        isConditionTrue_0 = true;
        gdjs.TUTORIALCode.GDPlayerObjects1[k] = gdjs.TUTORIALCode.GDPlayerObjects1[i];
        ++k;
    }
}
gdjs.TUTORIALCode.GDPlayerObjects1.length = k;
}
if (isConditionTrue_0) {
/* Reuse gdjs.TUTORIALCode.GDPlayerObjects1 */
{for(var i = 0, len = gdjs.TUTORIALCode.GDPlayerObjects1.length ;i < len;++i) {
    gdjs.TUTORIALCode.GDPlayerObjects1[i].getBehavior("Animation").setAnimationName("Running");
}
}
}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.isKeyPressed(runtimeScene, "Left");
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("Player"), gdjs.TUTORIALCode.GDPlayerObjects1);
{for(var i = 0, len = gdjs.TUTORIALCode.GDPlayerObjects1.length ;i < len;++i) {
    gdjs.TUTORIALCode.GDPlayerObjects1[i].getBehavior("Flippable").flipX(true);
}
}
}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.isKeyPressed(runtimeScene, "Right");
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("Player"), gdjs.TUTORIALCode.GDPlayerObjects1);
{for(var i = 0, len = gdjs.TUTORIALCode.GDPlayerObjects1.length ;i < len;++i) {
    gdjs.TUTORIALCode.GDPlayerObjects1[i].getBehavior("Flippable").flipX(false);
}
}
}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.isKeyPressed(runtimeScene, "Left");
if (isConditionTrue_0) {
}

}


{


let isConditionTrue_0 = false;
{
}

}


{


let isConditionTrue_0 = false;
{
}

}


{

gdjs.copyArray(runtimeScene.getObjects("NewSprite11"), gdjs.TUTORIALCode.GDNewSprite11Objects1);
gdjs.copyArray(runtimeScene.getObjects("Player"), gdjs.TUTORIALCode.GDPlayerObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.TUTORIALCode.mapOfGDgdjs_9546TUTORIALCode_9546GDPlayerObjects1Objects, gdjs.TUTORIALCode.mapOfGDgdjs_9546TUTORIALCode_9546GDNewSprite11Objects1Objects, false, runtimeScene, false);
if (isConditionTrue_0) {
{gdjs.evtTools.sound.playSound(runtimeScene, "TaDa.wav", false, 100, 1);
}
}

}


{

gdjs.copyArray(runtimeScene.getObjects("Player"), gdjs.TUTORIALCode.GDPlayerObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.TUTORIALCode.GDPlayerObjects1.length;i<l;++i) {
    if ( gdjs.TUTORIALCode.GDPlayerObjects1[i].getBehavior("PlatformerObject").isUsingControl("Left") ) {
        isConditionTrue_0 = true;
        gdjs.TUTORIALCode.GDPlayerObjects1[k] = gdjs.TUTORIALCode.GDPlayerObjects1[i];
        ++k;
    }
}
gdjs.TUTORIALCode.GDPlayerObjects1.length = k;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.TUTORIALCode.GDPlayerObjects1.length;i<l;++i) {
    if ( !(gdjs.TUTORIALCode.GDPlayerObjects1[i].getBehavior("PlatformerObject").isUsingControl("Right")) ) {
        isConditionTrue_0 = true;
        gdjs.TUTORIALCode.GDPlayerObjects1[k] = gdjs.TUTORIALCode.GDPlayerObjects1[i];
        ++k;
    }
}
gdjs.TUTORIALCode.GDPlayerObjects1.length = k;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.TUTORIALCode.GDPlayerObjects1.length;i<l;++i) {
    if ( gdjs.TUTORIALCode.GDPlayerObjects1[i].getBehavior("PlatformerObject").isUsingControl("Left") ) {
        isConditionTrue_0 = true;
        gdjs.TUTORIALCode.GDPlayerObjects1[k] = gdjs.TUTORIALCode.GDPlayerObjects1[i];
        ++k;
    }
}
gdjs.TUTORIALCode.GDPlayerObjects1.length = k;
}
}
if (isConditionTrue_0) {
/* Reuse gdjs.TUTORIALCode.GDPlayerObjects1 */
{for(var i = 0, len = gdjs.TUTORIALCode.GDPlayerObjects1.length ;i < len;++i) {
    gdjs.TUTORIALCode.GDPlayerObjects1[i].getBehavior("Flippable").flipX(false);
}
}
{for(var i = 0, len = gdjs.TUTORIALCode.GDPlayerObjects1.length ;i < len;++i) {
    gdjs.TUTORIALCode.GDPlayerObjects1[i].getBehavior("Flippable").flipX(false);
}
}
{for(var i = 0, len = gdjs.TUTORIALCode.GDPlayerObjects1.length ;i < len;++i) {
    gdjs.TUTORIALCode.GDPlayerObjects1[i].getBehavior("Flippable").flipX(true);
}
}
}

}


{

gdjs.copyArray(runtimeScene.getObjects("Player"), gdjs.TUTORIALCode.GDPlayerObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.TUTORIALCode.GDPlayerObjects1.length;i<l;++i) {
    if ( gdjs.TUTORIALCode.GDPlayerObjects1[i].getBehavior("PlatformerObject").isUsingControl("Right") ) {
        isConditionTrue_0 = true;
        gdjs.TUTORIALCode.GDPlayerObjects1[k] = gdjs.TUTORIALCode.GDPlayerObjects1[i];
        ++k;
    }
}
gdjs.TUTORIALCode.GDPlayerObjects1.length = k;
if (isConditionTrue_0) {
/* Reuse gdjs.TUTORIALCode.GDPlayerObjects1 */
{for(var i = 0, len = gdjs.TUTORIALCode.GDPlayerObjects1.length ;i < len;++i) {
    gdjs.TUTORIALCode.GDPlayerObjects1[i].getBehavior("Flippable").flipX(false);
}
}
}

}


{

gdjs.copyArray(runtimeScene.getObjects("Jump"), gdjs.TUTORIALCode.GDJumpObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.TUTORIALCode.GDJumpObjects1.length;i<l;++i) {
    if ( gdjs.TUTORIALCode.GDJumpObjects1[i].getBehavior("ButtonFSM").IsPressed(null) ) {
        isConditionTrue_0 = true;
        gdjs.TUTORIALCode.GDJumpObjects1[k] = gdjs.TUTORIALCode.GDJumpObjects1[i];
        ++k;
    }
}
gdjs.TUTORIALCode.GDJumpObjects1.length = k;
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("Player"), gdjs.TUTORIALCode.GDPlayerObjects1);
{for(var i = 0, len = gdjs.TUTORIALCode.GDPlayerObjects1.length ;i < len;++i) {
    gdjs.TUTORIALCode.GDPlayerObjects1[i].getBehavior("PlatformerObject").simulateJumpKey();
}
}
}

}


{

gdjs.copyArray(runtimeScene.getObjects("NewSprite4"), gdjs.TUTORIALCode.GDNewSprite4Objects1);
gdjs.copyArray(runtimeScene.getObjects("Player"), gdjs.TUTORIALCode.GDPlayerObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.TUTORIALCode.mapOfGDgdjs_9546TUTORIALCode_9546GDPlayerObjects1Objects, gdjs.TUTORIALCode.mapOfGDgdjs_9546TUTORIALCode_9546GDNewSprite4Objects1Objects, false, runtimeScene, false);
if (isConditionTrue_0) {
/* Reuse gdjs.TUTORIALCode.GDPlayerObjects1 */
{for(var i = 0, len = gdjs.TUTORIALCode.GDPlayerObjects1.length ;i < len;++i) {
    gdjs.TUTORIALCode.GDPlayerObjects1[i].getBehavior("PlatformerObject").simulateRightKey();
}
}
}

}


{

gdjs.copyArray(runtimeScene.getObjects("NewSprite11"), gdjs.TUTORIALCode.GDNewSprite11Objects1);
gdjs.copyArray(runtimeScene.getObjects("Player"), gdjs.TUTORIALCode.GDPlayerObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.TUTORIALCode.mapOfGDgdjs_9546TUTORIALCode_9546GDPlayerObjects1Objects, gdjs.TUTORIALCode.mapOfGDgdjs_9546TUTORIALCode_9546GDNewSprite11Objects1Objects, false, runtimeScene, false);
if (isConditionTrue_0) {
{gdjs.evtTools.runtimeScene.replaceScene(runtimeScene, "1", false);
}
}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.runtimeScene.sceneJustBegins(runtimeScene);
if (isConditionTrue_0) {
{gdjs.evtTools.sound.playMusicOnChannel(runtimeScene, "levelshironew.mp3", 2, true, 100, 1);
}
}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.runtimeScene.sceneJustBegins(runtimeScene);
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("NewSprite10"), gdjs.TUTORIALCode.GDNewSprite10Objects1);
{for(var i = 0, len = gdjs.TUTORIALCode.GDNewSprite10Objects1.length ;i < len;++i) {
    gdjs.TUTORIALCode.GDNewSprite10Objects1[i].hide();
}
}
}

}


{


let isConditionTrue_0 = false;
{
}

}


{

gdjs.copyArray(runtimeScene.getObjects("Player"), gdjs.TUTORIALCode.GDPlayerObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.TUTORIALCode.GDPlayerObjects1.length;i<l;++i) {
    if ( gdjs.TUTORIALCode.GDPlayerObjects1[i].getBehavior("PlatformerObject").isJumping() ) {
        isConditionTrue_0 = true;
        gdjs.TUTORIALCode.GDPlayerObjects1[k] = gdjs.TUTORIALCode.GDPlayerObjects1[i];
        ++k;
    }
}
gdjs.TUTORIALCode.GDPlayerObjects1.length = k;
if (isConditionTrue_0) {
/* Reuse gdjs.TUTORIALCode.GDPlayerObjects1 */
{for(var i = 0, len = gdjs.TUTORIALCode.GDPlayerObjects1.length ;i < len;++i) {
    gdjs.TUTORIALCode.GDPlayerObjects1[i].getBehavior("Animation").setAnimationName("Jumping jacks");
}
}
}

}


{

gdjs.copyArray(runtimeScene.getObjects("Player"), gdjs.TUTORIALCode.GDPlayerObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.TUTORIALCode.GDPlayerObjects1.length;i<l;++i) {
    if ( gdjs.TUTORIALCode.GDPlayerObjects1[i].getBehavior("PlatformerObject").isFalling() ) {
        isConditionTrue_0 = true;
        gdjs.TUTORIALCode.GDPlayerObjects1[k] = gdjs.TUTORIALCode.GDPlayerObjects1[i];
        ++k;
    }
}
gdjs.TUTORIALCode.GDPlayerObjects1.length = k;
if (isConditionTrue_0) {
/* Reuse gdjs.TUTORIALCode.GDPlayerObjects1 */
{for(var i = 0, len = gdjs.TUTORIALCode.GDPlayerObjects1.length ;i < len;++i) {
    gdjs.TUTORIALCode.GDPlayerObjects1[i].getBehavior("Animation").setAnimationName("Fall");
}
}
}

}


{


let isConditionTrue_0 = false;
{
}

}


{

gdjs.copyArray(runtimeScene.getObjects("Pause"), gdjs.TUTORIALCode.GDPauseObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.TUTORIALCode.GDPauseObjects1.length;i<l;++i) {
    if ( gdjs.TUTORIALCode.GDPauseObjects1[i].getBehavior("ButtonFSM").IsPressed(null) ) {
        isConditionTrue_0 = true;
        gdjs.TUTORIALCode.GDPauseObjects1[k] = gdjs.TUTORIALCode.GDPauseObjects1[i];
        ++k;
    }
}
gdjs.TUTORIALCode.GDPauseObjects1.length = k;
if (isConditionTrue_0) {
{gdjs.evtTools.runtimeScene.replaceScene(runtimeScene, "Settings", false);
}
}

}


{

gdjs.copyArray(runtimeScene.getObjects("NewSprite4"), gdjs.TUTORIALCode.GDNewSprite4Objects1);
gdjs.copyArray(runtimeScene.getObjects("Player"), gdjs.TUTORIALCode.GDPlayerObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.TUTORIALCode.mapOfGDgdjs_9546TUTORIALCode_9546GDPlayerObjects1Objects, gdjs.TUTORIALCode.mapOfGDgdjs_9546TUTORIALCode_9546GDNewSprite4Objects1Objects, false, runtimeScene, false);
if (isConditionTrue_0) {
/* Reuse gdjs.TUTORIALCode.GDNewSprite4Objects1 */
{for(var i = 0, len = gdjs.TUTORIALCode.GDNewSprite4Objects1.length ;i < len;++i) {
    gdjs.TUTORIALCode.GDNewSprite4Objects1[i].getBehavior("Animation").setAnimationName("cool");
}
}
}

}


{


let isConditionTrue_0 = false;
{
}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtsExt__Gamepads__C_Axis_pushed.func(runtimeScene, 1, "Left", "Any", null);
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("Jump"), gdjs.TUTORIALCode.GDJumpObjects1);
gdjs.copyArray(runtimeScene.getObjects("ShadedDarkJoystick"), gdjs.TUTORIALCode.GDShadedDarkJoystickObjects1);
{for(var i = 0, len = gdjs.TUTORIALCode.GDShadedDarkJoystickObjects1.length ;i < len;++i) {
    gdjs.TUTORIALCode.GDShadedDarkJoystickObjects1[i].deleteFromScene(runtimeScene);
}
}
{for(var i = 0, len = gdjs.TUTORIALCode.GDJumpObjects1.length ;i < len;++i) {
    gdjs.TUTORIALCode.GDJumpObjects1[i].deleteFromScene(runtimeScene);
}
}
}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.anyKeyPressed(runtimeScene);
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("Jump"), gdjs.TUTORIALCode.GDJumpObjects1);
gdjs.copyArray(runtimeScene.getObjects("ShadedDarkJoystick"), gdjs.TUTORIALCode.GDShadedDarkJoystickObjects1);
{for(var i = 0, len = gdjs.TUTORIALCode.GDShadedDarkJoystickObjects1.length ;i < len;++i) {
    gdjs.TUTORIALCode.GDShadedDarkJoystickObjects1[i].deleteFromScene(runtimeScene);
}
}
{for(var i = 0, len = gdjs.TUTORIALCode.GDJumpObjects1.length ;i < len;++i) {
    gdjs.TUTORIALCode.GDJumpObjects1[i].deleteFromScene(runtimeScene);
}
}
}

}


{

gdjs.copyArray(runtimeScene.getObjects("Player"), gdjs.TUTORIALCode.GDPlayerObjects1);
gdjs.copyArray(runtimeScene.getObjects("spike"), gdjs.TUTORIALCode.GDspikeObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.platform.isOnPlatform(gdjs.TUTORIALCode.mapOfGDgdjs_9546TUTORIALCode_9546GDPlayerObjects1Objects, "PlatformerObject", gdjs.TUTORIALCode.mapOfGDgdjs_9546TUTORIALCode_9546GDspikeObjects1Objects, false);
if (isConditionTrue_0) {
/* Reuse gdjs.TUTORIALCode.GDPlayerObjects1 */
{for(var i = 0, len = gdjs.TUTORIALCode.GDPlayerObjects1.length ;i < len;++i) {
    gdjs.TUTORIALCode.GDPlayerObjects1[i].getBehavior("LinearMovement").SetSpeedY(-200, null);
}
}
}

}


{

gdjs.copyArray(runtimeScene.getObjects("Player"), gdjs.TUTORIALCode.GDPlayerObjects1);
gdjs.copyArray(runtimeScene.getObjects("spike"), gdjs.TUTORIALCode.GDspikeObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.platform.isOnPlatform(gdjs.TUTORIALCode.mapOfGDgdjs_9546TUTORIALCode_9546GDPlayerObjects1Objects, "PlatformerObject", gdjs.TUTORIALCode.mapOfGDgdjs_9546TUTORIALCode_9546GDspikeObjects1Objects, false);
if (isConditionTrue_0) {
/* Reuse gdjs.TUTORIALCode.GDPlayerObjects1 */
{for(var i = 0, len = gdjs.TUTORIALCode.GDPlayerObjects1.length ;i < len;++i) {
    gdjs.TUTORIALCode.GDPlayerObjects1[i].getBehavior("LinearMovement").SetSpeedX(-100, null);
}
}
}

}


{

gdjs.copyArray(runtimeScene.getObjects("Platform_Ground"), gdjs.TUTORIALCode.GDPlatform_9595GroundObjects1);
gdjs.copyArray(runtimeScene.getObjects("Player"), gdjs.TUTORIALCode.GDPlayerObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.platform.isOnPlatform(gdjs.TUTORIALCode.mapOfGDgdjs_9546TUTORIALCode_9546GDPlayerObjects1Objects, "PlatformerObject", gdjs.TUTORIALCode.mapOfGDgdjs_9546TUTORIALCode_9546GDPlatform_95959595GroundObjects1Objects, false);
if (isConditionTrue_0) {
/* Reuse gdjs.TUTORIALCode.GDPlayerObjects1 */
{for(var i = 0, len = gdjs.TUTORIALCode.GDPlayerObjects1.length ;i < len;++i) {
    gdjs.TUTORIALCode.GDPlayerObjects1[i].getBehavior("LinearMovement").SetSpeedX(0, null);
}
}
}

}


{


let isConditionTrue_0 = false;
{
}

}


{

gdjs.copyArray(runtimeScene.getObjects("Platform_Ground"), gdjs.TUTORIALCode.GDPlatform_9595GroundObjects1);
gdjs.copyArray(runtimeScene.getObjects("Player"), gdjs.TUTORIALCode.GDPlayerObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.platform.isOnPlatform(gdjs.TUTORIALCode.mapOfGDgdjs_9546TUTORIALCode_9546GDPlayerObjects1Objects, "PlatformerObject", gdjs.TUTORIALCode.mapOfGDgdjs_9546TUTORIALCode_9546GDPlatform_95959595GroundObjects1Objects, false);
if (isConditionTrue_0) {
/* Reuse gdjs.TUTORIALCode.GDPlayerObjects1 */
{for(var i = 0, len = gdjs.TUTORIALCode.GDPlayerObjects1.length ;i < len;++i) {
    gdjs.TUTORIALCode.GDPlayerObjects1[i].getBehavior("LinearMovement").SetSpeedY(0, null);
}
}
}

}


{

gdjs.copyArray(runtimeScene.getObjects("Player"), gdjs.TUTORIALCode.GDPlayerObjects1);
gdjs.copyArray(runtimeScene.getObjects("spike"), gdjs.TUTORIALCode.GDspikeObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.TUTORIALCode.mapOfGDgdjs_9546TUTORIALCode_9546GDPlayerObjects1Objects, gdjs.TUTORIALCode.mapOfGDgdjs_9546TUTORIALCode_9546GDspikeObjects1Objects, false, runtimeScene, false);
if (isConditionTrue_0) {
/* Reuse gdjs.TUTORIALCode.GDPlayerObjects1 */
{for(var i = 0, len = gdjs.TUTORIALCode.GDPlayerObjects1.length ;i < len;++i) {
    gdjs.TUTORIALCode.GDPlayerObjects1[i].getBehavior("Animation").setAnimationName("Die");
}
}
}

}


{


let isConditionTrue_0 = false;
{
}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.runtimeScene.sceneJustBegins(runtimeScene);
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("Loadanim"), gdjs.TUTORIALCode.GDLoadanimObjects1);
{for(var i = 0, len = gdjs.TUTORIALCode.GDLoadanimObjects1.length ;i < len;++i) {
    gdjs.TUTORIALCode.GDLoadanimObjects1[i].hide();
}
}
}

}


{

gdjs.copyArray(runtimeScene.getObjects("NewSprite14"), gdjs.TUTORIALCode.GDNewSprite14Objects1);
gdjs.copyArray(runtimeScene.getObjects("Player"), gdjs.TUTORIALCode.GDPlayerObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.TUTORIALCode.mapOfGDgdjs_9546TUTORIALCode_9546GDPlayerObjects1Objects, gdjs.TUTORIALCode.mapOfGDgdjs_9546TUTORIALCode_9546GDNewSprite14Objects1Objects, false, runtimeScene, false);
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("Loadanim"), gdjs.TUTORIALCode.GDLoadanimObjects1);
{for(var i = 0, len = gdjs.TUTORIALCode.GDLoadanimObjects1.length ;i < len;++i) {
    gdjs.TUTORIALCode.GDLoadanimObjects1[i].hide(false);
}
}
}

}


{

gdjs.copyArray(runtimeScene.getObjects("NewSprite15"), gdjs.TUTORIALCode.GDNewSprite15Objects1);
gdjs.copyArray(runtimeScene.getObjects("Player"), gdjs.TUTORIALCode.GDPlayerObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.TUTORIALCode.mapOfGDgdjs_9546TUTORIALCode_9546GDPlayerObjects1Objects, gdjs.TUTORIALCode.mapOfGDgdjs_9546TUTORIALCode_9546GDNewSprite15Objects1Objects, false, runtimeScene, false);
if (isConditionTrue_0) {
{gdjs.evtTools.runtimeScene.replaceScene(runtimeScene, "TUTORIAL", false);
}
}

}


{


let isConditionTrue_0 = false;
{
}

}


{

gdjs.copyArray(runtimeScene.getObjects("Player"), gdjs.TUTORIALCode.GDPlayerObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.TUTORIALCode.GDPlayerObjects1.length;i<l;++i) {
    if ( gdjs.TUTORIALCode.GDPlayerObjects1[i].getAnimationFrame() == 1 ) {
        isConditionTrue_0 = true;
        gdjs.TUTORIALCode.GDPlayerObjects1[k] = gdjs.TUTORIALCode.GDPlayerObjects1[i];
        ++k;
    }
}
gdjs.TUTORIALCode.GDPlayerObjects1.length = k;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.TUTORIALCode.GDPlayerObjects1.length;i<l;++i) {
    if ( gdjs.TUTORIALCode.GDPlayerObjects1[i].getBehavior("Animation").getAnimationName() == "Jumping jacks" ) {
        isConditionTrue_0 = true;
        gdjs.TUTORIALCode.GDPlayerObjects1[k] = gdjs.TUTORIALCode.GDPlayerObjects1[i];
        ++k;
    }
}
gdjs.TUTORIALCode.GDPlayerObjects1.length = k;
}
if (isConditionTrue_0) {
{gdjs.evtTools.sound.playSoundOnChannel(runtimeScene, "Jumbin.wav", 11, false, 100, 1);
}
}

}


{


let isConditionTrue_0 = false;
{
}

}


{

gdjs.copyArray(runtimeScene.getObjects("Player"), gdjs.TUTORIALCode.GDPlayerObjects1);
gdjs.copyArray(runtimeScene.getObjects("spike"), gdjs.TUTORIALCode.GDspikeObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.TUTORIALCode.mapOfGDgdjs_9546TUTORIALCode_9546GDPlayerObjects1Objects, gdjs.TUTORIALCode.mapOfGDgdjs_9546TUTORIALCode_9546GDspikeObjects1Objects, false, runtimeScene, false);
if (isConditionTrue_0) {
/* Reuse gdjs.TUTORIALCode.GDPlayerObjects1 */
{for(var i = 0, len = gdjs.TUTORIALCode.GDPlayerObjects1.length ;i < len;++i) {
    gdjs.TUTORIALCode.GDPlayerObjects1[i].getBehavior("SmoothCamera").SetUpwardSpeed(0, null);
}
}
{for(var i = 0, len = gdjs.TUTORIALCode.GDPlayerObjects1.length ;i < len;++i) {
    gdjs.TUTORIALCode.GDPlayerObjects1[i].getBehavior("SmoothCamera").SetLeftwardSpeed(0, null);
}
}
{for(var i = 0, len = gdjs.TUTORIALCode.GDPlayerObjects1.length ;i < len;++i) {
    gdjs.TUTORIALCode.GDPlayerObjects1[i].getBehavior("SmoothCamera").SetDownwardSpeedMax(0, null);
}
}
}

}


{

gdjs.copyArray(runtimeScene.getObjects("Player"), gdjs.TUTORIALCode.GDPlayerObjects1);
gdjs.copyArray(runtimeScene.getObjects("spike"), gdjs.TUTORIALCode.GDspikeObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.TUTORIALCode.mapOfGDgdjs_9546TUTORIALCode_9546GDPlayerObjects1Objects, gdjs.TUTORIALCode.mapOfGDgdjs_9546TUTORIALCode_9546GDspikeObjects1Objects, false, runtimeScene, false);
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("NewSprite7"), gdjs.TUTORIALCode.GDNewSprite7Objects1);
gdjs.copyArray(runtimeScene.getObjects("Platform_Ground"), gdjs.TUTORIALCode.GDPlatform_9595GroundObjects1);
{for(var i = 0, len = gdjs.TUTORIALCode.GDPlatform_9595GroundObjects1.length ;i < len;++i) {
    gdjs.TUTORIALCode.GDPlatform_9595GroundObjects1[i].activateBehavior("Platform", false);
}
}
{for(var i = 0, len = gdjs.TUTORIALCode.GDNewSprite7Objects1.length ;i < len;++i) {
    gdjs.TUTORIALCode.GDNewSprite7Objects1[i].activateBehavior("Platform", false);
}
}
}

}


{

gdjs.copyArray(runtimeScene.getObjects("Death"), gdjs.TUTORIALCode.GDDeathObjects1);
gdjs.copyArray(runtimeScene.getObjects("Player"), gdjs.TUTORIALCode.GDPlayerObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.TUTORIALCode.mapOfGDgdjs_9546TUTORIALCode_9546GDPlayerObjects1Objects, gdjs.TUTORIALCode.mapOfGDgdjs_9546TUTORIALCode_9546GDDeathObjects1Objects, false, runtimeScene, false);
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("NewSprite10"), gdjs.TUTORIALCode.GDNewSprite10Objects1);
{for(var i = 0, len = gdjs.TUTORIALCode.GDNewSprite10Objects1.length ;i < len;++i) {
    gdjs.TUTORIALCode.GDNewSprite10Objects1[i].hide(false);
}
}
}

}


{

gdjs.copyArray(runtimeScene.getObjects("Player"), gdjs.TUTORIALCode.GDPlayerObjects1);
gdjs.copyArray(runtimeScene.getObjects("menublock"), gdjs.TUTORIALCode.GDmenublockObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.TUTORIALCode.mapOfGDgdjs_9546TUTORIALCode_9546GDPlayerObjects1Objects, gdjs.TUTORIALCode.mapOfGDgdjs_9546TUTORIALCode_9546GDmenublockObjects1Objects, false, runtimeScene, false);
if (isConditionTrue_0) {
{gdjs.evtTools.runtimeScene.replaceScene(runtimeScene, "TUTORIAL", false);
}
}

}


{

gdjs.copyArray(runtimeScene.getObjects("NewSprite10"), gdjs.TUTORIALCode.GDNewSprite10Objects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.TUTORIALCode.GDNewSprite10Objects1.length;i<l;++i) {
    if ( gdjs.TUTORIALCode.GDNewSprite10Objects1[i].isVisible() ) {
        isConditionTrue_0 = true;
        gdjs.TUTORIALCode.GDNewSprite10Objects1[k] = gdjs.TUTORIALCode.GDNewSprite10Objects1[i];
        ++k;
    }
}
gdjs.TUTORIALCode.GDNewSprite10Objects1.length = k;
if (isConditionTrue_0) {
{gdjs.evtTools.sound.playSoundOnChannel(runtimeScene, "oof.mp3", 16, false, 50, 1);
}
}

}


{

gdjs.copyArray(runtimeScene.getObjects("Death"), gdjs.TUTORIALCode.GDDeathObjects1);
gdjs.copyArray(runtimeScene.getObjects("Player"), gdjs.TUTORIALCode.GDPlayerObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.TUTORIALCode.mapOfGDgdjs_9546TUTORIALCode_9546GDPlayerObjects1Objects, gdjs.TUTORIALCode.mapOfGDgdjs_9546TUTORIALCode_9546GDDeathObjects1Objects, false, runtimeScene, false);
if (isConditionTrue_0) {
/* Reuse gdjs.TUTORIALCode.GDPlayerObjects1 */
{for(var i = 0, len = gdjs.TUTORIALCode.GDPlayerObjects1.length ;i < len;++i) {
    gdjs.TUTORIALCode.GDPlayerObjects1[i].getBehavior("Animation").setAnimationName("Die");
}
}
{for(var i = 0, len = gdjs.TUTORIALCode.GDPlayerObjects1.length ;i < len;++i) {
    gdjs.TUTORIALCode.GDPlayerObjects1[i].getBehavior("Animation").pauseAnimation();
}
}
}

}


{

gdjs.copyArray(runtimeScene.getObjects("Death"), gdjs.TUTORIALCode.GDDeathObjects1);
gdjs.copyArray(runtimeScene.getObjects("Player"), gdjs.TUTORIALCode.GDPlayerObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.TUTORIALCode.mapOfGDgdjs_9546TUTORIALCode_9546GDPlayerObjects1Objects, gdjs.TUTORIALCode.mapOfGDgdjs_9546TUTORIALCode_9546GDDeathObjects1Objects, false, runtimeScene, false);
if (isConditionTrue_0) {
{gdjs.evtTools.sound.stopMusicOnChannel(runtimeScene, 2);
}
}

}


{

gdjs.copyArray(runtimeScene.getObjects("Player"), gdjs.TUTORIALCode.GDPlayerObjects1);
gdjs.copyArray(runtimeScene.getObjects("spike"), gdjs.TUTORIALCode.GDspikeObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.TUTORIALCode.mapOfGDgdjs_9546TUTORIALCode_9546GDPlayerObjects1Objects, gdjs.TUTORIALCode.mapOfGDgdjs_9546TUTORIALCode_9546GDspikeObjects1Objects, false, runtimeScene, false);
if (isConditionTrue_0) {
/* Reuse gdjs.TUTORIALCode.GDPlayerObjects1 */
{for(var i = 0, len = gdjs.TUTORIALCode.GDPlayerObjects1.length ;i < len;++i) {
    gdjs.TUTORIALCode.GDPlayerObjects1[i].getBehavior("PlatformerObject").ignoreDefaultControls(true);
}
}
}

}


};

gdjs.TUTORIALCode.func = function(runtimeScene) {
runtimeScene.getOnceTriggers().startNewFrame();

gdjs.TUTORIALCode.GDPlayerObjects1.length = 0;
gdjs.TUTORIALCode.GDPlayerObjects2.length = 0;
gdjs.TUTORIALCode.GDCoinsObjects1.length = 0;
gdjs.TUTORIALCode.GDCoinsObjects2.length = 0;
gdjs.TUTORIALCode.GDPlatform_9595GroundObjects1.length = 0;
gdjs.TUTORIALCode.GDPlatform_9595GroundObjects2.length = 0;
gdjs.TUTORIALCode.GDNewSprite4Objects1.length = 0;
gdjs.TUTORIALCode.GDNewSprite4Objects2.length = 0;
gdjs.TUTORIALCode.GDNewSprite5Objects1.length = 0;
gdjs.TUTORIALCode.GDNewSprite5Objects2.length = 0;
gdjs.TUTORIALCode.GDNewSprite6Objects1.length = 0;
gdjs.TUTORIALCode.GDNewSprite6Objects2.length = 0;
gdjs.TUTORIALCode.GDspikeObjects1.length = 0;
gdjs.TUTORIALCode.GDspikeObjects2.length = 0;
gdjs.TUTORIALCode.GDNewSprite7Objects1.length = 0;
gdjs.TUTORIALCode.GDNewSprite7Objects2.length = 0;
gdjs.TUTORIALCode.GDNewSprite8Objects1.length = 0;
gdjs.TUTORIALCode.GDNewSprite8Objects2.length = 0;
gdjs.TUTORIALCode.GDNewSprite3Objects1.length = 0;
gdjs.TUTORIALCode.GDNewSprite3Objects2.length = 0;
gdjs.TUTORIALCode.GDpipeObjects1.length = 0;
gdjs.TUTORIALCode.GDpipeObjects2.length = 0;
gdjs.TUTORIALCode.GDStacyObjects1.length = 0;
gdjs.TUTORIALCode.GDStacyObjects2.length = 0;
gdjs.TUTORIALCode.GDShadedDarkJoystickObjects1.length = 0;
gdjs.TUTORIALCode.GDShadedDarkJoystickObjects2.length = 0;
gdjs.TUTORIALCode.GDNewSpriteObjects1.length = 0;
gdjs.TUTORIALCode.GDNewSpriteObjects2.length = 0;
gdjs.TUTORIALCode.GDNewSprite9Objects1.length = 0;
gdjs.TUTORIALCode.GDNewSprite9Objects2.length = 0;
gdjs.TUTORIALCode.GDMountain_9595dewObjects1.length = 0;
gdjs.TUTORIALCode.GDMountain_9595dewObjects2.length = 0;
gdjs.TUTORIALCode.GDNewSprite10Objects1.length = 0;
gdjs.TUTORIALCode.GDNewSprite10Objects2.length = 0;
gdjs.TUTORIALCode.GDJumpObjects1.length = 0;
gdjs.TUTORIALCode.GDJumpObjects2.length = 0;
gdjs.TUTORIALCode.GDTreeObjects1.length = 0;
gdjs.TUTORIALCode.GDTreeObjects2.length = 0;
gdjs.TUTORIALCode.GDPauseObjects1.length = 0;
gdjs.TUTORIALCode.GDPauseObjects2.length = 0;
gdjs.TUTORIALCode.GDNewTextObjects1.length = 0;
gdjs.TUTORIALCode.GDNewTextObjects2.length = 0;
gdjs.TUTORIALCode.GDNewSprite2Objects1.length = 0;
gdjs.TUTORIALCode.GDNewSprite2Objects2.length = 0;
gdjs.TUTORIALCode.GDNewSprite11Objects1.length = 0;
gdjs.TUTORIALCode.GDNewSprite11Objects2.length = 0;
gdjs.TUTORIALCode.GDNewSprite12Objects1.length = 0;
gdjs.TUTORIALCode.GDNewSprite12Objects2.length = 0;
gdjs.TUTORIALCode.GDNewSprite13Objects1.length = 0;
gdjs.TUTORIALCode.GDNewSprite13Objects2.length = 0;
gdjs.TUTORIALCode.GDspikenotvisiObjects1.length = 0;
gdjs.TUTORIALCode.GDspikenotvisiObjects2.length = 0;
gdjs.TUTORIALCode.GDBoomObjects1.length = 0;
gdjs.TUTORIALCode.GDBoomObjects2.length = 0;
gdjs.TUTORIALCode.GDNew3DBoxObjects1.length = 0;
gdjs.TUTORIALCode.GDNew3DBoxObjects2.length = 0;
gdjs.TUTORIALCode.GDLoadanimObjects1.length = 0;
gdjs.TUTORIALCode.GDLoadanimObjects2.length = 0;
gdjs.TUTORIALCode.GDNewSprite14Objects1.length = 0;
gdjs.TUTORIALCode.GDNewSprite14Objects2.length = 0;
gdjs.TUTORIALCode.GDBushesObjects1.length = 0;
gdjs.TUTORIALCode.GDBushesObjects2.length = 0;
gdjs.TUTORIALCode.GDNewSprite15Objects1.length = 0;
gdjs.TUTORIALCode.GDNewSprite15Objects2.length = 0;
gdjs.TUTORIALCode.GDSurpsObjects1.length = 0;
gdjs.TUTORIALCode.GDSurpsObjects2.length = 0;
gdjs.TUTORIALCode.GDNewSprite16Objects1.length = 0;
gdjs.TUTORIALCode.GDNewSprite16Objects2.length = 0;
gdjs.TUTORIALCode.GDDeathObjects1.length = 0;
gdjs.TUTORIALCode.GDDeathObjects2.length = 0;
gdjs.TUTORIALCode.GDmenublockObjects1.length = 0;
gdjs.TUTORIALCode.GDmenublockObjects2.length = 0;
gdjs.TUTORIALCode.GDTutorialObjects1.length = 0;
gdjs.TUTORIALCode.GDTutorialObjects2.length = 0;
gdjs.TUTORIALCode.GDNewText2Objects1.length = 0;
gdjs.TUTORIALCode.GDNewText2Objects2.length = 0;
gdjs.TUTORIALCode.GDNewText3Objects1.length = 0;
gdjs.TUTORIALCode.GDNewText3Objects2.length = 0;
gdjs.TUTORIALCode.GDNewText4Objects1.length = 0;
gdjs.TUTORIALCode.GDNewText4Objects2.length = 0;

gdjs.TUTORIALCode.eventsList0(runtimeScene);
gdjs.TUTORIALCode.GDPlayerObjects1.length = 0;
gdjs.TUTORIALCode.GDPlayerObjects2.length = 0;
gdjs.TUTORIALCode.GDCoinsObjects1.length = 0;
gdjs.TUTORIALCode.GDCoinsObjects2.length = 0;
gdjs.TUTORIALCode.GDPlatform_9595GroundObjects1.length = 0;
gdjs.TUTORIALCode.GDPlatform_9595GroundObjects2.length = 0;
gdjs.TUTORIALCode.GDNewSprite4Objects1.length = 0;
gdjs.TUTORIALCode.GDNewSprite4Objects2.length = 0;
gdjs.TUTORIALCode.GDNewSprite5Objects1.length = 0;
gdjs.TUTORIALCode.GDNewSprite5Objects2.length = 0;
gdjs.TUTORIALCode.GDNewSprite6Objects1.length = 0;
gdjs.TUTORIALCode.GDNewSprite6Objects2.length = 0;
gdjs.TUTORIALCode.GDspikeObjects1.length = 0;
gdjs.TUTORIALCode.GDspikeObjects2.length = 0;
gdjs.TUTORIALCode.GDNewSprite7Objects1.length = 0;
gdjs.TUTORIALCode.GDNewSprite7Objects2.length = 0;
gdjs.TUTORIALCode.GDNewSprite8Objects1.length = 0;
gdjs.TUTORIALCode.GDNewSprite8Objects2.length = 0;
gdjs.TUTORIALCode.GDNewSprite3Objects1.length = 0;
gdjs.TUTORIALCode.GDNewSprite3Objects2.length = 0;
gdjs.TUTORIALCode.GDpipeObjects1.length = 0;
gdjs.TUTORIALCode.GDpipeObjects2.length = 0;
gdjs.TUTORIALCode.GDStacyObjects1.length = 0;
gdjs.TUTORIALCode.GDStacyObjects2.length = 0;
gdjs.TUTORIALCode.GDShadedDarkJoystickObjects1.length = 0;
gdjs.TUTORIALCode.GDShadedDarkJoystickObjects2.length = 0;
gdjs.TUTORIALCode.GDNewSpriteObjects1.length = 0;
gdjs.TUTORIALCode.GDNewSpriteObjects2.length = 0;
gdjs.TUTORIALCode.GDNewSprite9Objects1.length = 0;
gdjs.TUTORIALCode.GDNewSprite9Objects2.length = 0;
gdjs.TUTORIALCode.GDMountain_9595dewObjects1.length = 0;
gdjs.TUTORIALCode.GDMountain_9595dewObjects2.length = 0;
gdjs.TUTORIALCode.GDNewSprite10Objects1.length = 0;
gdjs.TUTORIALCode.GDNewSprite10Objects2.length = 0;
gdjs.TUTORIALCode.GDJumpObjects1.length = 0;
gdjs.TUTORIALCode.GDJumpObjects2.length = 0;
gdjs.TUTORIALCode.GDTreeObjects1.length = 0;
gdjs.TUTORIALCode.GDTreeObjects2.length = 0;
gdjs.TUTORIALCode.GDPauseObjects1.length = 0;
gdjs.TUTORIALCode.GDPauseObjects2.length = 0;
gdjs.TUTORIALCode.GDNewTextObjects1.length = 0;
gdjs.TUTORIALCode.GDNewTextObjects2.length = 0;
gdjs.TUTORIALCode.GDNewSprite2Objects1.length = 0;
gdjs.TUTORIALCode.GDNewSprite2Objects2.length = 0;
gdjs.TUTORIALCode.GDNewSprite11Objects1.length = 0;
gdjs.TUTORIALCode.GDNewSprite11Objects2.length = 0;
gdjs.TUTORIALCode.GDNewSprite12Objects1.length = 0;
gdjs.TUTORIALCode.GDNewSprite12Objects2.length = 0;
gdjs.TUTORIALCode.GDNewSprite13Objects1.length = 0;
gdjs.TUTORIALCode.GDNewSprite13Objects2.length = 0;
gdjs.TUTORIALCode.GDspikenotvisiObjects1.length = 0;
gdjs.TUTORIALCode.GDspikenotvisiObjects2.length = 0;
gdjs.TUTORIALCode.GDBoomObjects1.length = 0;
gdjs.TUTORIALCode.GDBoomObjects2.length = 0;
gdjs.TUTORIALCode.GDNew3DBoxObjects1.length = 0;
gdjs.TUTORIALCode.GDNew3DBoxObjects2.length = 0;
gdjs.TUTORIALCode.GDLoadanimObjects1.length = 0;
gdjs.TUTORIALCode.GDLoadanimObjects2.length = 0;
gdjs.TUTORIALCode.GDNewSprite14Objects1.length = 0;
gdjs.TUTORIALCode.GDNewSprite14Objects2.length = 0;
gdjs.TUTORIALCode.GDBushesObjects1.length = 0;
gdjs.TUTORIALCode.GDBushesObjects2.length = 0;
gdjs.TUTORIALCode.GDNewSprite15Objects1.length = 0;
gdjs.TUTORIALCode.GDNewSprite15Objects2.length = 0;
gdjs.TUTORIALCode.GDSurpsObjects1.length = 0;
gdjs.TUTORIALCode.GDSurpsObjects2.length = 0;
gdjs.TUTORIALCode.GDNewSprite16Objects1.length = 0;
gdjs.TUTORIALCode.GDNewSprite16Objects2.length = 0;
gdjs.TUTORIALCode.GDDeathObjects1.length = 0;
gdjs.TUTORIALCode.GDDeathObjects2.length = 0;
gdjs.TUTORIALCode.GDmenublockObjects1.length = 0;
gdjs.TUTORIALCode.GDmenublockObjects2.length = 0;
gdjs.TUTORIALCode.GDTutorialObjects1.length = 0;
gdjs.TUTORIALCode.GDTutorialObjects2.length = 0;
gdjs.TUTORIALCode.GDNewText2Objects1.length = 0;
gdjs.TUTORIALCode.GDNewText2Objects2.length = 0;
gdjs.TUTORIALCode.GDNewText3Objects1.length = 0;
gdjs.TUTORIALCode.GDNewText3Objects2.length = 0;
gdjs.TUTORIALCode.GDNewText4Objects1.length = 0;
gdjs.TUTORIALCode.GDNewText4Objects2.length = 0;


return;

}

gdjs['TUTORIALCode'] = gdjs.TUTORIALCode;
