gdjs.DemoENDCode = {};
gdjs.DemoENDCode.localVariables = [];
gdjs.DemoENDCode.idToCallbackMap = new Map();
gdjs.DemoENDCode.GDLOGOObjects1= [];
gdjs.DemoENDCode.GDLOGOObjects2= [];
gdjs.DemoENDCode.GDNew3DBoxObjects1= [];
gdjs.DemoENDCode.GDNew3DBoxObjects2= [];
gdjs.DemoENDCode.GDNewTiledSpriteObjects1= [];
gdjs.DemoENDCode.GDNewTiledSpriteObjects2= [];
gdjs.DemoENDCode.GDCreditsObjects1= [];
gdjs.DemoENDCode.GDCreditsObjects2= [];
gdjs.DemoENDCode.GDshirotitleObjects1= [];
gdjs.DemoENDCode.GDshirotitleObjects2= [];
gdjs.DemoENDCode.GDNewSpriteObjects1= [];
gdjs.DemoENDCode.GDNewSpriteObjects2= [];
gdjs.DemoENDCode.GDNewSprite2Objects1= [];
gdjs.DemoENDCode.GDNewSprite2Objects2= [];
gdjs.DemoENDCode.GDNewSprite3Objects1= [];
gdjs.DemoENDCode.GDNewSprite3Objects2= [];
gdjs.DemoENDCode.GDNewSprite4Objects1= [];
gdjs.DemoENDCode.GDNewSprite4Objects2= [];
gdjs.DemoENDCode.GDStart_9595GameObjects1= [];
gdjs.DemoENDCode.GDStart_9595GameObjects2= [];
gdjs.DemoENDCode.GDpressObjects1= [];
gdjs.DemoENDCode.GDpressObjects2= [];
gdjs.DemoENDCode.GDDemoendtextObjects1= [];
gdjs.DemoENDCode.GDDemoendtextObjects2= [];
gdjs.DemoENDCode.GDThingObjects1= [];
gdjs.DemoENDCode.GDThingObjects2= [];
gdjs.DemoENDCode.GDMOuseclickObjects1= [];
gdjs.DemoENDCode.GDMOuseclickObjects2= [];


gdjs.DemoENDCode.mapOfGDgdjs_9546DemoENDCode_9546GDNewSprite2Objects1Objects = Hashtable.newFrom({"NewSprite2": gdjs.DemoENDCode.GDNewSprite2Objects1});
gdjs.DemoENDCode.eventsList0 = function(runtimeScene) {

{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.runtimeScene.sceneJustBegins(runtimeScene);
if (isConditionTrue_0) {
{gdjs.evtTools.sound.playMusicOnChannel(runtimeScene, "Drums.mp3", 4, true, 100, 1);
}
}

}


{

gdjs.copyArray(runtimeScene.getObjects("Start_Game"), gdjs.DemoENDCode.GDStart_9595GameObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.DemoENDCode.GDStart_9595GameObjects1.length;i<l;++i) {
    if ( gdjs.DemoENDCode.GDStart_9595GameObjects1[i].getBehavior("ButtonFSM").IsPressed(null) ) {
        isConditionTrue_0 = true;
        gdjs.DemoENDCode.GDStart_9595GameObjects1[k] = gdjs.DemoENDCode.GDStart_9595GameObjects1[i];
        ++k;
    }
}
gdjs.DemoENDCode.GDStart_9595GameObjects1.length = k;
if (isConditionTrue_0) {
{gdjs.evtTools.runtimeScene.replaceScene(runtimeScene, "1", false);
}
{gdjs.evtTools.sound.stopMusicOnChannel(runtimeScene, 4);
}
{gdjs.evtTools.sound.playMusicOnChannel(runtimeScene, "SELECT.mp3", 5, false, 100, 1);
}
}

}


{

gdjs.copyArray(runtimeScene.getObjects("NewSprite2"), gdjs.DemoENDCode.GDNewSprite2Objects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.cursorOnObject(gdjs.DemoENDCode.mapOfGDgdjs_9546DemoENDCode_9546GDNewSprite2Objects1Objects, runtimeScene, true, false);
if (isConditionTrue_0) {
{gdjs.evtTools.runtimeScene.replaceScene(runtimeScene, "Title screen", false);
}
}

}


{

gdjs.copyArray(runtimeScene.getObjects("Start_Game"), gdjs.DemoENDCode.GDStart_9595GameObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.DemoENDCode.GDStart_9595GameObjects1.length;i<l;++i) {
    if ( gdjs.DemoENDCode.GDStart_9595GameObjects1[i].getBehavior("ButtonFSM").IsHovered(null) ) {
        isConditionTrue_0 = true;
        gdjs.DemoENDCode.GDStart_9595GameObjects1[k] = gdjs.DemoENDCode.GDStart_9595GameObjects1[i];
        ++k;
    }
}
gdjs.DemoENDCode.GDStart_9595GameObjects1.length = k;
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("shirotitle"), gdjs.DemoENDCode.GDshirotitleObjects1);
{for(var i = 0, len = gdjs.DemoENDCode.GDshirotitleObjects1.length ;i < len;++i) {
    gdjs.DemoENDCode.GDshirotitleObjects1[i].getBehavior("Animation").setAnimationName("shirohappy");
}
}
}

}


{

gdjs.copyArray(runtimeScene.getObjects("Start_Game"), gdjs.DemoENDCode.GDStart_9595GameObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.DemoENDCode.GDStart_9595GameObjects1.length;i<l;++i) {
    if ( gdjs.DemoENDCode.GDStart_9595GameObjects1[i].getBehavior("ButtonFSM").IsIdle(null) ) {
        isConditionTrue_0 = true;
        gdjs.DemoENDCode.GDStart_9595GameObjects1[k] = gdjs.DemoENDCode.GDStart_9595GameObjects1[i];
        ++k;
    }
}
gdjs.DemoENDCode.GDStart_9595GameObjects1.length = k;
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("shirotitle"), gdjs.DemoENDCode.GDshirotitleObjects1);
{for(var i = 0, len = gdjs.DemoENDCode.GDshirotitleObjects1.length ;i < len;++i) {
    gdjs.DemoENDCode.GDshirotitleObjects1[i].getBehavior("Animation").setAnimationName("NewSprite");
}
}
}

}


{

gdjs.copyArray(runtimeScene.getObjects("press"), gdjs.DemoENDCode.GDpressObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.DemoENDCode.GDpressObjects1.length;i<l;++i) {
    if ( gdjs.DemoENDCode.GDpressObjects1[i].getBehavior("ButtonFSM").IsHovered(null) ) {
        isConditionTrue_0 = true;
        gdjs.DemoENDCode.GDpressObjects1[k] = gdjs.DemoENDCode.GDpressObjects1[i];
        ++k;
    }
}
gdjs.DemoENDCode.GDpressObjects1.length = k;
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("shirotitle"), gdjs.DemoENDCode.GDshirotitleObjects1);
{for(var i = 0, len = gdjs.DemoENDCode.GDshirotitleObjects1.length ;i < len;++i) {
    gdjs.DemoENDCode.GDshirotitleObjects1[i].getBehavior("Animation").setAnimationName("shirohappy");
}
}
}

}


{

gdjs.copyArray(runtimeScene.getObjects("press"), gdjs.DemoENDCode.GDpressObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.DemoENDCode.GDpressObjects1.length;i<l;++i) {
    if ( gdjs.DemoENDCode.GDpressObjects1[i].getBehavior("ButtonFSM").IsIdle(null) ) {
        isConditionTrue_0 = true;
        gdjs.DemoENDCode.GDpressObjects1[k] = gdjs.DemoENDCode.GDpressObjects1[i];
        ++k;
    }
}
gdjs.DemoENDCode.GDpressObjects1.length = k;
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("shirotitle"), gdjs.DemoENDCode.GDshirotitleObjects1);
{for(var i = 0, len = gdjs.DemoENDCode.GDshirotitleObjects1.length ;i < len;++i) {
    gdjs.DemoENDCode.GDshirotitleObjects1[i].getBehavior("Animation").setAnimationName("NewSprite");
}
}
}

}


{

gdjs.copyArray(runtimeScene.getObjects("press"), gdjs.DemoENDCode.GDpressObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.DemoENDCode.GDpressObjects1.length;i<l;++i) {
    if ( gdjs.DemoENDCode.GDpressObjects1[i].getBehavior("ButtonFSM").IsPressed(null) ) {
        isConditionTrue_0 = true;
        gdjs.DemoENDCode.GDpressObjects1[k] = gdjs.DemoENDCode.GDpressObjects1[i];
        ++k;
    }
}
gdjs.DemoENDCode.GDpressObjects1.length = k;
if (isConditionTrue_0) {
{gdjs.evtTools.runtimeScene.replaceScene(runtimeScene, "VS Zone", false);
}
{gdjs.evtTools.sound.stopMusicOnChannel(runtimeScene, 4);
}
{gdjs.evtTools.sound.playMusicOnChannel(runtimeScene, "SELECT.mp3", 5, false, 100, 1);
}
}

}


};

gdjs.DemoENDCode.func = function(runtimeScene) {
runtimeScene.getOnceTriggers().startNewFrame();

gdjs.DemoENDCode.GDLOGOObjects1.length = 0;
gdjs.DemoENDCode.GDLOGOObjects2.length = 0;
gdjs.DemoENDCode.GDNew3DBoxObjects1.length = 0;
gdjs.DemoENDCode.GDNew3DBoxObjects2.length = 0;
gdjs.DemoENDCode.GDNewTiledSpriteObjects1.length = 0;
gdjs.DemoENDCode.GDNewTiledSpriteObjects2.length = 0;
gdjs.DemoENDCode.GDCreditsObjects1.length = 0;
gdjs.DemoENDCode.GDCreditsObjects2.length = 0;
gdjs.DemoENDCode.GDshirotitleObjects1.length = 0;
gdjs.DemoENDCode.GDshirotitleObjects2.length = 0;
gdjs.DemoENDCode.GDNewSpriteObjects1.length = 0;
gdjs.DemoENDCode.GDNewSpriteObjects2.length = 0;
gdjs.DemoENDCode.GDNewSprite2Objects1.length = 0;
gdjs.DemoENDCode.GDNewSprite2Objects2.length = 0;
gdjs.DemoENDCode.GDNewSprite3Objects1.length = 0;
gdjs.DemoENDCode.GDNewSprite3Objects2.length = 0;
gdjs.DemoENDCode.GDNewSprite4Objects1.length = 0;
gdjs.DemoENDCode.GDNewSprite4Objects2.length = 0;
gdjs.DemoENDCode.GDStart_9595GameObjects1.length = 0;
gdjs.DemoENDCode.GDStart_9595GameObjects2.length = 0;
gdjs.DemoENDCode.GDpressObjects1.length = 0;
gdjs.DemoENDCode.GDpressObjects2.length = 0;
gdjs.DemoENDCode.GDDemoendtextObjects1.length = 0;
gdjs.DemoENDCode.GDDemoendtextObjects2.length = 0;
gdjs.DemoENDCode.GDThingObjects1.length = 0;
gdjs.DemoENDCode.GDThingObjects2.length = 0;
gdjs.DemoENDCode.GDMOuseclickObjects1.length = 0;
gdjs.DemoENDCode.GDMOuseclickObjects2.length = 0;

gdjs.DemoENDCode.eventsList0(runtimeScene);
gdjs.DemoENDCode.GDLOGOObjects1.length = 0;
gdjs.DemoENDCode.GDLOGOObjects2.length = 0;
gdjs.DemoENDCode.GDNew3DBoxObjects1.length = 0;
gdjs.DemoENDCode.GDNew3DBoxObjects2.length = 0;
gdjs.DemoENDCode.GDNewTiledSpriteObjects1.length = 0;
gdjs.DemoENDCode.GDNewTiledSpriteObjects2.length = 0;
gdjs.DemoENDCode.GDCreditsObjects1.length = 0;
gdjs.DemoENDCode.GDCreditsObjects2.length = 0;
gdjs.DemoENDCode.GDshirotitleObjects1.length = 0;
gdjs.DemoENDCode.GDshirotitleObjects2.length = 0;
gdjs.DemoENDCode.GDNewSpriteObjects1.length = 0;
gdjs.DemoENDCode.GDNewSpriteObjects2.length = 0;
gdjs.DemoENDCode.GDNewSprite2Objects1.length = 0;
gdjs.DemoENDCode.GDNewSprite2Objects2.length = 0;
gdjs.DemoENDCode.GDNewSprite3Objects1.length = 0;
gdjs.DemoENDCode.GDNewSprite3Objects2.length = 0;
gdjs.DemoENDCode.GDNewSprite4Objects1.length = 0;
gdjs.DemoENDCode.GDNewSprite4Objects2.length = 0;
gdjs.DemoENDCode.GDStart_9595GameObjects1.length = 0;
gdjs.DemoENDCode.GDStart_9595GameObjects2.length = 0;
gdjs.DemoENDCode.GDpressObjects1.length = 0;
gdjs.DemoENDCode.GDpressObjects2.length = 0;
gdjs.DemoENDCode.GDDemoendtextObjects1.length = 0;
gdjs.DemoENDCode.GDDemoendtextObjects2.length = 0;
gdjs.DemoENDCode.GDThingObjects1.length = 0;
gdjs.DemoENDCode.GDThingObjects2.length = 0;
gdjs.DemoENDCode.GDMOuseclickObjects1.length = 0;
gdjs.DemoENDCode.GDMOuseclickObjects2.length = 0;


return;

}

gdjs['DemoENDCode'] = gdjs.DemoENDCode;
