gdjs._49_45BackrCode = {};
gdjs._49_45BackrCode.localVariables = [];
gdjs._49_45BackrCode.idToCallbackMap = new Map();
gdjs._49_45BackrCode.GDPlayerObjects1= [];
gdjs._49_45BackrCode.GDPlayerObjects2= [];
gdjs._49_45BackrCode.GDCoinsObjects1= [];
gdjs._49_45BackrCode.GDCoinsObjects2= [];
gdjs._49_45BackrCode.GDPlatform_9595GroundObjects1= [];
gdjs._49_45BackrCode.GDPlatform_9595GroundObjects2= [];
gdjs._49_45BackrCode.GDNewSprite4Objects1= [];
gdjs._49_45BackrCode.GDNewSprite4Objects2= [];
gdjs._49_45BackrCode.GDNewSprite5Objects1= [];
gdjs._49_45BackrCode.GDNewSprite5Objects2= [];
gdjs._49_45BackrCode.GDNewSprite6Objects1= [];
gdjs._49_45BackrCode.GDNewSprite6Objects2= [];
gdjs._49_45BackrCode.GDspikeObjects1= [];
gdjs._49_45BackrCode.GDspikeObjects2= [];
gdjs._49_45BackrCode.GDNewSprite7Objects1= [];
gdjs._49_45BackrCode.GDNewSprite7Objects2= [];
gdjs._49_45BackrCode.GDNewSprite8Objects1= [];
gdjs._49_45BackrCode.GDNewSprite8Objects2= [];
gdjs._49_45BackrCode.GDNewSprite3Objects1= [];
gdjs._49_45BackrCode.GDNewSprite3Objects2= [];
gdjs._49_45BackrCode.GDpipeObjects1= [];
gdjs._49_45BackrCode.GDpipeObjects2= [];
gdjs._49_45BackrCode.GDStacyObjects1= [];
gdjs._49_45BackrCode.GDStacyObjects2= [];
gdjs._49_45BackrCode.GDShadedDarkJoystickObjects1= [];
gdjs._49_45BackrCode.GDShadedDarkJoystickObjects2= [];
gdjs._49_45BackrCode.GDNewSpriteObjects1= [];
gdjs._49_45BackrCode.GDNewSpriteObjects2= [];
gdjs._49_45BackrCode.GDNewSprite9Objects1= [];
gdjs._49_45BackrCode.GDNewSprite9Objects2= [];
gdjs._49_45BackrCode.GDMountain_9595dewObjects1= [];
gdjs._49_45BackrCode.GDMountain_9595dewObjects2= [];
gdjs._49_45BackrCode.GDNewSprite10Objects1= [];
gdjs._49_45BackrCode.GDNewSprite10Objects2= [];
gdjs._49_45BackrCode.GDJumpObjects1= [];
gdjs._49_45BackrCode.GDJumpObjects2= [];
gdjs._49_45BackrCode.GDTreeObjects1= [];
gdjs._49_45BackrCode.GDTreeObjects2= [];
gdjs._49_45BackrCode.GDPauseObjects1= [];
gdjs._49_45BackrCode.GDPauseObjects2= [];
gdjs._49_45BackrCode.GDMOuseclickObjects1= [];
gdjs._49_45BackrCode.GDMOuseclickObjects2= [];
gdjs._49_45BackrCode.GDNewTextObjects1= [];
gdjs._49_45BackrCode.GDNewTextObjects2= [];
gdjs._49_45BackrCode.GDNewSprite2Objects1= [];
gdjs._49_45BackrCode.GDNewSprite2Objects2= [];
gdjs._49_45BackrCode.GDNewSprite11Objects1= [];
gdjs._49_45BackrCode.GDNewSprite11Objects2= [];
gdjs._49_45BackrCode.GDNewSprite12Objects1= [];
gdjs._49_45BackrCode.GDNewSprite12Objects2= [];
gdjs._49_45BackrCode.GDNewSprite13Objects1= [];
gdjs._49_45BackrCode.GDNewSprite13Objects2= [];
gdjs._49_45BackrCode.GDspikenotvisiObjects1= [];
gdjs._49_45BackrCode.GDspikenotvisiObjects2= [];
gdjs._49_45BackrCode.GDBoomObjects1= [];
gdjs._49_45BackrCode.GDBoomObjects2= [];
gdjs._49_45BackrCode.GDNew3DBoxObjects1= [];
gdjs._49_45BackrCode.GDNew3DBoxObjects2= [];
gdjs._49_45BackrCode.GDLoadanimObjects1= [];
gdjs._49_45BackrCode.GDLoadanimObjects2= [];
gdjs._49_45BackrCode.GDNewSprite14Objects1= [];
gdjs._49_45BackrCode.GDNewSprite14Objects2= [];
gdjs._49_45BackrCode.GDBushesObjects1= [];
gdjs._49_45BackrCode.GDBushesObjects2= [];
gdjs._49_45BackrCode.GDNewSprite15Objects1= [];
gdjs._49_45BackrCode.GDNewSprite15Objects2= [];


gdjs._49_45BackrCode.mapOfGDgdjs_9546_959549_959545BackrCode_9546GDPlayerObjects1Objects = Hashtable.newFrom({"Player": gdjs._49_45BackrCode.GDPlayerObjects1});
gdjs._49_45BackrCode.mapOfGDgdjs_9546_959549_959545BackrCode_9546GDCoinsObjects1Objects = Hashtable.newFrom({"Coins": gdjs._49_45BackrCode.GDCoinsObjects1});
gdjs._49_45BackrCode.mapOfGDgdjs_9546_959549_959545BackrCode_9546GDPlayerObjects1Objects = Hashtable.newFrom({"Player": gdjs._49_45BackrCode.GDPlayerObjects1});
gdjs._49_45BackrCode.mapOfGDgdjs_9546_959549_959545BackrCode_9546GDNewSprite11Objects1Objects = Hashtable.newFrom({"NewSprite11": gdjs._49_45BackrCode.GDNewSprite11Objects1});
gdjs._49_45BackrCode.mapOfGDgdjs_9546_959549_959545BackrCode_9546GDPlayerObjects1Objects = Hashtable.newFrom({"Player": gdjs._49_45BackrCode.GDPlayerObjects1});
gdjs._49_45BackrCode.mapOfGDgdjs_9546_959549_959545BackrCode_9546GDNewSprite4Objects1Objects = Hashtable.newFrom({"NewSprite4": gdjs._49_45BackrCode.GDNewSprite4Objects1});
gdjs._49_45BackrCode.mapOfGDgdjs_9546_959549_959545BackrCode_9546GDPlayerObjects1Objects = Hashtable.newFrom({"Player": gdjs._49_45BackrCode.GDPlayerObjects1});
gdjs._49_45BackrCode.mapOfGDgdjs_9546_959549_959545BackrCode_9546GDNewSprite11Objects1Objects = Hashtable.newFrom({"NewSprite11": gdjs._49_45BackrCode.GDNewSprite11Objects1});
gdjs._49_45BackrCode.mapOfGDgdjs_9546_959549_959545BackrCode_9546GDPlayerObjects1Objects = Hashtable.newFrom({"Player": gdjs._49_45BackrCode.GDPlayerObjects1});
gdjs._49_45BackrCode.mapOfGDgdjs_9546_959549_959545BackrCode_9546GDNewSprite4Objects1Objects = Hashtable.newFrom({"NewSprite4": gdjs._49_45BackrCode.GDNewSprite4Objects1});
gdjs._49_45BackrCode.mapOfGDgdjs_9546_959549_959545BackrCode_9546GDPlayerObjects1Objects = Hashtable.newFrom({"Player": gdjs._49_45BackrCode.GDPlayerObjects1});
gdjs._49_45BackrCode.mapOfGDgdjs_9546_959549_959545BackrCode_9546GDspikeObjects1Objects = Hashtable.newFrom({"spike": gdjs._49_45BackrCode.GDspikeObjects1});
gdjs._49_45BackrCode.mapOfGDgdjs_9546_959549_959545BackrCode_9546GDPlayerObjects1Objects = Hashtable.newFrom({"Player": gdjs._49_45BackrCode.GDPlayerObjects1});
gdjs._49_45BackrCode.mapOfGDgdjs_9546_959549_959545BackrCode_9546GDspikeObjects1Objects = Hashtable.newFrom({"spike": gdjs._49_45BackrCode.GDspikeObjects1});
gdjs._49_45BackrCode.mapOfGDgdjs_9546_959549_959545BackrCode_9546GDPlayerObjects1Objects = Hashtable.newFrom({"Player": gdjs._49_45BackrCode.GDPlayerObjects1});
gdjs._49_45BackrCode.mapOfGDgdjs_9546_959549_959545BackrCode_9546GDPlatform_95959595GroundObjects1Objects = Hashtable.newFrom({"Platform_Ground": gdjs._49_45BackrCode.GDPlatform_9595GroundObjects1});
gdjs._49_45BackrCode.mapOfGDgdjs_9546_959549_959545BackrCode_9546GDPlayerObjects1Objects = Hashtable.newFrom({"Player": gdjs._49_45BackrCode.GDPlayerObjects1});
gdjs._49_45BackrCode.mapOfGDgdjs_9546_959549_959545BackrCode_9546GDPlatform_95959595GroundObjects1Objects = Hashtable.newFrom({"Platform_Ground": gdjs._49_45BackrCode.GDPlatform_9595GroundObjects1});
gdjs._49_45BackrCode.mapOfGDgdjs_9546_959549_959545BackrCode_9546GDPlayerObjects1Objects = Hashtable.newFrom({"Player": gdjs._49_45BackrCode.GDPlayerObjects1});
gdjs._49_45BackrCode.mapOfGDgdjs_9546_959549_959545BackrCode_9546GDspikeObjects1Objects = Hashtable.newFrom({"spike": gdjs._49_45BackrCode.GDspikeObjects1});
gdjs._49_45BackrCode.mapOfGDgdjs_9546_959549_959545BackrCode_9546GDPlayerObjects1Objects = Hashtable.newFrom({"Player": gdjs._49_45BackrCode.GDPlayerObjects1});
gdjs._49_45BackrCode.mapOfGDgdjs_9546_959549_959545BackrCode_9546GDNewSprite14Objects1Objects = Hashtable.newFrom({"NewSprite14": gdjs._49_45BackrCode.GDNewSprite14Objects1});
gdjs._49_45BackrCode.eventsList0 = function(runtimeScene) {

{


let isConditionTrue_0 = false;
{
{gdjs.evtTools.camera.setCameraZoom(runtimeScene, 2.5, "", 0);
}
{gdjs.evtTools.camera.setCameraZoom(runtimeScene, 2.5, "Background", 0);
}
}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.runtimeScene.sceneJustBegins(runtimeScene);
if (isConditionTrue_0) {
}

}


{

gdjs.copyArray(runtimeScene.getObjects("Coins"), gdjs._49_45BackrCode.GDCoinsObjects1);
gdjs.copyArray(runtimeScene.getObjects("Player"), gdjs._49_45BackrCode.GDPlayerObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs._49_45BackrCode.mapOfGDgdjs_9546_959549_959545BackrCode_9546GDPlayerObjects1Objects, gdjs._49_45BackrCode.mapOfGDgdjs_9546_959549_959545BackrCode_9546GDCoinsObjects1Objects, false, runtimeScene, false);
if (isConditionTrue_0) {
/* Reuse gdjs._49_45BackrCode.GDCoinsObjects1 */
{for(var i = 0, len = gdjs._49_45BackrCode.GDCoinsObjects1.length ;i < len;++i) {
    gdjs._49_45BackrCode.GDCoinsObjects1[i].deleteFromScene(runtimeScene);
}
}
{gdjs.evtTools.sound.playSound(runtimeScene, "Coin.wav", false, 100, 1);
}
}

}


{

gdjs.copyArray(runtimeScene.getObjects("Player"), gdjs._49_45BackrCode.GDPlayerObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs._49_45BackrCode.GDPlayerObjects1.length;i<l;++i) {
    if ( gdjs._49_45BackrCode.GDPlayerObjects1[i].getBehavior("PlatformerObject").isOnFloor() ) {
        isConditionTrue_0 = true;
        gdjs._49_45BackrCode.GDPlayerObjects1[k] = gdjs._49_45BackrCode.GDPlayerObjects1[i];
        ++k;
    }
}
gdjs._49_45BackrCode.GDPlayerObjects1.length = k;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs._49_45BackrCode.GDPlayerObjects1.length;i<l;++i) {
    if ( !(gdjs._49_45BackrCode.GDPlayerObjects1[i].getBehavior("PlatformerObject").isMovingEvenALittle()) ) {
        isConditionTrue_0 = true;
        gdjs._49_45BackrCode.GDPlayerObjects1[k] = gdjs._49_45BackrCode.GDPlayerObjects1[i];
        ++k;
    }
}
gdjs._49_45BackrCode.GDPlayerObjects1.length = k;
}
if (isConditionTrue_0) {
/* Reuse gdjs._49_45BackrCode.GDPlayerObjects1 */
{for(var i = 0, len = gdjs._49_45BackrCode.GDPlayerObjects1.length ;i < len;++i) {
    gdjs._49_45BackrCode.GDPlayerObjects1[i].getBehavior("Animation").setAnimationName("Idle");
}
}
}

}


{

gdjs.copyArray(runtimeScene.getObjects("Player"), gdjs._49_45BackrCode.GDPlayerObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs._49_45BackrCode.GDPlayerObjects1.length;i<l;++i) {
    if ( gdjs._49_45BackrCode.GDPlayerObjects1[i].getBehavior("PlatformerObject").isMovingEvenALittle() ) {
        isConditionTrue_0 = true;
        gdjs._49_45BackrCode.GDPlayerObjects1[k] = gdjs._49_45BackrCode.GDPlayerObjects1[i];
        ++k;
    }
}
gdjs._49_45BackrCode.GDPlayerObjects1.length = k;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs._49_45BackrCode.GDPlayerObjects1.length;i<l;++i) {
    if ( gdjs._49_45BackrCode.GDPlayerObjects1[i].getBehavior("PlatformerObject").isOnFloor() ) {
        isConditionTrue_0 = true;
        gdjs._49_45BackrCode.GDPlayerObjects1[k] = gdjs._49_45BackrCode.GDPlayerObjects1[i];
        ++k;
    }
}
gdjs._49_45BackrCode.GDPlayerObjects1.length = k;
}
if (isConditionTrue_0) {
/* Reuse gdjs._49_45BackrCode.GDPlayerObjects1 */
{for(var i = 0, len = gdjs._49_45BackrCode.GDPlayerObjects1.length ;i < len;++i) {
    gdjs._49_45BackrCode.GDPlayerObjects1[i].getBehavior("Animation").setAnimationName("Running");
}
}
}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.isKeyPressed(runtimeScene, "Left");
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("Player"), gdjs._49_45BackrCode.GDPlayerObjects1);
{for(var i = 0, len = gdjs._49_45BackrCode.GDPlayerObjects1.length ;i < len;++i) {
    gdjs._49_45BackrCode.GDPlayerObjects1[i].getBehavior("Flippable").flipX(true);
}
}
}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.isKeyPressed(runtimeScene, "Right");
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("Player"), gdjs._49_45BackrCode.GDPlayerObjects1);
{for(var i = 0, len = gdjs._49_45BackrCode.GDPlayerObjects1.length ;i < len;++i) {
    gdjs._49_45BackrCode.GDPlayerObjects1[i].getBehavior("Flippable").flipX(false);
}
}
}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.isKeyPressed(runtimeScene, "Left");
if (isConditionTrue_0) {
}

}


{


let isConditionTrue_0 = false;
{
}

}


{


let isConditionTrue_0 = false;
{
}

}


{

gdjs.copyArray(runtimeScene.getObjects("NewSprite11"), gdjs._49_45BackrCode.GDNewSprite11Objects1);
gdjs.copyArray(runtimeScene.getObjects("Player"), gdjs._49_45BackrCode.GDPlayerObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs._49_45BackrCode.mapOfGDgdjs_9546_959549_959545BackrCode_9546GDPlayerObjects1Objects, gdjs._49_45BackrCode.mapOfGDgdjs_9546_959549_959545BackrCode_9546GDNewSprite11Objects1Objects, false, runtimeScene, false);
if (isConditionTrue_0) {
{gdjs.evtTools.sound.playSound(runtimeScene, "TaDa.wav", false, 100, 1);
}
}

}


{

gdjs.copyArray(runtimeScene.getObjects("Player"), gdjs._49_45BackrCode.GDPlayerObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs._49_45BackrCode.GDPlayerObjects1.length;i<l;++i) {
    if ( gdjs._49_45BackrCode.GDPlayerObjects1[i].getBehavior("PlatformerObject").isUsingControl("Left") ) {
        isConditionTrue_0 = true;
        gdjs._49_45BackrCode.GDPlayerObjects1[k] = gdjs._49_45BackrCode.GDPlayerObjects1[i];
        ++k;
    }
}
gdjs._49_45BackrCode.GDPlayerObjects1.length = k;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs._49_45BackrCode.GDPlayerObjects1.length;i<l;++i) {
    if ( !(gdjs._49_45BackrCode.GDPlayerObjects1[i].getBehavior("PlatformerObject").isUsingControl("Right")) ) {
        isConditionTrue_0 = true;
        gdjs._49_45BackrCode.GDPlayerObjects1[k] = gdjs._49_45BackrCode.GDPlayerObjects1[i];
        ++k;
    }
}
gdjs._49_45BackrCode.GDPlayerObjects1.length = k;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs._49_45BackrCode.GDPlayerObjects1.length;i<l;++i) {
    if ( gdjs._49_45BackrCode.GDPlayerObjects1[i].getBehavior("PlatformerObject").isUsingControl("Left") ) {
        isConditionTrue_0 = true;
        gdjs._49_45BackrCode.GDPlayerObjects1[k] = gdjs._49_45BackrCode.GDPlayerObjects1[i];
        ++k;
    }
}
gdjs._49_45BackrCode.GDPlayerObjects1.length = k;
}
}
if (isConditionTrue_0) {
/* Reuse gdjs._49_45BackrCode.GDPlayerObjects1 */
{for(var i = 0, len = gdjs._49_45BackrCode.GDPlayerObjects1.length ;i < len;++i) {
    gdjs._49_45BackrCode.GDPlayerObjects1[i].getBehavior("Flippable").flipX(false);
}
}
{for(var i = 0, len = gdjs._49_45BackrCode.GDPlayerObjects1.length ;i < len;++i) {
    gdjs._49_45BackrCode.GDPlayerObjects1[i].getBehavior("Flippable").flipX(false);
}
}
{for(var i = 0, len = gdjs._49_45BackrCode.GDPlayerObjects1.length ;i < len;++i) {
    gdjs._49_45BackrCode.GDPlayerObjects1[i].getBehavior("Flippable").flipX(true);
}
}
}

}


{

gdjs.copyArray(runtimeScene.getObjects("Player"), gdjs._49_45BackrCode.GDPlayerObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs._49_45BackrCode.GDPlayerObjects1.length;i<l;++i) {
    if ( gdjs._49_45BackrCode.GDPlayerObjects1[i].getBehavior("PlatformerObject").isUsingControl("Right") ) {
        isConditionTrue_0 = true;
        gdjs._49_45BackrCode.GDPlayerObjects1[k] = gdjs._49_45BackrCode.GDPlayerObjects1[i];
        ++k;
    }
}
gdjs._49_45BackrCode.GDPlayerObjects1.length = k;
if (isConditionTrue_0) {
/* Reuse gdjs._49_45BackrCode.GDPlayerObjects1 */
{for(var i = 0, len = gdjs._49_45BackrCode.GDPlayerObjects1.length ;i < len;++i) {
    gdjs._49_45BackrCode.GDPlayerObjects1[i].getBehavior("Flippable").flipX(false);
}
}
}

}


{

gdjs.copyArray(runtimeScene.getObjects("Jump"), gdjs._49_45BackrCode.GDJumpObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs._49_45BackrCode.GDJumpObjects1.length;i<l;++i) {
    if ( gdjs._49_45BackrCode.GDJumpObjects1[i].getBehavior("ButtonFSM").IsPressed(null) ) {
        isConditionTrue_0 = true;
        gdjs._49_45BackrCode.GDJumpObjects1[k] = gdjs._49_45BackrCode.GDJumpObjects1[i];
        ++k;
    }
}
gdjs._49_45BackrCode.GDJumpObjects1.length = k;
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("Player"), gdjs._49_45BackrCode.GDPlayerObjects1);
{for(var i = 0, len = gdjs._49_45BackrCode.GDPlayerObjects1.length ;i < len;++i) {
    gdjs._49_45BackrCode.GDPlayerObjects1[i].getBehavior("PlatformerObject").simulateJumpKey();
}
}
}

}


{

gdjs.copyArray(runtimeScene.getObjects("NewSprite4"), gdjs._49_45BackrCode.GDNewSprite4Objects1);
gdjs.copyArray(runtimeScene.getObjects("Player"), gdjs._49_45BackrCode.GDPlayerObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs._49_45BackrCode.mapOfGDgdjs_9546_959549_959545BackrCode_9546GDPlayerObjects1Objects, gdjs._49_45BackrCode.mapOfGDgdjs_9546_959549_959545BackrCode_9546GDNewSprite4Objects1Objects, false, runtimeScene, false);
if (isConditionTrue_0) {
/* Reuse gdjs._49_45BackrCode.GDPlayerObjects1 */
{for(var i = 0, len = gdjs._49_45BackrCode.GDPlayerObjects1.length ;i < len;++i) {
    gdjs._49_45BackrCode.GDPlayerObjects1[i].getBehavior("PlatformerObject").simulateRightKey();
}
}
}

}


{

gdjs.copyArray(runtimeScene.getObjects("NewSprite11"), gdjs._49_45BackrCode.GDNewSprite11Objects1);
gdjs.copyArray(runtimeScene.getObjects("Player"), gdjs._49_45BackrCode.GDPlayerObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs._49_45BackrCode.mapOfGDgdjs_9546_959549_959545BackrCode_9546GDPlayerObjects1Objects, gdjs._49_45BackrCode.mapOfGDgdjs_9546_959549_959545BackrCode_9546GDNewSprite11Objects1Objects, false, runtimeScene, false);
if (isConditionTrue_0) {
{gdjs.evtTools.runtimeScene.replaceScene(runtimeScene, "DemoEND", false);
}
}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.runtimeScene.sceneJustBegins(runtimeScene);
if (isConditionTrue_0) {
{gdjs.evtTools.sound.playMusicOnChannel(runtimeScene, "oof.mp3", 2, true, 100, 1);
}
}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.runtimeScene.sceneJustBegins(runtimeScene);
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("NewSprite10"), gdjs._49_45BackrCode.GDNewSprite10Objects1);
{for(var i = 0, len = gdjs._49_45BackrCode.GDNewSprite10Objects1.length ;i < len;++i) {
    gdjs._49_45BackrCode.GDNewSprite10Objects1[i].hide();
}
}
}

}


{


let isConditionTrue_0 = false;
{
}

}


{

gdjs.copyArray(runtimeScene.getObjects("Player"), gdjs._49_45BackrCode.GDPlayerObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs._49_45BackrCode.GDPlayerObjects1.length;i<l;++i) {
    if ( gdjs._49_45BackrCode.GDPlayerObjects1[i].getBehavior("PlatformerObject").isJumping() ) {
        isConditionTrue_0 = true;
        gdjs._49_45BackrCode.GDPlayerObjects1[k] = gdjs._49_45BackrCode.GDPlayerObjects1[i];
        ++k;
    }
}
gdjs._49_45BackrCode.GDPlayerObjects1.length = k;
if (isConditionTrue_0) {
/* Reuse gdjs._49_45BackrCode.GDPlayerObjects1 */
{for(var i = 0, len = gdjs._49_45BackrCode.GDPlayerObjects1.length ;i < len;++i) {
    gdjs._49_45BackrCode.GDPlayerObjects1[i].getBehavior("Animation").setAnimationName("Jumping jacks");
}
}
}

}


{

gdjs.copyArray(runtimeScene.getObjects("Player"), gdjs._49_45BackrCode.GDPlayerObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs._49_45BackrCode.GDPlayerObjects1.length;i<l;++i) {
    if ( gdjs._49_45BackrCode.GDPlayerObjects1[i].getBehavior("PlatformerObject").isFalling() ) {
        isConditionTrue_0 = true;
        gdjs._49_45BackrCode.GDPlayerObjects1[k] = gdjs._49_45BackrCode.GDPlayerObjects1[i];
        ++k;
    }
}
gdjs._49_45BackrCode.GDPlayerObjects1.length = k;
if (isConditionTrue_0) {
/* Reuse gdjs._49_45BackrCode.GDPlayerObjects1 */
{for(var i = 0, len = gdjs._49_45BackrCode.GDPlayerObjects1.length ;i < len;++i) {
    gdjs._49_45BackrCode.GDPlayerObjects1[i].getBehavior("Animation").setAnimationName("Fall");
}
}
}

}


{


let isConditionTrue_0 = false;
{
}

}


{

gdjs.copyArray(runtimeScene.getObjects("Pause"), gdjs._49_45BackrCode.GDPauseObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs._49_45BackrCode.GDPauseObjects1.length;i<l;++i) {
    if ( gdjs._49_45BackrCode.GDPauseObjects1[i].getBehavior("ButtonFSM").IsPressed(null) ) {
        isConditionTrue_0 = true;
        gdjs._49_45BackrCode.GDPauseObjects1[k] = gdjs._49_45BackrCode.GDPauseObjects1[i];
        ++k;
    }
}
gdjs._49_45BackrCode.GDPauseObjects1.length = k;
if (isConditionTrue_0) {
{gdjs.evtTools.runtimeScene.replaceScene(runtimeScene, "Settings", false);
}
}

}


{

gdjs.copyArray(runtimeScene.getObjects("NewSprite4"), gdjs._49_45BackrCode.GDNewSprite4Objects1);
gdjs.copyArray(runtimeScene.getObjects("Player"), gdjs._49_45BackrCode.GDPlayerObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs._49_45BackrCode.mapOfGDgdjs_9546_959549_959545BackrCode_9546GDPlayerObjects1Objects, gdjs._49_45BackrCode.mapOfGDgdjs_9546_959549_959545BackrCode_9546GDNewSprite4Objects1Objects, false, runtimeScene, false);
if (isConditionTrue_0) {
/* Reuse gdjs._49_45BackrCode.GDNewSprite4Objects1 */
{for(var i = 0, len = gdjs._49_45BackrCode.GDNewSprite4Objects1.length ;i < len;++i) {
    gdjs._49_45BackrCode.GDNewSprite4Objects1[i].getBehavior("Animation").setAnimationName("cool");
}
}
}

}


{


let isConditionTrue_0 = false;
{
}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtsExt__Gamepads__C_Axis_pushed.func(runtimeScene, 1, "Left", "Any", null);
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("Jump"), gdjs._49_45BackrCode.GDJumpObjects1);
gdjs.copyArray(runtimeScene.getObjects("ShadedDarkJoystick"), gdjs._49_45BackrCode.GDShadedDarkJoystickObjects1);
{for(var i = 0, len = gdjs._49_45BackrCode.GDShadedDarkJoystickObjects1.length ;i < len;++i) {
    gdjs._49_45BackrCode.GDShadedDarkJoystickObjects1[i].deleteFromScene(runtimeScene);
}
}
{for(var i = 0, len = gdjs._49_45BackrCode.GDJumpObjects1.length ;i < len;++i) {
    gdjs._49_45BackrCode.GDJumpObjects1[i].deleteFromScene(runtimeScene);
}
}
}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.anyKeyPressed(runtimeScene);
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("Jump"), gdjs._49_45BackrCode.GDJumpObjects1);
gdjs.copyArray(runtimeScene.getObjects("ShadedDarkJoystick"), gdjs._49_45BackrCode.GDShadedDarkJoystickObjects1);
{for(var i = 0, len = gdjs._49_45BackrCode.GDShadedDarkJoystickObjects1.length ;i < len;++i) {
    gdjs._49_45BackrCode.GDShadedDarkJoystickObjects1[i].deleteFromScene(runtimeScene);
}
}
{for(var i = 0, len = gdjs._49_45BackrCode.GDJumpObjects1.length ;i < len;++i) {
    gdjs._49_45BackrCode.GDJumpObjects1[i].deleteFromScene(runtimeScene);
}
}
}

}


{

gdjs.copyArray(runtimeScene.getObjects("Player"), gdjs._49_45BackrCode.GDPlayerObjects1);
gdjs.copyArray(runtimeScene.getObjects("spike"), gdjs._49_45BackrCode.GDspikeObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.platform.isOnPlatform(gdjs._49_45BackrCode.mapOfGDgdjs_9546_959549_959545BackrCode_9546GDPlayerObjects1Objects, "PlatformerObject", gdjs._49_45BackrCode.mapOfGDgdjs_9546_959549_959545BackrCode_9546GDspikeObjects1Objects, false);
if (isConditionTrue_0) {
/* Reuse gdjs._49_45BackrCode.GDPlayerObjects1 */
{for(var i = 0, len = gdjs._49_45BackrCode.GDPlayerObjects1.length ;i < len;++i) {
    gdjs._49_45BackrCode.GDPlayerObjects1[i].getBehavior("LinearMovement").SetSpeedY(-200, null);
}
}
}

}


{

gdjs.copyArray(runtimeScene.getObjects("Player"), gdjs._49_45BackrCode.GDPlayerObjects1);
gdjs.copyArray(runtimeScene.getObjects("spike"), gdjs._49_45BackrCode.GDspikeObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.platform.isOnPlatform(gdjs._49_45BackrCode.mapOfGDgdjs_9546_959549_959545BackrCode_9546GDPlayerObjects1Objects, "PlatformerObject", gdjs._49_45BackrCode.mapOfGDgdjs_9546_959549_959545BackrCode_9546GDspikeObjects1Objects, false);
if (isConditionTrue_0) {
/* Reuse gdjs._49_45BackrCode.GDPlayerObjects1 */
{for(var i = 0, len = gdjs._49_45BackrCode.GDPlayerObjects1.length ;i < len;++i) {
    gdjs._49_45BackrCode.GDPlayerObjects1[i].getBehavior("LinearMovement").SetSpeedX(-100, null);
}
}
}

}


{

gdjs.copyArray(runtimeScene.getObjects("Platform_Ground"), gdjs._49_45BackrCode.GDPlatform_9595GroundObjects1);
gdjs.copyArray(runtimeScene.getObjects("Player"), gdjs._49_45BackrCode.GDPlayerObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.platform.isOnPlatform(gdjs._49_45BackrCode.mapOfGDgdjs_9546_959549_959545BackrCode_9546GDPlayerObjects1Objects, "PlatformerObject", gdjs._49_45BackrCode.mapOfGDgdjs_9546_959549_959545BackrCode_9546GDPlatform_95959595GroundObjects1Objects, false);
if (isConditionTrue_0) {
/* Reuse gdjs._49_45BackrCode.GDPlayerObjects1 */
{for(var i = 0, len = gdjs._49_45BackrCode.GDPlayerObjects1.length ;i < len;++i) {
    gdjs._49_45BackrCode.GDPlayerObjects1[i].getBehavior("LinearMovement").SetSpeedX(0, null);
}
}
}

}


{


let isConditionTrue_0 = false;
{
}

}


{

gdjs.copyArray(runtimeScene.getObjects("Platform_Ground"), gdjs._49_45BackrCode.GDPlatform_9595GroundObjects1);
gdjs.copyArray(runtimeScene.getObjects("Player"), gdjs._49_45BackrCode.GDPlayerObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.platform.isOnPlatform(gdjs._49_45BackrCode.mapOfGDgdjs_9546_959549_959545BackrCode_9546GDPlayerObjects1Objects, "PlatformerObject", gdjs._49_45BackrCode.mapOfGDgdjs_9546_959549_959545BackrCode_9546GDPlatform_95959595GroundObjects1Objects, false);
if (isConditionTrue_0) {
/* Reuse gdjs._49_45BackrCode.GDPlayerObjects1 */
{for(var i = 0, len = gdjs._49_45BackrCode.GDPlayerObjects1.length ;i < len;++i) {
    gdjs._49_45BackrCode.GDPlayerObjects1[i].getBehavior("LinearMovement").SetSpeedY(0, null);
}
}
}

}


{

gdjs.copyArray(runtimeScene.getObjects("Player"), gdjs._49_45BackrCode.GDPlayerObjects1);
gdjs.copyArray(runtimeScene.getObjects("spike"), gdjs._49_45BackrCode.GDspikeObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs._49_45BackrCode.mapOfGDgdjs_9546_959549_959545BackrCode_9546GDPlayerObjects1Objects, gdjs._49_45BackrCode.mapOfGDgdjs_9546_959549_959545BackrCode_9546GDspikeObjects1Objects, false, runtimeScene, false);
if (isConditionTrue_0) {
/* Reuse gdjs._49_45BackrCode.GDPlayerObjects1 */
{for(var i = 0, len = gdjs._49_45BackrCode.GDPlayerObjects1.length ;i < len;++i) {
    gdjs._49_45BackrCode.GDPlayerObjects1[i].getBehavior("Animation").setAnimationName("Die");
}
}
}

}


{


let isConditionTrue_0 = false;
{
}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.runtimeScene.sceneJustBegins(runtimeScene);
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("Loadanim"), gdjs._49_45BackrCode.GDLoadanimObjects1);
{for(var i = 0, len = gdjs._49_45BackrCode.GDLoadanimObjects1.length ;i < len;++i) {
    gdjs._49_45BackrCode.GDLoadanimObjects1[i].hide();
}
}
}

}


{

gdjs.copyArray(runtimeScene.getObjects("NewSprite14"), gdjs._49_45BackrCode.GDNewSprite14Objects1);
gdjs.copyArray(runtimeScene.getObjects("Player"), gdjs._49_45BackrCode.GDPlayerObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs._49_45BackrCode.mapOfGDgdjs_9546_959549_959545BackrCode_9546GDPlayerObjects1Objects, gdjs._49_45BackrCode.mapOfGDgdjs_9546_959549_959545BackrCode_9546GDNewSprite14Objects1Objects, false, runtimeScene, false);
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("Loadanim"), gdjs._49_45BackrCode.GDLoadanimObjects1);
{for(var i = 0, len = gdjs._49_45BackrCode.GDLoadanimObjects1.length ;i < len;++i) {
    gdjs._49_45BackrCode.GDLoadanimObjects1[i].hide(false);
}
}
}

}


};

gdjs._49_45BackrCode.func = function(runtimeScene) {
runtimeScene.getOnceTriggers().startNewFrame();

gdjs._49_45BackrCode.GDPlayerObjects1.length = 0;
gdjs._49_45BackrCode.GDPlayerObjects2.length = 0;
gdjs._49_45BackrCode.GDCoinsObjects1.length = 0;
gdjs._49_45BackrCode.GDCoinsObjects2.length = 0;
gdjs._49_45BackrCode.GDPlatform_9595GroundObjects1.length = 0;
gdjs._49_45BackrCode.GDPlatform_9595GroundObjects2.length = 0;
gdjs._49_45BackrCode.GDNewSprite4Objects1.length = 0;
gdjs._49_45BackrCode.GDNewSprite4Objects2.length = 0;
gdjs._49_45BackrCode.GDNewSprite5Objects1.length = 0;
gdjs._49_45BackrCode.GDNewSprite5Objects2.length = 0;
gdjs._49_45BackrCode.GDNewSprite6Objects1.length = 0;
gdjs._49_45BackrCode.GDNewSprite6Objects2.length = 0;
gdjs._49_45BackrCode.GDspikeObjects1.length = 0;
gdjs._49_45BackrCode.GDspikeObjects2.length = 0;
gdjs._49_45BackrCode.GDNewSprite7Objects1.length = 0;
gdjs._49_45BackrCode.GDNewSprite7Objects2.length = 0;
gdjs._49_45BackrCode.GDNewSprite8Objects1.length = 0;
gdjs._49_45BackrCode.GDNewSprite8Objects2.length = 0;
gdjs._49_45BackrCode.GDNewSprite3Objects1.length = 0;
gdjs._49_45BackrCode.GDNewSprite3Objects2.length = 0;
gdjs._49_45BackrCode.GDpipeObjects1.length = 0;
gdjs._49_45BackrCode.GDpipeObjects2.length = 0;
gdjs._49_45BackrCode.GDStacyObjects1.length = 0;
gdjs._49_45BackrCode.GDStacyObjects2.length = 0;
gdjs._49_45BackrCode.GDShadedDarkJoystickObjects1.length = 0;
gdjs._49_45BackrCode.GDShadedDarkJoystickObjects2.length = 0;
gdjs._49_45BackrCode.GDNewSpriteObjects1.length = 0;
gdjs._49_45BackrCode.GDNewSpriteObjects2.length = 0;
gdjs._49_45BackrCode.GDNewSprite9Objects1.length = 0;
gdjs._49_45BackrCode.GDNewSprite9Objects2.length = 0;
gdjs._49_45BackrCode.GDMountain_9595dewObjects1.length = 0;
gdjs._49_45BackrCode.GDMountain_9595dewObjects2.length = 0;
gdjs._49_45BackrCode.GDNewSprite10Objects1.length = 0;
gdjs._49_45BackrCode.GDNewSprite10Objects2.length = 0;
gdjs._49_45BackrCode.GDJumpObjects1.length = 0;
gdjs._49_45BackrCode.GDJumpObjects2.length = 0;
gdjs._49_45BackrCode.GDTreeObjects1.length = 0;
gdjs._49_45BackrCode.GDTreeObjects2.length = 0;
gdjs._49_45BackrCode.GDPauseObjects1.length = 0;
gdjs._49_45BackrCode.GDPauseObjects2.length = 0;
gdjs._49_45BackrCode.GDMOuseclickObjects1.length = 0;
gdjs._49_45BackrCode.GDMOuseclickObjects2.length = 0;
gdjs._49_45BackrCode.GDNewTextObjects1.length = 0;
gdjs._49_45BackrCode.GDNewTextObjects2.length = 0;
gdjs._49_45BackrCode.GDNewSprite2Objects1.length = 0;
gdjs._49_45BackrCode.GDNewSprite2Objects2.length = 0;
gdjs._49_45BackrCode.GDNewSprite11Objects1.length = 0;
gdjs._49_45BackrCode.GDNewSprite11Objects2.length = 0;
gdjs._49_45BackrCode.GDNewSprite12Objects1.length = 0;
gdjs._49_45BackrCode.GDNewSprite12Objects2.length = 0;
gdjs._49_45BackrCode.GDNewSprite13Objects1.length = 0;
gdjs._49_45BackrCode.GDNewSprite13Objects2.length = 0;
gdjs._49_45BackrCode.GDspikenotvisiObjects1.length = 0;
gdjs._49_45BackrCode.GDspikenotvisiObjects2.length = 0;
gdjs._49_45BackrCode.GDBoomObjects1.length = 0;
gdjs._49_45BackrCode.GDBoomObjects2.length = 0;
gdjs._49_45BackrCode.GDNew3DBoxObjects1.length = 0;
gdjs._49_45BackrCode.GDNew3DBoxObjects2.length = 0;
gdjs._49_45BackrCode.GDLoadanimObjects1.length = 0;
gdjs._49_45BackrCode.GDLoadanimObjects2.length = 0;
gdjs._49_45BackrCode.GDNewSprite14Objects1.length = 0;
gdjs._49_45BackrCode.GDNewSprite14Objects2.length = 0;
gdjs._49_45BackrCode.GDBushesObjects1.length = 0;
gdjs._49_45BackrCode.GDBushesObjects2.length = 0;
gdjs._49_45BackrCode.GDNewSprite15Objects1.length = 0;
gdjs._49_45BackrCode.GDNewSprite15Objects2.length = 0;

gdjs._49_45BackrCode.eventsList0(runtimeScene);
gdjs._49_45BackrCode.GDPlayerObjects1.length = 0;
gdjs._49_45BackrCode.GDPlayerObjects2.length = 0;
gdjs._49_45BackrCode.GDCoinsObjects1.length = 0;
gdjs._49_45BackrCode.GDCoinsObjects2.length = 0;
gdjs._49_45BackrCode.GDPlatform_9595GroundObjects1.length = 0;
gdjs._49_45BackrCode.GDPlatform_9595GroundObjects2.length = 0;
gdjs._49_45BackrCode.GDNewSprite4Objects1.length = 0;
gdjs._49_45BackrCode.GDNewSprite4Objects2.length = 0;
gdjs._49_45BackrCode.GDNewSprite5Objects1.length = 0;
gdjs._49_45BackrCode.GDNewSprite5Objects2.length = 0;
gdjs._49_45BackrCode.GDNewSprite6Objects1.length = 0;
gdjs._49_45BackrCode.GDNewSprite6Objects2.length = 0;
gdjs._49_45BackrCode.GDspikeObjects1.length = 0;
gdjs._49_45BackrCode.GDspikeObjects2.length = 0;
gdjs._49_45BackrCode.GDNewSprite7Objects1.length = 0;
gdjs._49_45BackrCode.GDNewSprite7Objects2.length = 0;
gdjs._49_45BackrCode.GDNewSprite8Objects1.length = 0;
gdjs._49_45BackrCode.GDNewSprite8Objects2.length = 0;
gdjs._49_45BackrCode.GDNewSprite3Objects1.length = 0;
gdjs._49_45BackrCode.GDNewSprite3Objects2.length = 0;
gdjs._49_45BackrCode.GDpipeObjects1.length = 0;
gdjs._49_45BackrCode.GDpipeObjects2.length = 0;
gdjs._49_45BackrCode.GDStacyObjects1.length = 0;
gdjs._49_45BackrCode.GDStacyObjects2.length = 0;
gdjs._49_45BackrCode.GDShadedDarkJoystickObjects1.length = 0;
gdjs._49_45BackrCode.GDShadedDarkJoystickObjects2.length = 0;
gdjs._49_45BackrCode.GDNewSpriteObjects1.length = 0;
gdjs._49_45BackrCode.GDNewSpriteObjects2.length = 0;
gdjs._49_45BackrCode.GDNewSprite9Objects1.length = 0;
gdjs._49_45BackrCode.GDNewSprite9Objects2.length = 0;
gdjs._49_45BackrCode.GDMountain_9595dewObjects1.length = 0;
gdjs._49_45BackrCode.GDMountain_9595dewObjects2.length = 0;
gdjs._49_45BackrCode.GDNewSprite10Objects1.length = 0;
gdjs._49_45BackrCode.GDNewSprite10Objects2.length = 0;
gdjs._49_45BackrCode.GDJumpObjects1.length = 0;
gdjs._49_45BackrCode.GDJumpObjects2.length = 0;
gdjs._49_45BackrCode.GDTreeObjects1.length = 0;
gdjs._49_45BackrCode.GDTreeObjects2.length = 0;
gdjs._49_45BackrCode.GDPauseObjects1.length = 0;
gdjs._49_45BackrCode.GDPauseObjects2.length = 0;
gdjs._49_45BackrCode.GDMOuseclickObjects1.length = 0;
gdjs._49_45BackrCode.GDMOuseclickObjects2.length = 0;
gdjs._49_45BackrCode.GDNewTextObjects1.length = 0;
gdjs._49_45BackrCode.GDNewTextObjects2.length = 0;
gdjs._49_45BackrCode.GDNewSprite2Objects1.length = 0;
gdjs._49_45BackrCode.GDNewSprite2Objects2.length = 0;
gdjs._49_45BackrCode.GDNewSprite11Objects1.length = 0;
gdjs._49_45BackrCode.GDNewSprite11Objects2.length = 0;
gdjs._49_45BackrCode.GDNewSprite12Objects1.length = 0;
gdjs._49_45BackrCode.GDNewSprite12Objects2.length = 0;
gdjs._49_45BackrCode.GDNewSprite13Objects1.length = 0;
gdjs._49_45BackrCode.GDNewSprite13Objects2.length = 0;
gdjs._49_45BackrCode.GDspikenotvisiObjects1.length = 0;
gdjs._49_45BackrCode.GDspikenotvisiObjects2.length = 0;
gdjs._49_45BackrCode.GDBoomObjects1.length = 0;
gdjs._49_45BackrCode.GDBoomObjects2.length = 0;
gdjs._49_45BackrCode.GDNew3DBoxObjects1.length = 0;
gdjs._49_45BackrCode.GDNew3DBoxObjects2.length = 0;
gdjs._49_45BackrCode.GDLoadanimObjects1.length = 0;
gdjs._49_45BackrCode.GDLoadanimObjects2.length = 0;
gdjs._49_45BackrCode.GDNewSprite14Objects1.length = 0;
gdjs._49_45BackrCode.GDNewSprite14Objects2.length = 0;
gdjs._49_45BackrCode.GDBushesObjects1.length = 0;
gdjs._49_45BackrCode.GDBushesObjects2.length = 0;
gdjs._49_45BackrCode.GDNewSprite15Objects1.length = 0;
gdjs._49_45BackrCode.GDNewSprite15Objects2.length = 0;


return;

}

gdjs['_49_45BackrCode'] = gdjs._49_45BackrCode;
