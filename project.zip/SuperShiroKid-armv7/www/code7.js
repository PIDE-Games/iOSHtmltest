gdjs._50Code = {};
gdjs._50Code.localVariables = [];
gdjs._50Code.idToCallbackMap = new Map();
gdjs._50Code.GDPlayerObjects1= [];
gdjs._50Code.GDPlayerObjects2= [];
gdjs._50Code.GDCoinsObjects1= [];
gdjs._50Code.GDCoinsObjects2= [];
gdjs._50Code.GDPlatform_9595GroundObjects1= [];
gdjs._50Code.GDPlatform_9595GroundObjects2= [];
gdjs._50Code.GDNewSprite4Objects1= [];
gdjs._50Code.GDNewSprite4Objects2= [];
gdjs._50Code.GDNewSprite5Objects1= [];
gdjs._50Code.GDNewSprite5Objects2= [];
gdjs._50Code.GDNewSprite6Objects1= [];
gdjs._50Code.GDNewSprite6Objects2= [];
gdjs._50Code.GDspikeObjects1= [];
gdjs._50Code.GDspikeObjects2= [];
gdjs._50Code.GDNewSprite7Objects1= [];
gdjs._50Code.GDNewSprite7Objects2= [];
gdjs._50Code.GDNewSprite8Objects1= [];
gdjs._50Code.GDNewSprite8Objects2= [];
gdjs._50Code.GDNewSprite3Objects1= [];
gdjs._50Code.GDNewSprite3Objects2= [];
gdjs._50Code.GDpipeObjects1= [];
gdjs._50Code.GDpipeObjects2= [];
gdjs._50Code.GDStacyObjects1= [];
gdjs._50Code.GDStacyObjects2= [];
gdjs._50Code.GDShadedDarkJoystickObjects1= [];
gdjs._50Code.GDShadedDarkJoystickObjects2= [];
gdjs._50Code.GDNewSpriteObjects1= [];
gdjs._50Code.GDNewSpriteObjects2= [];
gdjs._50Code.GDNewSprite9Objects1= [];
gdjs._50Code.GDNewSprite9Objects2= [];
gdjs._50Code.GDMountain_9595dewObjects1= [];
gdjs._50Code.GDMountain_9595dewObjects2= [];
gdjs._50Code.GDNewSprite10Objects1= [];
gdjs._50Code.GDNewSprite10Objects2= [];
gdjs._50Code.GDJumpObjects1= [];
gdjs._50Code.GDJumpObjects2= [];
gdjs._50Code.GDTreeObjects1= [];
gdjs._50Code.GDTreeObjects2= [];
gdjs._50Code.GDPauseObjects1= [];
gdjs._50Code.GDPauseObjects2= [];
gdjs._50Code.GDMOuseclickObjects1= [];
gdjs._50Code.GDMOuseclickObjects2= [];
gdjs._50Code.GDNewTextObjects1= [];
gdjs._50Code.GDNewTextObjects2= [];
gdjs._50Code.GDNewSprite2Objects1= [];
gdjs._50Code.GDNewSprite2Objects2= [];
gdjs._50Code.GDNewSprite11Objects1= [];
gdjs._50Code.GDNewSprite11Objects2= [];
gdjs._50Code.GDNewSprite12Objects1= [];
gdjs._50Code.GDNewSprite12Objects2= [];
gdjs._50Code.GDNewSprite13Objects1= [];
gdjs._50Code.GDNewSprite13Objects2= [];
gdjs._50Code.GDspikenotvisiObjects1= [];
gdjs._50Code.GDspikenotvisiObjects2= [];
gdjs._50Code.GDBoomObjects1= [];
gdjs._50Code.GDBoomObjects2= [];
gdjs._50Code.GDNew3DBoxObjects1= [];
gdjs._50Code.GDNew3DBoxObjects2= [];
gdjs._50Code.GDLoadanimObjects1= [];
gdjs._50Code.GDLoadanimObjects2= [];
gdjs._50Code.GDNewSprite14Objects1= [];
gdjs._50Code.GDNewSprite14Objects2= [];
gdjs._50Code.GDBushesObjects1= [];
gdjs._50Code.GDBushesObjects2= [];
gdjs._50Code.GDNewSprite15Objects1= [];
gdjs._50Code.GDNewSprite15Objects2= [];
gdjs._50Code.GDSurpsObjects1= [];
gdjs._50Code.GDSurpsObjects2= [];
gdjs._50Code.GDTreeplatformObjects1= [];
gdjs._50Code.GDTreeplatformObjects2= [];
gdjs._50Code.GDDeathObjects1= [];
gdjs._50Code.GDDeathObjects2= [];
gdjs._50Code.GDmenublockObjects1= [];
gdjs._50Code.GDmenublockObjects2= [];


gdjs._50Code.mapOfGDgdjs_9546_959550Code_9546GDPlayerObjects1Objects = Hashtable.newFrom({"Player": gdjs._50Code.GDPlayerObjects1});
gdjs._50Code.mapOfGDgdjs_9546_959550Code_9546GDCoinsObjects1Objects = Hashtable.newFrom({"Coins": gdjs._50Code.GDCoinsObjects1});
gdjs._50Code.mapOfGDgdjs_9546_959550Code_9546GDPlayerObjects1Objects = Hashtable.newFrom({"Player": gdjs._50Code.GDPlayerObjects1});
gdjs._50Code.mapOfGDgdjs_9546_959550Code_9546GDNewSprite11Objects1Objects = Hashtable.newFrom({"NewSprite11": gdjs._50Code.GDNewSprite11Objects1});
gdjs._50Code.mapOfGDgdjs_9546_959550Code_9546GDPlayerObjects1Objects = Hashtable.newFrom({"Player": gdjs._50Code.GDPlayerObjects1});
gdjs._50Code.mapOfGDgdjs_9546_959550Code_9546GDNewSprite4Objects1Objects = Hashtable.newFrom({"NewSprite4": gdjs._50Code.GDNewSprite4Objects1});
gdjs._50Code.mapOfGDgdjs_9546_959550Code_9546GDPlayerObjects1Objects = Hashtable.newFrom({"Player": gdjs._50Code.GDPlayerObjects1});
gdjs._50Code.mapOfGDgdjs_9546_959550Code_9546GDNewSprite11Objects1Objects = Hashtable.newFrom({"NewSprite11": gdjs._50Code.GDNewSprite11Objects1});
gdjs._50Code.mapOfGDgdjs_9546_959550Code_9546GDPlayerObjects1Objects = Hashtable.newFrom({"Player": gdjs._50Code.GDPlayerObjects1});
gdjs._50Code.mapOfGDgdjs_9546_959550Code_9546GDDeathObjects1Objects = Hashtable.newFrom({"Death": gdjs._50Code.GDDeathObjects1});
gdjs._50Code.mapOfGDgdjs_9546_959550Code_9546GDPlayerObjects1Objects = Hashtable.newFrom({"Player": gdjs._50Code.GDPlayerObjects1});
gdjs._50Code.mapOfGDgdjs_9546_959550Code_9546GDNewSprite4Objects1Objects = Hashtable.newFrom({"NewSprite4": gdjs._50Code.GDNewSprite4Objects1});
gdjs._50Code.mapOfGDgdjs_9546_959550Code_9546GDPlayerObjects1Objects = Hashtable.newFrom({"Player": gdjs._50Code.GDPlayerObjects1});
gdjs._50Code.mapOfGDgdjs_9546_959550Code_9546GDspikeObjects1Objects = Hashtable.newFrom({"spike": gdjs._50Code.GDspikeObjects1});
gdjs._50Code.mapOfGDgdjs_9546_959550Code_9546GDPlayerObjects1Objects = Hashtable.newFrom({"Player": gdjs._50Code.GDPlayerObjects1});
gdjs._50Code.mapOfGDgdjs_9546_959550Code_9546GDspikeObjects1Objects = Hashtable.newFrom({"spike": gdjs._50Code.GDspikeObjects1});
gdjs._50Code.mapOfGDgdjs_9546_959550Code_9546GDPlayerObjects1Objects = Hashtable.newFrom({"Player": gdjs._50Code.GDPlayerObjects1});
gdjs._50Code.mapOfGDgdjs_9546_959550Code_9546GDPlatform_95959595GroundObjects1Objects = Hashtable.newFrom({"Platform_Ground": gdjs._50Code.GDPlatform_9595GroundObjects1});
gdjs._50Code.mapOfGDgdjs_9546_959550Code_9546GDPlayerObjects1Objects = Hashtable.newFrom({"Player": gdjs._50Code.GDPlayerObjects1});
gdjs._50Code.mapOfGDgdjs_9546_959550Code_9546GDPlatform_95959595GroundObjects1Objects = Hashtable.newFrom({"Platform_Ground": gdjs._50Code.GDPlatform_9595GroundObjects1});
gdjs._50Code.mapOfGDgdjs_9546_959550Code_9546GDPlayerObjects1Objects = Hashtable.newFrom({"Player": gdjs._50Code.GDPlayerObjects1});
gdjs._50Code.mapOfGDgdjs_9546_959550Code_9546GDspikeObjects1Objects = Hashtable.newFrom({"spike": gdjs._50Code.GDspikeObjects1});
gdjs._50Code.mapOfGDgdjs_9546_959550Code_9546GDPlayerObjects1Objects = Hashtable.newFrom({"Player": gdjs._50Code.GDPlayerObjects1});
gdjs._50Code.mapOfGDgdjs_9546_959550Code_9546GDNewSprite14Objects1Objects = Hashtable.newFrom({"NewSprite14": gdjs._50Code.GDNewSprite14Objects1});
gdjs._50Code.mapOfGDgdjs_9546_959550Code_9546GDPlayerObjects1Objects = Hashtable.newFrom({"Player": gdjs._50Code.GDPlayerObjects1});
gdjs._50Code.mapOfGDgdjs_9546_959550Code_9546GDNewSprite15Objects1Objects = Hashtable.newFrom({"NewSprite15": gdjs._50Code.GDNewSprite15Objects1});
gdjs._50Code.mapOfGDgdjs_9546_959550Code_9546GDPlayerObjects1Objects = Hashtable.newFrom({"Player": gdjs._50Code.GDPlayerObjects1});
gdjs._50Code.mapOfGDgdjs_9546_959550Code_9546GDDeathObjects1Objects = Hashtable.newFrom({"Death": gdjs._50Code.GDDeathObjects1});
gdjs._50Code.mapOfGDgdjs_9546_959550Code_9546GDPlayerObjects1Objects = Hashtable.newFrom({"Player": gdjs._50Code.GDPlayerObjects1});
gdjs._50Code.mapOfGDgdjs_9546_959550Code_9546GDmenublockObjects1Objects = Hashtable.newFrom({"menublock": gdjs._50Code.GDmenublockObjects1});
gdjs._50Code.mapOfGDgdjs_9546_959550Code_9546GDPlayerObjects1Objects = Hashtable.newFrom({"Player": gdjs._50Code.GDPlayerObjects1});
gdjs._50Code.mapOfGDgdjs_9546_959550Code_9546GDDeathObjects1Objects = Hashtable.newFrom({"Death": gdjs._50Code.GDDeathObjects1});
gdjs._50Code.mapOfGDgdjs_9546_959550Code_9546GDPlayerObjects1Objects = Hashtable.newFrom({"Player": gdjs._50Code.GDPlayerObjects1});
gdjs._50Code.mapOfGDgdjs_9546_959550Code_9546GDDeathObjects1Objects = Hashtable.newFrom({"Death": gdjs._50Code.GDDeathObjects1});
gdjs._50Code.mapOfGDgdjs_9546_959550Code_9546GDPlayerObjects1Objects = Hashtable.newFrom({"Player": gdjs._50Code.GDPlayerObjects1});
gdjs._50Code.mapOfGDgdjs_9546_959550Code_9546GDDeathObjects1Objects = Hashtable.newFrom({"Death": gdjs._50Code.GDDeathObjects1});
gdjs._50Code.mapOfGDgdjs_9546_959550Code_9546GDPlayerObjects1Objects = Hashtable.newFrom({"Player": gdjs._50Code.GDPlayerObjects1});
gdjs._50Code.mapOfGDgdjs_9546_959550Code_9546GDTreeplatformObjects1Objects = Hashtable.newFrom({"Treeplatform": gdjs._50Code.GDTreeplatformObjects1});
gdjs._50Code.mapOfGDgdjs_9546_959550Code_9546GDPlayerObjects1Objects = Hashtable.newFrom({"Player": gdjs._50Code.GDPlayerObjects1});
gdjs._50Code.mapOfGDgdjs_9546_959550Code_9546GDTreeplatformObjects1Objects = Hashtable.newFrom({"Treeplatform": gdjs._50Code.GDTreeplatformObjects1});
gdjs._50Code.mapOfGDgdjs_9546_959550Code_9546GDPlayerObjects1Objects = Hashtable.newFrom({"Player": gdjs._50Code.GDPlayerObjects1});
gdjs._50Code.mapOfGDgdjs_9546_959550Code_9546GDSurpsObjects1Objects = Hashtable.newFrom({"Surps": gdjs._50Code.GDSurpsObjects1});
gdjs._50Code.mapOfGDgdjs_9546_959550Code_9546GDPlayerObjects1Objects = Hashtable.newFrom({"Player": gdjs._50Code.GDPlayerObjects1});
gdjs._50Code.mapOfGDgdjs_9546_959550Code_9546GDSurpsObjects1Objects = Hashtable.newFrom({"Surps": gdjs._50Code.GDSurpsObjects1});
gdjs._50Code.mapOfGDgdjs_9546_959550Code_9546GDSurpsObjects1Objects = Hashtable.newFrom({"Surps": gdjs._50Code.GDSurpsObjects1});
gdjs._50Code.mapOfGDgdjs_9546_959550Code_9546GDNewSprite11Objects1Objects = Hashtable.newFrom({"NewSprite11": gdjs._50Code.GDNewSprite11Objects1});
gdjs._50Code.mapOfGDgdjs_9546_959550Code_9546GDStacyObjects1Objects = Hashtable.newFrom({"Stacy": gdjs._50Code.GDStacyObjects1});
gdjs._50Code.mapOfGDgdjs_9546_959550Code_9546GDNewSprite11Objects1Objects = Hashtable.newFrom({"NewSprite11": gdjs._50Code.GDNewSprite11Objects1});
gdjs._50Code.mapOfGDgdjs_9546_959550Code_9546GDPlayerObjects1Objects = Hashtable.newFrom({"Player": gdjs._50Code.GDPlayerObjects1});
gdjs._50Code.mapOfGDgdjs_9546_959550Code_9546GDspikeObjects1Objects = Hashtable.newFrom({"spike": gdjs._50Code.GDspikeObjects1});
gdjs._50Code.mapOfGDgdjs_9546_959550Code_9546GDPlayerObjects1Objects = Hashtable.newFrom({"Player": gdjs._50Code.GDPlayerObjects1});
gdjs._50Code.mapOfGDgdjs_9546_959550Code_9546GDspikeObjects1Objects = Hashtable.newFrom({"spike": gdjs._50Code.GDspikeObjects1});
gdjs._50Code.mapOfGDgdjs_9546_959550Code_9546GDPlayerObjects1Objects = Hashtable.newFrom({"Player": gdjs._50Code.GDPlayerObjects1});
gdjs._50Code.mapOfGDgdjs_9546_959550Code_9546GDDeathObjects1Objects = Hashtable.newFrom({"Death": gdjs._50Code.GDDeathObjects1});
gdjs._50Code.mapOfGDgdjs_9546_959550Code_9546GDPlayerObjects1Objects = Hashtable.newFrom({"Player": gdjs._50Code.GDPlayerObjects1});
gdjs._50Code.mapOfGDgdjs_9546_959550Code_9546GDspikeObjects1Objects = Hashtable.newFrom({"spike": gdjs._50Code.GDspikeObjects1});
gdjs._50Code.mapOfGDgdjs_9546_959550Code_9546GDPlayerObjects1Objects = Hashtable.newFrom({"Player": gdjs._50Code.GDPlayerObjects1});
gdjs._50Code.mapOfGDgdjs_9546_959550Code_9546GDspikeObjects1Objects = Hashtable.newFrom({"spike": gdjs._50Code.GDspikeObjects1});
gdjs._50Code.eventsList0 = function(runtimeScene) {

{


let isConditionTrue_0 = false;
{
{gdjs.evtTools.camera.setCameraZoom(runtimeScene, 2.5, "", 0);
}
{gdjs.evtTools.camera.setCameraZoom(runtimeScene, 2.5, "Background", 0);
}
}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.runtimeScene.sceneJustBegins(runtimeScene);
if (isConditionTrue_0) {
}

}


{

gdjs.copyArray(runtimeScene.getObjects("Coins"), gdjs._50Code.GDCoinsObjects1);
gdjs.copyArray(runtimeScene.getObjects("Player"), gdjs._50Code.GDPlayerObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs._50Code.mapOfGDgdjs_9546_959550Code_9546GDPlayerObjects1Objects, gdjs._50Code.mapOfGDgdjs_9546_959550Code_9546GDCoinsObjects1Objects, false, runtimeScene, false);
if (isConditionTrue_0) {
/* Reuse gdjs._50Code.GDCoinsObjects1 */
{for(var i = 0, len = gdjs._50Code.GDCoinsObjects1.length ;i < len;++i) {
    gdjs._50Code.GDCoinsObjects1[i].deleteFromScene(runtimeScene);
}
}
{gdjs.evtTools.sound.playSound(runtimeScene, "Coin.wav", false, 100, 1);
}
}

}


{

gdjs.copyArray(runtimeScene.getObjects("Player"), gdjs._50Code.GDPlayerObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs._50Code.GDPlayerObjects1.length;i<l;++i) {
    if ( gdjs._50Code.GDPlayerObjects1[i].getBehavior("PlatformerObject").isOnFloor() ) {
        isConditionTrue_0 = true;
        gdjs._50Code.GDPlayerObjects1[k] = gdjs._50Code.GDPlayerObjects1[i];
        ++k;
    }
}
gdjs._50Code.GDPlayerObjects1.length = k;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs._50Code.GDPlayerObjects1.length;i<l;++i) {
    if ( !(gdjs._50Code.GDPlayerObjects1[i].getBehavior("PlatformerObject").isMovingEvenALittle()) ) {
        isConditionTrue_0 = true;
        gdjs._50Code.GDPlayerObjects1[k] = gdjs._50Code.GDPlayerObjects1[i];
        ++k;
    }
}
gdjs._50Code.GDPlayerObjects1.length = k;
}
if (isConditionTrue_0) {
/* Reuse gdjs._50Code.GDPlayerObjects1 */
{for(var i = 0, len = gdjs._50Code.GDPlayerObjects1.length ;i < len;++i) {
    gdjs._50Code.GDPlayerObjects1[i].getBehavior("Animation").setAnimationName("Idle");
}
}
}

}


{

gdjs.copyArray(runtimeScene.getObjects("Player"), gdjs._50Code.GDPlayerObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs._50Code.GDPlayerObjects1.length;i<l;++i) {
    if ( gdjs._50Code.GDPlayerObjects1[i].getBehavior("PlatformerObject").isMovingEvenALittle() ) {
        isConditionTrue_0 = true;
        gdjs._50Code.GDPlayerObjects1[k] = gdjs._50Code.GDPlayerObjects1[i];
        ++k;
    }
}
gdjs._50Code.GDPlayerObjects1.length = k;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs._50Code.GDPlayerObjects1.length;i<l;++i) {
    if ( gdjs._50Code.GDPlayerObjects1[i].getBehavior("PlatformerObject").isOnFloor() ) {
        isConditionTrue_0 = true;
        gdjs._50Code.GDPlayerObjects1[k] = gdjs._50Code.GDPlayerObjects1[i];
        ++k;
    }
}
gdjs._50Code.GDPlayerObjects1.length = k;
}
if (isConditionTrue_0) {
/* Reuse gdjs._50Code.GDPlayerObjects1 */
{for(var i = 0, len = gdjs._50Code.GDPlayerObjects1.length ;i < len;++i) {
    gdjs._50Code.GDPlayerObjects1[i].getBehavior("Animation").setAnimationName("Running");
}
}
}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.isKeyPressed(runtimeScene, "Left");
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("Player"), gdjs._50Code.GDPlayerObjects1);
{for(var i = 0, len = gdjs._50Code.GDPlayerObjects1.length ;i < len;++i) {
    gdjs._50Code.GDPlayerObjects1[i].getBehavior("Flippable").flipX(true);
}
}
}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.isKeyPressed(runtimeScene, "Right");
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("Player"), gdjs._50Code.GDPlayerObjects1);
{for(var i = 0, len = gdjs._50Code.GDPlayerObjects1.length ;i < len;++i) {
    gdjs._50Code.GDPlayerObjects1[i].getBehavior("Flippable").flipX(false);
}
}
}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.isKeyPressed(runtimeScene, "Left");
if (isConditionTrue_0) {
}

}


{


let isConditionTrue_0 = false;
{
}

}


{


let isConditionTrue_0 = false;
{
}

}


{

gdjs.copyArray(runtimeScene.getObjects("NewSprite11"), gdjs._50Code.GDNewSprite11Objects1);
gdjs.copyArray(runtimeScene.getObjects("Player"), gdjs._50Code.GDPlayerObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs._50Code.mapOfGDgdjs_9546_959550Code_9546GDPlayerObjects1Objects, gdjs._50Code.mapOfGDgdjs_9546_959550Code_9546GDNewSprite11Objects1Objects, false, runtimeScene, false);
if (isConditionTrue_0) {
{gdjs.evtTools.sound.playSound(runtimeScene, "TaDa.wav", false, 100, 1);
}
}

}


{

gdjs.copyArray(runtimeScene.getObjects("Player"), gdjs._50Code.GDPlayerObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs._50Code.GDPlayerObjects1.length;i<l;++i) {
    if ( gdjs._50Code.GDPlayerObjects1[i].getBehavior("PlatformerObject").isUsingControl("Left") ) {
        isConditionTrue_0 = true;
        gdjs._50Code.GDPlayerObjects1[k] = gdjs._50Code.GDPlayerObjects1[i];
        ++k;
    }
}
gdjs._50Code.GDPlayerObjects1.length = k;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs._50Code.GDPlayerObjects1.length;i<l;++i) {
    if ( !(gdjs._50Code.GDPlayerObjects1[i].getBehavior("PlatformerObject").isUsingControl("Right")) ) {
        isConditionTrue_0 = true;
        gdjs._50Code.GDPlayerObjects1[k] = gdjs._50Code.GDPlayerObjects1[i];
        ++k;
    }
}
gdjs._50Code.GDPlayerObjects1.length = k;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs._50Code.GDPlayerObjects1.length;i<l;++i) {
    if ( gdjs._50Code.GDPlayerObjects1[i].getBehavior("PlatformerObject").isUsingControl("Left") ) {
        isConditionTrue_0 = true;
        gdjs._50Code.GDPlayerObjects1[k] = gdjs._50Code.GDPlayerObjects1[i];
        ++k;
    }
}
gdjs._50Code.GDPlayerObjects1.length = k;
}
}
if (isConditionTrue_0) {
/* Reuse gdjs._50Code.GDPlayerObjects1 */
{for(var i = 0, len = gdjs._50Code.GDPlayerObjects1.length ;i < len;++i) {
    gdjs._50Code.GDPlayerObjects1[i].getBehavior("Flippable").flipX(false);
}
}
{for(var i = 0, len = gdjs._50Code.GDPlayerObjects1.length ;i < len;++i) {
    gdjs._50Code.GDPlayerObjects1[i].getBehavior("Flippable").flipX(false);
}
}
{for(var i = 0, len = gdjs._50Code.GDPlayerObjects1.length ;i < len;++i) {
    gdjs._50Code.GDPlayerObjects1[i].getBehavior("Flippable").flipX(true);
}
}
}

}


{

gdjs.copyArray(runtimeScene.getObjects("Player"), gdjs._50Code.GDPlayerObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs._50Code.GDPlayerObjects1.length;i<l;++i) {
    if ( gdjs._50Code.GDPlayerObjects1[i].getBehavior("PlatformerObject").isUsingControl("Right") ) {
        isConditionTrue_0 = true;
        gdjs._50Code.GDPlayerObjects1[k] = gdjs._50Code.GDPlayerObjects1[i];
        ++k;
    }
}
gdjs._50Code.GDPlayerObjects1.length = k;
if (isConditionTrue_0) {
/* Reuse gdjs._50Code.GDPlayerObjects1 */
{for(var i = 0, len = gdjs._50Code.GDPlayerObjects1.length ;i < len;++i) {
    gdjs._50Code.GDPlayerObjects1[i].getBehavior("Flippable").flipX(false);
}
}
}

}


{

gdjs.copyArray(runtimeScene.getObjects("Jump"), gdjs._50Code.GDJumpObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs._50Code.GDJumpObjects1.length;i<l;++i) {
    if ( gdjs._50Code.GDJumpObjects1[i].getBehavior("ButtonFSM").IsPressed(null) ) {
        isConditionTrue_0 = true;
        gdjs._50Code.GDJumpObjects1[k] = gdjs._50Code.GDJumpObjects1[i];
        ++k;
    }
}
gdjs._50Code.GDJumpObjects1.length = k;
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("Player"), gdjs._50Code.GDPlayerObjects1);
{for(var i = 0, len = gdjs._50Code.GDPlayerObjects1.length ;i < len;++i) {
    gdjs._50Code.GDPlayerObjects1[i].getBehavior("PlatformerObject").simulateJumpKey();
}
}
}

}


{

gdjs.copyArray(runtimeScene.getObjects("NewSprite4"), gdjs._50Code.GDNewSprite4Objects1);
gdjs.copyArray(runtimeScene.getObjects("Player"), gdjs._50Code.GDPlayerObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs._50Code.mapOfGDgdjs_9546_959550Code_9546GDPlayerObjects1Objects, gdjs._50Code.mapOfGDgdjs_9546_959550Code_9546GDNewSprite4Objects1Objects, false, runtimeScene, false);
if (isConditionTrue_0) {
/* Reuse gdjs._50Code.GDPlayerObjects1 */
{for(var i = 0, len = gdjs._50Code.GDPlayerObjects1.length ;i < len;++i) {
    gdjs._50Code.GDPlayerObjects1[i].getBehavior("PlatformerObject").simulateRightKey();
}
}
}

}


{

gdjs.copyArray(runtimeScene.getObjects("NewSprite11"), gdjs._50Code.GDNewSprite11Objects1);
gdjs.copyArray(runtimeScene.getObjects("Player"), gdjs._50Code.GDPlayerObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs._50Code.mapOfGDgdjs_9546_959550Code_9546GDPlayerObjects1Objects, gdjs._50Code.mapOfGDgdjs_9546_959550Code_9546GDNewSprite11Objects1Objects, false, runtimeScene, false);
if (isConditionTrue_0) {
{gdjs.evtTools.runtimeScene.replaceScene(runtimeScene, "2End", false);
}
}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.runtimeScene.sceneJustBegins(runtimeScene);
if (isConditionTrue_0) {
{gdjs.evtTools.sound.playMusicOnChannel(runtimeScene, "Cherry hills.mp3", 2, true, 100, 1);
}
}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.runtimeScene.sceneJustBegins(runtimeScene);
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("NewSprite10"), gdjs._50Code.GDNewSprite10Objects1);
{for(var i = 0, len = gdjs._50Code.GDNewSprite10Objects1.length ;i < len;++i) {
    gdjs._50Code.GDNewSprite10Objects1[i].hide();
}
}
}

}


{

gdjs.copyArray(runtimeScene.getObjects("Death"), gdjs._50Code.GDDeathObjects1);
gdjs.copyArray(runtimeScene.getObjects("Player"), gdjs._50Code.GDPlayerObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.distanceTest(gdjs._50Code.mapOfGDgdjs_9546_959550Code_9546GDPlayerObjects1Objects, gdjs._50Code.mapOfGDgdjs_9546_959550Code_9546GDDeathObjects1Objects, 0.1, false);
if (isConditionTrue_0) {
/* Reuse gdjs._50Code.GDPlayerObjects1 */
{for(var i = 0, len = gdjs._50Code.GDPlayerObjects1.length ;i < len;++i) {
    gdjs._50Code.GDPlayerObjects1[i].deleteFromScene(runtimeScene);
}
}
}

}


{

gdjs.copyArray(runtimeScene.getObjects("Player"), gdjs._50Code.GDPlayerObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs._50Code.GDPlayerObjects1.length;i<l;++i) {
    if ( gdjs._50Code.GDPlayerObjects1[i].getBehavior("PlatformerObject").isJumping() ) {
        isConditionTrue_0 = true;
        gdjs._50Code.GDPlayerObjects1[k] = gdjs._50Code.GDPlayerObjects1[i];
        ++k;
    }
}
gdjs._50Code.GDPlayerObjects1.length = k;
if (isConditionTrue_0) {
/* Reuse gdjs._50Code.GDPlayerObjects1 */
{for(var i = 0, len = gdjs._50Code.GDPlayerObjects1.length ;i < len;++i) {
    gdjs._50Code.GDPlayerObjects1[i].getBehavior("Animation").setAnimationName("Jumping jacks");
}
}
}

}


{

gdjs.copyArray(runtimeScene.getObjects("Player"), gdjs._50Code.GDPlayerObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs._50Code.GDPlayerObjects1.length;i<l;++i) {
    if ( gdjs._50Code.GDPlayerObjects1[i].getBehavior("PlatformerObject").isFalling() ) {
        isConditionTrue_0 = true;
        gdjs._50Code.GDPlayerObjects1[k] = gdjs._50Code.GDPlayerObjects1[i];
        ++k;
    }
}
gdjs._50Code.GDPlayerObjects1.length = k;
if (isConditionTrue_0) {
/* Reuse gdjs._50Code.GDPlayerObjects1 */
{for(var i = 0, len = gdjs._50Code.GDPlayerObjects1.length ;i < len;++i) {
    gdjs._50Code.GDPlayerObjects1[i].getBehavior("Animation").setAnimationName("Fall");
}
}
}

}


{


let isConditionTrue_0 = false;
{
}

}


{

gdjs.copyArray(runtimeScene.getObjects("Pause"), gdjs._50Code.GDPauseObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs._50Code.GDPauseObjects1.length;i<l;++i) {
    if ( gdjs._50Code.GDPauseObjects1[i].getBehavior("ButtonFSM").IsPressed(null) ) {
        isConditionTrue_0 = true;
        gdjs._50Code.GDPauseObjects1[k] = gdjs._50Code.GDPauseObjects1[i];
        ++k;
    }
}
gdjs._50Code.GDPauseObjects1.length = k;
if (isConditionTrue_0) {
{gdjs.evtTools.runtimeScene.replaceScene(runtimeScene, "Settings", false);
}
}

}


{

gdjs.copyArray(runtimeScene.getObjects("NewSprite4"), gdjs._50Code.GDNewSprite4Objects1);
gdjs.copyArray(runtimeScene.getObjects("Player"), gdjs._50Code.GDPlayerObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs._50Code.mapOfGDgdjs_9546_959550Code_9546GDPlayerObjects1Objects, gdjs._50Code.mapOfGDgdjs_9546_959550Code_9546GDNewSprite4Objects1Objects, false, runtimeScene, false);
if (isConditionTrue_0) {
/* Reuse gdjs._50Code.GDNewSprite4Objects1 */
{for(var i = 0, len = gdjs._50Code.GDNewSprite4Objects1.length ;i < len;++i) {
    gdjs._50Code.GDNewSprite4Objects1[i].getBehavior("Animation").setAnimationName("cool");
}
}
}

}


{


let isConditionTrue_0 = false;
{
}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtsExt__Gamepads__C_Axis_pushed.func(runtimeScene, 1, "Left", "Any", null);
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("Jump"), gdjs._50Code.GDJumpObjects1);
gdjs.copyArray(runtimeScene.getObjects("ShadedDarkJoystick"), gdjs._50Code.GDShadedDarkJoystickObjects1);
{for(var i = 0, len = gdjs._50Code.GDShadedDarkJoystickObjects1.length ;i < len;++i) {
    gdjs._50Code.GDShadedDarkJoystickObjects1[i].deleteFromScene(runtimeScene);
}
}
{for(var i = 0, len = gdjs._50Code.GDJumpObjects1.length ;i < len;++i) {
    gdjs._50Code.GDJumpObjects1[i].deleteFromScene(runtimeScene);
}
}
}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.anyKeyPressed(runtimeScene);
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("Jump"), gdjs._50Code.GDJumpObjects1);
gdjs.copyArray(runtimeScene.getObjects("ShadedDarkJoystick"), gdjs._50Code.GDShadedDarkJoystickObjects1);
{for(var i = 0, len = gdjs._50Code.GDShadedDarkJoystickObjects1.length ;i < len;++i) {
    gdjs._50Code.GDShadedDarkJoystickObjects1[i].deleteFromScene(runtimeScene);
}
}
{for(var i = 0, len = gdjs._50Code.GDJumpObjects1.length ;i < len;++i) {
    gdjs._50Code.GDJumpObjects1[i].deleteFromScene(runtimeScene);
}
}
}

}


{

gdjs.copyArray(runtimeScene.getObjects("Player"), gdjs._50Code.GDPlayerObjects1);
gdjs.copyArray(runtimeScene.getObjects("spike"), gdjs._50Code.GDspikeObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.platform.isOnPlatform(gdjs._50Code.mapOfGDgdjs_9546_959550Code_9546GDPlayerObjects1Objects, "PlatformerObject", gdjs._50Code.mapOfGDgdjs_9546_959550Code_9546GDspikeObjects1Objects, false);
if (isConditionTrue_0) {
/* Reuse gdjs._50Code.GDPlayerObjects1 */
{for(var i = 0, len = gdjs._50Code.GDPlayerObjects1.length ;i < len;++i) {
    gdjs._50Code.GDPlayerObjects1[i].getBehavior("LinearMovement").SetSpeedY(-200, null);
}
}
}

}


{

gdjs.copyArray(runtimeScene.getObjects("Player"), gdjs._50Code.GDPlayerObjects1);
gdjs.copyArray(runtimeScene.getObjects("spike"), gdjs._50Code.GDspikeObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.platform.isOnPlatform(gdjs._50Code.mapOfGDgdjs_9546_959550Code_9546GDPlayerObjects1Objects, "PlatformerObject", gdjs._50Code.mapOfGDgdjs_9546_959550Code_9546GDspikeObjects1Objects, false);
if (isConditionTrue_0) {
/* Reuse gdjs._50Code.GDPlayerObjects1 */
{for(var i = 0, len = gdjs._50Code.GDPlayerObjects1.length ;i < len;++i) {
    gdjs._50Code.GDPlayerObjects1[i].getBehavior("LinearMovement").SetSpeedX(-100, null);
}
}
}

}


{

gdjs.copyArray(runtimeScene.getObjects("Platform_Ground"), gdjs._50Code.GDPlatform_9595GroundObjects1);
gdjs.copyArray(runtimeScene.getObjects("Player"), gdjs._50Code.GDPlayerObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.platform.isOnPlatform(gdjs._50Code.mapOfGDgdjs_9546_959550Code_9546GDPlayerObjects1Objects, "PlatformerObject", gdjs._50Code.mapOfGDgdjs_9546_959550Code_9546GDPlatform_95959595GroundObjects1Objects, false);
if (isConditionTrue_0) {
/* Reuse gdjs._50Code.GDPlayerObjects1 */
{for(var i = 0, len = gdjs._50Code.GDPlayerObjects1.length ;i < len;++i) {
    gdjs._50Code.GDPlayerObjects1[i].getBehavior("LinearMovement").SetSpeedX(0, null);
}
}
}

}


{


let isConditionTrue_0 = false;
{
}

}


{

gdjs.copyArray(runtimeScene.getObjects("Platform_Ground"), gdjs._50Code.GDPlatform_9595GroundObjects1);
gdjs.copyArray(runtimeScene.getObjects("Player"), gdjs._50Code.GDPlayerObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.platform.isOnPlatform(gdjs._50Code.mapOfGDgdjs_9546_959550Code_9546GDPlayerObjects1Objects, "PlatformerObject", gdjs._50Code.mapOfGDgdjs_9546_959550Code_9546GDPlatform_95959595GroundObjects1Objects, false);
if (isConditionTrue_0) {
/* Reuse gdjs._50Code.GDPlayerObjects1 */
{for(var i = 0, len = gdjs._50Code.GDPlayerObjects1.length ;i < len;++i) {
    gdjs._50Code.GDPlayerObjects1[i].getBehavior("LinearMovement").SetSpeedY(0, null);
}
}
}

}


{

gdjs.copyArray(runtimeScene.getObjects("Player"), gdjs._50Code.GDPlayerObjects1);
gdjs.copyArray(runtimeScene.getObjects("spike"), gdjs._50Code.GDspikeObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs._50Code.mapOfGDgdjs_9546_959550Code_9546GDPlayerObjects1Objects, gdjs._50Code.mapOfGDgdjs_9546_959550Code_9546GDspikeObjects1Objects, false, runtimeScene, false);
if (isConditionTrue_0) {
/* Reuse gdjs._50Code.GDPlayerObjects1 */
{for(var i = 0, len = gdjs._50Code.GDPlayerObjects1.length ;i < len;++i) {
    gdjs._50Code.GDPlayerObjects1[i].getBehavior("Animation").setAnimationName("Die");
}
}
}

}


{


let isConditionTrue_0 = false;
{
}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.runtimeScene.sceneJustBegins(runtimeScene);
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("Loadanim"), gdjs._50Code.GDLoadanimObjects1);
{for(var i = 0, len = gdjs._50Code.GDLoadanimObjects1.length ;i < len;++i) {
    gdjs._50Code.GDLoadanimObjects1[i].hide();
}
}
}

}


{

gdjs.copyArray(runtimeScene.getObjects("NewSprite14"), gdjs._50Code.GDNewSprite14Objects1);
gdjs.copyArray(runtimeScene.getObjects("Player"), gdjs._50Code.GDPlayerObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs._50Code.mapOfGDgdjs_9546_959550Code_9546GDPlayerObjects1Objects, gdjs._50Code.mapOfGDgdjs_9546_959550Code_9546GDNewSprite14Objects1Objects, false, runtimeScene, false);
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("Loadanim"), gdjs._50Code.GDLoadanimObjects1);
{for(var i = 0, len = gdjs._50Code.GDLoadanimObjects1.length ;i < len;++i) {
    gdjs._50Code.GDLoadanimObjects1[i].hide(false);
}
}
}

}


{

gdjs.copyArray(runtimeScene.getObjects("NewSprite15"), gdjs._50Code.GDNewSprite15Objects1);
gdjs.copyArray(runtimeScene.getObjects("Player"), gdjs._50Code.GDPlayerObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs._50Code.mapOfGDgdjs_9546_959550Code_9546GDPlayerObjects1Objects, gdjs._50Code.mapOfGDgdjs_9546_959550Code_9546GDNewSprite15Objects1Objects, false, runtimeScene, false);
if (isConditionTrue_0) {
{gdjs.evtTools.runtimeScene.replaceScene(runtimeScene, "TestLevel", false);
}
}

}


{

gdjs.copyArray(runtimeScene.getObjects("Death"), gdjs._50Code.GDDeathObjects1);
gdjs.copyArray(runtimeScene.getObjects("Player"), gdjs._50Code.GDPlayerObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs._50Code.mapOfGDgdjs_9546_959550Code_9546GDPlayerObjects1Objects, gdjs._50Code.mapOfGDgdjs_9546_959550Code_9546GDDeathObjects1Objects, false, runtimeScene, false);
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("NewSprite10"), gdjs._50Code.GDNewSprite10Objects1);
{for(var i = 0, len = gdjs._50Code.GDNewSprite10Objects1.length ;i < len;++i) {
    gdjs._50Code.GDNewSprite10Objects1[i].hide(false);
}
}
}

}


{

gdjs.copyArray(runtimeScene.getObjects("Player"), gdjs._50Code.GDPlayerObjects1);
gdjs.copyArray(runtimeScene.getObjects("menublock"), gdjs._50Code.GDmenublockObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs._50Code.mapOfGDgdjs_9546_959550Code_9546GDPlayerObjects1Objects, gdjs._50Code.mapOfGDgdjs_9546_959550Code_9546GDmenublockObjects1Objects, false, runtimeScene, false);
if (isConditionTrue_0) {
{gdjs.evtTools.runtimeScene.replaceScene(runtimeScene, "2", false);
}
}

}


{

gdjs.copyArray(runtimeScene.getObjects("NewSprite10"), gdjs._50Code.GDNewSprite10Objects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs._50Code.GDNewSprite10Objects1.length;i<l;++i) {
    if ( gdjs._50Code.GDNewSprite10Objects1[i].isVisible() ) {
        isConditionTrue_0 = true;
        gdjs._50Code.GDNewSprite10Objects1[k] = gdjs._50Code.GDNewSprite10Objects1[i];
        ++k;
    }
}
gdjs._50Code.GDNewSprite10Objects1.length = k;
if (isConditionTrue_0) {
{gdjs.evtTools.sound.playSoundOnChannel(runtimeScene, "oof.mp3", 16, false, 50, 1);
}
}

}


{

gdjs.copyArray(runtimeScene.getObjects("Death"), gdjs._50Code.GDDeathObjects1);
gdjs.copyArray(runtimeScene.getObjects("Player"), gdjs._50Code.GDPlayerObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs._50Code.mapOfGDgdjs_9546_959550Code_9546GDPlayerObjects1Objects, gdjs._50Code.mapOfGDgdjs_9546_959550Code_9546GDDeathObjects1Objects, false, runtimeScene, false);
if (isConditionTrue_0) {
/* Reuse gdjs._50Code.GDPlayerObjects1 */
{for(var i = 0, len = gdjs._50Code.GDPlayerObjects1.length ;i < len;++i) {
    gdjs._50Code.GDPlayerObjects1[i].getBehavior("Animation").setAnimationName("Die");
}
}
}

}


{

gdjs.copyArray(runtimeScene.getObjects("Death"), gdjs._50Code.GDDeathObjects1);
gdjs.copyArray(runtimeScene.getObjects("Player"), gdjs._50Code.GDPlayerObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs._50Code.mapOfGDgdjs_9546_959550Code_9546GDPlayerObjects1Objects, gdjs._50Code.mapOfGDgdjs_9546_959550Code_9546GDDeathObjects1Objects, false, runtimeScene, false);
if (isConditionTrue_0) {
{gdjs.evtTools.sound.stopMusicOnChannel(runtimeScene, 2);
}
}

}


{

gdjs.copyArray(runtimeScene.getObjects("Death"), gdjs._50Code.GDDeathObjects1);
gdjs.copyArray(runtimeScene.getObjects("Player"), gdjs._50Code.GDPlayerObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs._50Code.mapOfGDgdjs_9546_959550Code_9546GDPlayerObjects1Objects, gdjs._50Code.mapOfGDgdjs_9546_959550Code_9546GDDeathObjects1Objects, false, runtimeScene, false);
if (isConditionTrue_0) {
/* Reuse gdjs._50Code.GDPlayerObjects1 */
{for(var i = 0, len = gdjs._50Code.GDPlayerObjects1.length ;i < len;++i) {
    gdjs._50Code.GDPlayerObjects1[i].getBehavior("SmoothCamera").SetDownwardSpeed(0, null);
}
}
}

}


{

gdjs.copyArray(runtimeScene.getObjects("Player"), gdjs._50Code.GDPlayerObjects1);
gdjs.copyArray(runtimeScene.getObjects("Treeplatform"), gdjs._50Code.GDTreeplatformObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.platform.isOnPlatform(gdjs._50Code.mapOfGDgdjs_9546_959550Code_9546GDPlayerObjects1Objects, "PlatformerObject", gdjs._50Code.mapOfGDgdjs_9546_959550Code_9546GDTreeplatformObjects1Objects, false);
if (isConditionTrue_0) {
/* Reuse gdjs._50Code.GDPlayerObjects1 */
{for(var i = 0, len = gdjs._50Code.GDPlayerObjects1.length ;i < len;++i) {
    gdjs._50Code.GDPlayerObjects1[i].getBehavior("LinearMovement").SetSpeedY(0, null);
}
}
}

}


{

gdjs.copyArray(runtimeScene.getObjects("Player"), gdjs._50Code.GDPlayerObjects1);
gdjs.copyArray(runtimeScene.getObjects("Treeplatform"), gdjs._50Code.GDTreeplatformObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.platform.isOnPlatform(gdjs._50Code.mapOfGDgdjs_9546_959550Code_9546GDPlayerObjects1Objects, "PlatformerObject", gdjs._50Code.mapOfGDgdjs_9546_959550Code_9546GDTreeplatformObjects1Objects, false);
if (isConditionTrue_0) {
/* Reuse gdjs._50Code.GDPlayerObjects1 */
{for(var i = 0, len = gdjs._50Code.GDPlayerObjects1.length ;i < len;++i) {
    gdjs._50Code.GDPlayerObjects1[i].getBehavior("LinearMovement").SetSpeedX(0, null);
}
}
}

}


{

gdjs.copyArray(runtimeScene.getObjects("Player"), gdjs._50Code.GDPlayerObjects1);
gdjs.copyArray(runtimeScene.getObjects("Surps"), gdjs._50Code.GDSurpsObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs._50Code.mapOfGDgdjs_9546_959550Code_9546GDPlayerObjects1Objects, gdjs._50Code.mapOfGDgdjs_9546_959550Code_9546GDSurpsObjects1Objects, false, runtimeScene, false);
if (isConditionTrue_0) {
/* Reuse gdjs._50Code.GDSurpsObjects1 */
{for(var i = 0, len = gdjs._50Code.GDSurpsObjects1.length ;i < len;++i) {
    gdjs._50Code.GDSurpsObjects1[i].addForce(100, 0, 1);
}
}
}

}


{

gdjs.copyArray(runtimeScene.getObjects("Surps"), gdjs._50Code.GDSurpsObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs._50Code.GDSurpsObjects1.length;i<l;++i) {
    if ( gdjs._50Code.GDSurpsObjects1[i].getAverageForce().getLength() == 100 ) {
        isConditionTrue_0 = true;
        gdjs._50Code.GDSurpsObjects1[k] = gdjs._50Code.GDSurpsObjects1[i];
        ++k;
    }
}
gdjs._50Code.GDSurpsObjects1.length = k;
if (isConditionTrue_0) {
/* Reuse gdjs._50Code.GDSurpsObjects1 */
{for(var i = 0, len = gdjs._50Code.GDSurpsObjects1.length ;i < len;++i) {
    gdjs._50Code.GDSurpsObjects1[i].getBehavior("Animation").setAnimationName("Run");
}
}
}

}


{

gdjs.copyArray(runtimeScene.getObjects("Stacy"), gdjs._50Code.GDStacyObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs._50Code.GDStacyObjects1.length;i<l;++i) {
    if ( gdjs._50Code.GDStacyObjects1[i].getAverageForce().getLength() == 100 ) {
        isConditionTrue_0 = true;
        gdjs._50Code.GDStacyObjects1[k] = gdjs._50Code.GDStacyObjects1[i];
        ++k;
    }
}
gdjs._50Code.GDStacyObjects1.length = k;
if (isConditionTrue_0) {
/* Reuse gdjs._50Code.GDStacyObjects1 */
{for(var i = 0, len = gdjs._50Code.GDStacyObjects1.length ;i < len;++i) {
    gdjs._50Code.GDStacyObjects1[i].getBehavior("Animation").setAnimationName("Back");
}
}
}

}


{

gdjs.copyArray(runtimeScene.getObjects("Player"), gdjs._50Code.GDPlayerObjects1);
gdjs.copyArray(runtimeScene.getObjects("Surps"), gdjs._50Code.GDSurpsObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs._50Code.mapOfGDgdjs_9546_959550Code_9546GDPlayerObjects1Objects, gdjs._50Code.mapOfGDgdjs_9546_959550Code_9546GDSurpsObjects1Objects, false, runtimeScene, false);
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("Stacy"), gdjs._50Code.GDStacyObjects1);
{for(var i = 0, len = gdjs._50Code.GDStacyObjects1.length ;i < len;++i) {
    gdjs._50Code.GDStacyObjects1[i].addForce(100, 0, 1);
}
}
}

}


{

gdjs.copyArray(runtimeScene.getObjects("NewSprite11"), gdjs._50Code.GDNewSprite11Objects1);
gdjs.copyArray(runtimeScene.getObjects("Surps"), gdjs._50Code.GDSurpsObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs._50Code.mapOfGDgdjs_9546_959550Code_9546GDSurpsObjects1Objects, gdjs._50Code.mapOfGDgdjs_9546_959550Code_9546GDNewSprite11Objects1Objects, false, runtimeScene, false);
if (isConditionTrue_0) {
/* Reuse gdjs._50Code.GDSurpsObjects1 */
{for(var i = 0, len = gdjs._50Code.GDSurpsObjects1.length ;i < len;++i) {
    gdjs._50Code.GDSurpsObjects1[i].addForce(0, 0, 1);
}
}
}

}


{

gdjs.copyArray(runtimeScene.getObjects("NewSprite11"), gdjs._50Code.GDNewSprite11Objects1);
gdjs.copyArray(runtimeScene.getObjects("Stacy"), gdjs._50Code.GDStacyObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs._50Code.mapOfGDgdjs_9546_959550Code_9546GDStacyObjects1Objects, gdjs._50Code.mapOfGDgdjs_9546_959550Code_9546GDNewSprite11Objects1Objects, false, runtimeScene, false);
if (isConditionTrue_0) {
/* Reuse gdjs._50Code.GDStacyObjects1 */
{for(var i = 0, len = gdjs._50Code.GDStacyObjects1.length ;i < len;++i) {
    gdjs._50Code.GDStacyObjects1[i].addForce(0, 0, 1);
}
}
}

}


{

gdjs.copyArray(runtimeScene.getObjects("Player"), gdjs._50Code.GDPlayerObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs._50Code.GDPlayerObjects1.length;i<l;++i) {
    if ( gdjs._50Code.GDPlayerObjects1[i].getAnimationFrame() == 1 ) {
        isConditionTrue_0 = true;
        gdjs._50Code.GDPlayerObjects1[k] = gdjs._50Code.GDPlayerObjects1[i];
        ++k;
    }
}
gdjs._50Code.GDPlayerObjects1.length = k;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs._50Code.GDPlayerObjects1.length;i<l;++i) {
    if ( gdjs._50Code.GDPlayerObjects1[i].getBehavior("Animation").getAnimationName() == "Jumping jacks" ) {
        isConditionTrue_0 = true;
        gdjs._50Code.GDPlayerObjects1[k] = gdjs._50Code.GDPlayerObjects1[i];
        ++k;
    }
}
gdjs._50Code.GDPlayerObjects1.length = k;
}
if (isConditionTrue_0) {
{gdjs.evtTools.sound.playSoundOnChannel(runtimeScene, "Jumbin.wav", 11, false, 100, 1);
}
}

}


{

gdjs.copyArray(runtimeScene.getObjects("Player"), gdjs._50Code.GDPlayerObjects1);
gdjs.copyArray(runtimeScene.getObjects("spike"), gdjs._50Code.GDspikeObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs._50Code.mapOfGDgdjs_9546_959550Code_9546GDPlayerObjects1Objects, gdjs._50Code.mapOfGDgdjs_9546_959550Code_9546GDspikeObjects1Objects, false, runtimeScene, false);
if (isConditionTrue_0) {
/* Reuse gdjs._50Code.GDPlayerObjects1 */
{for(var i = 0, len = gdjs._50Code.GDPlayerObjects1.length ;i < len;++i) {
    gdjs._50Code.GDPlayerObjects1[i].getBehavior("SmoothCamera").SetUpwardSpeed(0, null);
}
}
{for(var i = 0, len = gdjs._50Code.GDPlayerObjects1.length ;i < len;++i) {
    gdjs._50Code.GDPlayerObjects1[i].getBehavior("SmoothCamera").SetLeftwardSpeed(0, null);
}
}
{for(var i = 0, len = gdjs._50Code.GDPlayerObjects1.length ;i < len;++i) {
    gdjs._50Code.GDPlayerObjects1[i].getBehavior("SmoothCamera").SetDownwardSpeedMax(0, null);
}
}
}

}


{

gdjs.copyArray(runtimeScene.getObjects("Player"), gdjs._50Code.GDPlayerObjects1);
gdjs.copyArray(runtimeScene.getObjects("spike"), gdjs._50Code.GDspikeObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs._50Code.mapOfGDgdjs_9546_959550Code_9546GDPlayerObjects1Objects, gdjs._50Code.mapOfGDgdjs_9546_959550Code_9546GDspikeObjects1Objects, false, runtimeScene, false);
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("NewSprite7"), gdjs._50Code.GDNewSprite7Objects1);
gdjs.copyArray(runtimeScene.getObjects("Platform_Ground"), gdjs._50Code.GDPlatform_9595GroundObjects1);
{for(var i = 0, len = gdjs._50Code.GDPlatform_9595GroundObjects1.length ;i < len;++i) {
    gdjs._50Code.GDPlatform_9595GroundObjects1[i].activateBehavior("Platform", false);
}
}
{for(var i = 0, len = gdjs._50Code.GDNewSprite7Objects1.length ;i < len;++i) {
    gdjs._50Code.GDNewSprite7Objects1[i].activateBehavior("Platform", false);
}
}
}

}


{

gdjs.copyArray(runtimeScene.getObjects("Death"), gdjs._50Code.GDDeathObjects1);
gdjs.copyArray(runtimeScene.getObjects("Player"), gdjs._50Code.GDPlayerObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs._50Code.mapOfGDgdjs_9546_959550Code_9546GDPlayerObjects1Objects, gdjs._50Code.mapOfGDgdjs_9546_959550Code_9546GDDeathObjects1Objects, false, runtimeScene, false);
if (isConditionTrue_0) {
/* Reuse gdjs._50Code.GDPlayerObjects1 */
{for(var i = 0, len = gdjs._50Code.GDPlayerObjects1.length ;i < len;++i) {
    gdjs._50Code.GDPlayerObjects1[i].getBehavior("Animation").setAnimationName("Die");
}
}
{for(var i = 0, len = gdjs._50Code.GDPlayerObjects1.length ;i < len;++i) {
    gdjs._50Code.GDPlayerObjects1[i].getBehavior("Animation").pauseAnimation();
}
}
}

}


{

gdjs.copyArray(runtimeScene.getObjects("Player"), gdjs._50Code.GDPlayerObjects1);
gdjs.copyArray(runtimeScene.getObjects("spike"), gdjs._50Code.GDspikeObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs._50Code.mapOfGDgdjs_9546_959550Code_9546GDPlayerObjects1Objects, gdjs._50Code.mapOfGDgdjs_9546_959550Code_9546GDspikeObjects1Objects, false, runtimeScene, false);
if (isConditionTrue_0) {
/* Reuse gdjs._50Code.GDPlayerObjects1 */
{for(var i = 0, len = gdjs._50Code.GDPlayerObjects1.length ;i < len;++i) {
    gdjs._50Code.GDPlayerObjects1[i].getBehavior("PlatformerObject").ignoreDefaultControls(true);
}
}
}

}


{

gdjs.copyArray(runtimeScene.getObjects("Player"), gdjs._50Code.GDPlayerObjects1);
gdjs.copyArray(runtimeScene.getObjects("spike"), gdjs._50Code.GDspikeObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs._50Code.mapOfGDgdjs_9546_959550Code_9546GDPlayerObjects1Objects, gdjs._50Code.mapOfGDgdjs_9546_959550Code_9546GDspikeObjects1Objects, false, runtimeScene, false);
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("Treeplatform"), gdjs._50Code.GDTreeplatformObjects1);
{for(var i = 0, len = gdjs._50Code.GDTreeplatformObjects1.length ;i < len;++i) {
    gdjs._50Code.GDTreeplatformObjects1[i].activateBehavior("Platform", false);
}
}
}

}


{


let isConditionTrue_0 = false;
{
}

}


};

gdjs._50Code.func = function(runtimeScene) {
runtimeScene.getOnceTriggers().startNewFrame();

gdjs._50Code.GDPlayerObjects1.length = 0;
gdjs._50Code.GDPlayerObjects2.length = 0;
gdjs._50Code.GDCoinsObjects1.length = 0;
gdjs._50Code.GDCoinsObjects2.length = 0;
gdjs._50Code.GDPlatform_9595GroundObjects1.length = 0;
gdjs._50Code.GDPlatform_9595GroundObjects2.length = 0;
gdjs._50Code.GDNewSprite4Objects1.length = 0;
gdjs._50Code.GDNewSprite4Objects2.length = 0;
gdjs._50Code.GDNewSprite5Objects1.length = 0;
gdjs._50Code.GDNewSprite5Objects2.length = 0;
gdjs._50Code.GDNewSprite6Objects1.length = 0;
gdjs._50Code.GDNewSprite6Objects2.length = 0;
gdjs._50Code.GDspikeObjects1.length = 0;
gdjs._50Code.GDspikeObjects2.length = 0;
gdjs._50Code.GDNewSprite7Objects1.length = 0;
gdjs._50Code.GDNewSprite7Objects2.length = 0;
gdjs._50Code.GDNewSprite8Objects1.length = 0;
gdjs._50Code.GDNewSprite8Objects2.length = 0;
gdjs._50Code.GDNewSprite3Objects1.length = 0;
gdjs._50Code.GDNewSprite3Objects2.length = 0;
gdjs._50Code.GDpipeObjects1.length = 0;
gdjs._50Code.GDpipeObjects2.length = 0;
gdjs._50Code.GDStacyObjects1.length = 0;
gdjs._50Code.GDStacyObjects2.length = 0;
gdjs._50Code.GDShadedDarkJoystickObjects1.length = 0;
gdjs._50Code.GDShadedDarkJoystickObjects2.length = 0;
gdjs._50Code.GDNewSpriteObjects1.length = 0;
gdjs._50Code.GDNewSpriteObjects2.length = 0;
gdjs._50Code.GDNewSprite9Objects1.length = 0;
gdjs._50Code.GDNewSprite9Objects2.length = 0;
gdjs._50Code.GDMountain_9595dewObjects1.length = 0;
gdjs._50Code.GDMountain_9595dewObjects2.length = 0;
gdjs._50Code.GDNewSprite10Objects1.length = 0;
gdjs._50Code.GDNewSprite10Objects2.length = 0;
gdjs._50Code.GDJumpObjects1.length = 0;
gdjs._50Code.GDJumpObjects2.length = 0;
gdjs._50Code.GDTreeObjects1.length = 0;
gdjs._50Code.GDTreeObjects2.length = 0;
gdjs._50Code.GDPauseObjects1.length = 0;
gdjs._50Code.GDPauseObjects2.length = 0;
gdjs._50Code.GDMOuseclickObjects1.length = 0;
gdjs._50Code.GDMOuseclickObjects2.length = 0;
gdjs._50Code.GDNewTextObjects1.length = 0;
gdjs._50Code.GDNewTextObjects2.length = 0;
gdjs._50Code.GDNewSprite2Objects1.length = 0;
gdjs._50Code.GDNewSprite2Objects2.length = 0;
gdjs._50Code.GDNewSprite11Objects1.length = 0;
gdjs._50Code.GDNewSprite11Objects2.length = 0;
gdjs._50Code.GDNewSprite12Objects1.length = 0;
gdjs._50Code.GDNewSprite12Objects2.length = 0;
gdjs._50Code.GDNewSprite13Objects1.length = 0;
gdjs._50Code.GDNewSprite13Objects2.length = 0;
gdjs._50Code.GDspikenotvisiObjects1.length = 0;
gdjs._50Code.GDspikenotvisiObjects2.length = 0;
gdjs._50Code.GDBoomObjects1.length = 0;
gdjs._50Code.GDBoomObjects2.length = 0;
gdjs._50Code.GDNew3DBoxObjects1.length = 0;
gdjs._50Code.GDNew3DBoxObjects2.length = 0;
gdjs._50Code.GDLoadanimObjects1.length = 0;
gdjs._50Code.GDLoadanimObjects2.length = 0;
gdjs._50Code.GDNewSprite14Objects1.length = 0;
gdjs._50Code.GDNewSprite14Objects2.length = 0;
gdjs._50Code.GDBushesObjects1.length = 0;
gdjs._50Code.GDBushesObjects2.length = 0;
gdjs._50Code.GDNewSprite15Objects1.length = 0;
gdjs._50Code.GDNewSprite15Objects2.length = 0;
gdjs._50Code.GDSurpsObjects1.length = 0;
gdjs._50Code.GDSurpsObjects2.length = 0;
gdjs._50Code.GDTreeplatformObjects1.length = 0;
gdjs._50Code.GDTreeplatformObjects2.length = 0;
gdjs._50Code.GDDeathObjects1.length = 0;
gdjs._50Code.GDDeathObjects2.length = 0;
gdjs._50Code.GDmenublockObjects1.length = 0;
gdjs._50Code.GDmenublockObjects2.length = 0;

gdjs._50Code.eventsList0(runtimeScene);
gdjs._50Code.GDPlayerObjects1.length = 0;
gdjs._50Code.GDPlayerObjects2.length = 0;
gdjs._50Code.GDCoinsObjects1.length = 0;
gdjs._50Code.GDCoinsObjects2.length = 0;
gdjs._50Code.GDPlatform_9595GroundObjects1.length = 0;
gdjs._50Code.GDPlatform_9595GroundObjects2.length = 0;
gdjs._50Code.GDNewSprite4Objects1.length = 0;
gdjs._50Code.GDNewSprite4Objects2.length = 0;
gdjs._50Code.GDNewSprite5Objects1.length = 0;
gdjs._50Code.GDNewSprite5Objects2.length = 0;
gdjs._50Code.GDNewSprite6Objects1.length = 0;
gdjs._50Code.GDNewSprite6Objects2.length = 0;
gdjs._50Code.GDspikeObjects1.length = 0;
gdjs._50Code.GDspikeObjects2.length = 0;
gdjs._50Code.GDNewSprite7Objects1.length = 0;
gdjs._50Code.GDNewSprite7Objects2.length = 0;
gdjs._50Code.GDNewSprite8Objects1.length = 0;
gdjs._50Code.GDNewSprite8Objects2.length = 0;
gdjs._50Code.GDNewSprite3Objects1.length = 0;
gdjs._50Code.GDNewSprite3Objects2.length = 0;
gdjs._50Code.GDpipeObjects1.length = 0;
gdjs._50Code.GDpipeObjects2.length = 0;
gdjs._50Code.GDStacyObjects1.length = 0;
gdjs._50Code.GDStacyObjects2.length = 0;
gdjs._50Code.GDShadedDarkJoystickObjects1.length = 0;
gdjs._50Code.GDShadedDarkJoystickObjects2.length = 0;
gdjs._50Code.GDNewSpriteObjects1.length = 0;
gdjs._50Code.GDNewSpriteObjects2.length = 0;
gdjs._50Code.GDNewSprite9Objects1.length = 0;
gdjs._50Code.GDNewSprite9Objects2.length = 0;
gdjs._50Code.GDMountain_9595dewObjects1.length = 0;
gdjs._50Code.GDMountain_9595dewObjects2.length = 0;
gdjs._50Code.GDNewSprite10Objects1.length = 0;
gdjs._50Code.GDNewSprite10Objects2.length = 0;
gdjs._50Code.GDJumpObjects1.length = 0;
gdjs._50Code.GDJumpObjects2.length = 0;
gdjs._50Code.GDTreeObjects1.length = 0;
gdjs._50Code.GDTreeObjects2.length = 0;
gdjs._50Code.GDPauseObjects1.length = 0;
gdjs._50Code.GDPauseObjects2.length = 0;
gdjs._50Code.GDMOuseclickObjects1.length = 0;
gdjs._50Code.GDMOuseclickObjects2.length = 0;
gdjs._50Code.GDNewTextObjects1.length = 0;
gdjs._50Code.GDNewTextObjects2.length = 0;
gdjs._50Code.GDNewSprite2Objects1.length = 0;
gdjs._50Code.GDNewSprite2Objects2.length = 0;
gdjs._50Code.GDNewSprite11Objects1.length = 0;
gdjs._50Code.GDNewSprite11Objects2.length = 0;
gdjs._50Code.GDNewSprite12Objects1.length = 0;
gdjs._50Code.GDNewSprite12Objects2.length = 0;
gdjs._50Code.GDNewSprite13Objects1.length = 0;
gdjs._50Code.GDNewSprite13Objects2.length = 0;
gdjs._50Code.GDspikenotvisiObjects1.length = 0;
gdjs._50Code.GDspikenotvisiObjects2.length = 0;
gdjs._50Code.GDBoomObjects1.length = 0;
gdjs._50Code.GDBoomObjects2.length = 0;
gdjs._50Code.GDNew3DBoxObjects1.length = 0;
gdjs._50Code.GDNew3DBoxObjects2.length = 0;
gdjs._50Code.GDLoadanimObjects1.length = 0;
gdjs._50Code.GDLoadanimObjects2.length = 0;
gdjs._50Code.GDNewSprite14Objects1.length = 0;
gdjs._50Code.GDNewSprite14Objects2.length = 0;
gdjs._50Code.GDBushesObjects1.length = 0;
gdjs._50Code.GDBushesObjects2.length = 0;
gdjs._50Code.GDNewSprite15Objects1.length = 0;
gdjs._50Code.GDNewSprite15Objects2.length = 0;
gdjs._50Code.GDSurpsObjects1.length = 0;
gdjs._50Code.GDSurpsObjects2.length = 0;
gdjs._50Code.GDTreeplatformObjects1.length = 0;
gdjs._50Code.GDTreeplatformObjects2.length = 0;
gdjs._50Code.GDDeathObjects1.length = 0;
gdjs._50Code.GDDeathObjects2.length = 0;
gdjs._50Code.GDmenublockObjects1.length = 0;
gdjs._50Code.GDmenublockObjects2.length = 0;


return;

}

gdjs['_50Code'] = gdjs._50Code;
