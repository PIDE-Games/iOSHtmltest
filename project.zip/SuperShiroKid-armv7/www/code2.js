gdjs._491LOADCode = {};
gdjs._491LOADCode.localVariables = [];
gdjs._491LOADCode.idToCallbackMap = new Map();
gdjs._491LOADCode.GD_959511TeamlogoObjects1= [];
gdjs._491LOADCode.GD_959511TeamlogoObjects2= [];
gdjs._491LOADCode.GDTokoObjects1= [];
gdjs._491LOADCode.GDTokoObjects2= [];
gdjs._491LOADCode.GDNewTextObjects1= [];
gdjs._491LOADCode.GDNewTextObjects2= [];
gdjs._491LOADCode.GDNewSpriteObjects1= [];
gdjs._491LOADCode.GDNewSpriteObjects2= [];
gdjs._491LOADCode.GDLoadanimObjects1= [];
gdjs._491LOADCode.GDLoadanimObjects2= [];


gdjs._491LOADCode.eventsList0 = function(runtimeScene) {

{


let isConditionTrue_0 = false;
{
}

}


{

gdjs.copyArray(runtimeScene.getObjects("_11Teamlogo"), gdjs._491LOADCode.GD_959511TeamlogoObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs._491LOADCode.GD_959511TeamlogoObjects1.length;i<l;++i) {
    if ( gdjs._491LOADCode.GD_959511TeamlogoObjects1[i].getBehavior("Animation").hasAnimationEnded() ) {
        isConditionTrue_0 = true;
        gdjs._491LOADCode.GD_959511TeamlogoObjects1[k] = gdjs._491LOADCode.GD_959511TeamlogoObjects1[i];
        ++k;
    }
}
gdjs._491LOADCode.GD_959511TeamlogoObjects1.length = k;
if (isConditionTrue_0) {
{gdjs.evtTools.runtimeScene.replaceScene(runtimeScene, "IntroCutscene", false);
}
}

}


{

gdjs.copyArray(runtimeScene.getObjects("_11Teamlogo"), gdjs._491LOADCode.GD_959511TeamlogoObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs._491LOADCode.GD_959511TeamlogoObjects1.length;i<l;++i) {
    if ( gdjs._491LOADCode.GD_959511TeamlogoObjects1[i].getAnimationFrame() == 10 ) {
        isConditionTrue_0 = true;
        gdjs._491LOADCode.GD_959511TeamlogoObjects1[k] = gdjs._491LOADCode.GD_959511TeamlogoObjects1[i];
        ++k;
    }
}
gdjs._491LOADCode.GD_959511TeamlogoObjects1.length = k;
if (isConditionTrue_0) {
{gdjs.deviceVibration.startVibration(100);
}
}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.runtimeScene.sceneJustBegins(runtimeScene);
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("Loadanim"), gdjs._491LOADCode.GDLoadanimObjects1);
{for(var i = 0, len = gdjs._491LOADCode.GDLoadanimObjects1.length ;i < len;++i) {
    gdjs._491LOADCode.GDLoadanimObjects1[i].hide();
}
}
}

}


{

gdjs.copyArray(runtimeScene.getObjects("_11Teamlogo"), gdjs._491LOADCode.GD_959511TeamlogoObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs._491LOADCode.GD_959511TeamlogoObjects1.length;i<l;++i) {
    if ( gdjs._491LOADCode.GD_959511TeamlogoObjects1[i].getAnimationFrame() == 20 ) {
        isConditionTrue_0 = true;
        gdjs._491LOADCode.GD_959511TeamlogoObjects1[k] = gdjs._491LOADCode.GD_959511TeamlogoObjects1[i];
        ++k;
    }
}
gdjs._491LOADCode.GD_959511TeamlogoObjects1.length = k;
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("Loadanim"), gdjs._491LOADCode.GDLoadanimObjects1);
{for(var i = 0, len = gdjs._491LOADCode.GDLoadanimObjects1.length ;i < len;++i) {
    gdjs._491LOADCode.GDLoadanimObjects1[i].hide(false);
}
}
}

}


{

gdjs.copyArray(runtimeScene.getObjects("_11Teamlogo"), gdjs._491LOADCode.GD_959511TeamlogoObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs._491LOADCode.GD_959511TeamlogoObjects1.length;i<l;++i) {
    if ( gdjs._491LOADCode.GD_959511TeamlogoObjects1[i].getBehavior("FlashOpacity").HalfPeriodTime(null) == 4 ) {
        isConditionTrue_0 = true;
        gdjs._491LOADCode.GD_959511TeamlogoObjects1[k] = gdjs._491LOADCode.GD_959511TeamlogoObjects1[i];
        ++k;
    }
}
gdjs._491LOADCode.GD_959511TeamlogoObjects1.length = k;
if (isConditionTrue_0) {
/* Reuse gdjs._491LOADCode.GD_959511TeamlogoObjects1 */
{for(var i = 0, len = gdjs._491LOADCode.GD_959511TeamlogoObjects1.length ;i < len;++i) {
    gdjs._491LOADCode.GD_959511TeamlogoObjects1[i].getBehavior("FlashOpacity").Flash("Tween", 0, 0, null);
}
}
}

}


};

gdjs._491LOADCode.func = function(runtimeScene) {
runtimeScene.getOnceTriggers().startNewFrame();

gdjs._491LOADCode.GD_959511TeamlogoObjects1.length = 0;
gdjs._491LOADCode.GD_959511TeamlogoObjects2.length = 0;
gdjs._491LOADCode.GDTokoObjects1.length = 0;
gdjs._491LOADCode.GDTokoObjects2.length = 0;
gdjs._491LOADCode.GDNewTextObjects1.length = 0;
gdjs._491LOADCode.GDNewTextObjects2.length = 0;
gdjs._491LOADCode.GDNewSpriteObjects1.length = 0;
gdjs._491LOADCode.GDNewSpriteObjects2.length = 0;
gdjs._491LOADCode.GDLoadanimObjects1.length = 0;
gdjs._491LOADCode.GDLoadanimObjects2.length = 0;

gdjs._491LOADCode.eventsList0(runtimeScene);
gdjs._491LOADCode.GD_959511TeamlogoObjects1.length = 0;
gdjs._491LOADCode.GD_959511TeamlogoObjects2.length = 0;
gdjs._491LOADCode.GDTokoObjects1.length = 0;
gdjs._491LOADCode.GDTokoObjects2.length = 0;
gdjs._491LOADCode.GDNewTextObjects1.length = 0;
gdjs._491LOADCode.GDNewTextObjects2.length = 0;
gdjs._491LOADCode.GDNewSpriteObjects1.length = 0;
gdjs._491LOADCode.GDNewSpriteObjects2.length = 0;
gdjs._491LOADCode.GDLoadanimObjects1.length = 0;
gdjs._491LOADCode.GDLoadanimObjects2.length = 0;


return;

}

gdjs['_491LOADCode'] = gdjs._491LOADCode;
