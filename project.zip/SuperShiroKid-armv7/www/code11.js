gdjs.VS_32ZoneCode = {};
gdjs.VS_32ZoneCode.localVariables = [];
gdjs.VS_32ZoneCode.idToCallbackMap = new Map();
gdjs.VS_32ZoneCode.GDPlayerObjects1= [];
gdjs.VS_32ZoneCode.GDPlayerObjects2= [];
gdjs.VS_32ZoneCode.GDCoinsObjects1= [];
gdjs.VS_32ZoneCode.GDCoinsObjects2= [];
gdjs.VS_32ZoneCode.GDPlatform_9595GroundObjects1= [];
gdjs.VS_32ZoneCode.GDPlatform_9595GroundObjects2= [];
gdjs.VS_32ZoneCode.GDNewSprite4Objects1= [];
gdjs.VS_32ZoneCode.GDNewSprite4Objects2= [];
gdjs.VS_32ZoneCode.GDNewSprite5Objects1= [];
gdjs.VS_32ZoneCode.GDNewSprite5Objects2= [];
gdjs.VS_32ZoneCode.GDNewSprite6Objects1= [];
gdjs.VS_32ZoneCode.GDNewSprite6Objects2= [];
gdjs.VS_32ZoneCode.GDspikeObjects1= [];
gdjs.VS_32ZoneCode.GDspikeObjects2= [];
gdjs.VS_32ZoneCode.GDNewSprite7Objects1= [];
gdjs.VS_32ZoneCode.GDNewSprite7Objects2= [];
gdjs.VS_32ZoneCode.GDNewSprite8Objects1= [];
gdjs.VS_32ZoneCode.GDNewSprite8Objects2= [];
gdjs.VS_32ZoneCode.GDNewSprite3Objects1= [];
gdjs.VS_32ZoneCode.GDNewSprite3Objects2= [];
gdjs.VS_32ZoneCode.GDpipeObjects1= [];
gdjs.VS_32ZoneCode.GDpipeObjects2= [];
gdjs.VS_32ZoneCode.GDStacyObjects1= [];
gdjs.VS_32ZoneCode.GDStacyObjects2= [];
gdjs.VS_32ZoneCode.GDShadedDarkJoystickObjects1= [];
gdjs.VS_32ZoneCode.GDShadedDarkJoystickObjects2= [];
gdjs.VS_32ZoneCode.GDNewSpriteObjects1= [];
gdjs.VS_32ZoneCode.GDNewSpriteObjects2= [];
gdjs.VS_32ZoneCode.GDNewSprite9Objects1= [];
gdjs.VS_32ZoneCode.GDNewSprite9Objects2= [];
gdjs.VS_32ZoneCode.GDMountain_9595dewObjects1= [];
gdjs.VS_32ZoneCode.GDMountain_9595dewObjects2= [];
gdjs.VS_32ZoneCode.GDNewSprite10Objects1= [];
gdjs.VS_32ZoneCode.GDNewSprite10Objects2= [];
gdjs.VS_32ZoneCode.GDJumpObjects1= [];
gdjs.VS_32ZoneCode.GDJumpObjects2= [];
gdjs.VS_32ZoneCode.GDPlayer2Objects1= [];
gdjs.VS_32ZoneCode.GDPlayer2Objects2= [];
gdjs.VS_32ZoneCode.GDfaceObjects1= [];
gdjs.VS_32ZoneCode.GDfaceObjects2= [];
gdjs.VS_32ZoneCode.GDfaceplayer2Objects1= [];
gdjs.VS_32ZoneCode.GDfaceplayer2Objects2= [];
gdjs.VS_32ZoneCode.GDCloudObjects1= [];
gdjs.VS_32ZoneCode.GDCloudObjects2= [];
gdjs.VS_32ZoneCode.GDMOuseclickObjects1= [];
gdjs.VS_32ZoneCode.GDMOuseclickObjects2= [];


gdjs.VS_32ZoneCode.mapOfGDgdjs_9546VS_959532ZoneCode_9546GDPlayerObjects1Objects = Hashtable.newFrom({"Player": gdjs.VS_32ZoneCode.GDPlayerObjects1});
gdjs.VS_32ZoneCode.mapOfGDgdjs_9546VS_959532ZoneCode_9546GDCoinsObjects1Objects = Hashtable.newFrom({"Coins": gdjs.VS_32ZoneCode.GDCoinsObjects1});
gdjs.VS_32ZoneCode.mapOfGDgdjs_9546VS_959532ZoneCode_9546GDPlayerObjects1Objects = Hashtable.newFrom({"Player": gdjs.VS_32ZoneCode.GDPlayerObjects1});
gdjs.VS_32ZoneCode.mapOfGDgdjs_9546VS_959532ZoneCode_9546GDspikeObjects1Objects = Hashtable.newFrom({"spike": gdjs.VS_32ZoneCode.GDspikeObjects1});
gdjs.VS_32ZoneCode.mapOfGDgdjs_9546VS_959532ZoneCode_9546GDPlayerObjects1Objects = Hashtable.newFrom({"Player": gdjs.VS_32ZoneCode.GDPlayerObjects1});
gdjs.VS_32ZoneCode.mapOfGDgdjs_9546VS_959532ZoneCode_9546GDNewSprite4Objects1Objects = Hashtable.newFrom({"NewSprite4": gdjs.VS_32ZoneCode.GDNewSprite4Objects1});
gdjs.VS_32ZoneCode.mapOfGDgdjs_9546VS_959532ZoneCode_9546GDPlayerObjects1Objects = Hashtable.newFrom({"Player": gdjs.VS_32ZoneCode.GDPlayerObjects1});
gdjs.VS_32ZoneCode.mapOfGDgdjs_9546VS_959532ZoneCode_9546GDNewSprite4Objects1Objects = Hashtable.newFrom({"NewSprite4": gdjs.VS_32ZoneCode.GDNewSprite4Objects1});
gdjs.VS_32ZoneCode.mapOfGDgdjs_9546VS_959532ZoneCode_9546GDPlayerObjects1Objects = Hashtable.newFrom({"Player": gdjs.VS_32ZoneCode.GDPlayerObjects1});
gdjs.VS_32ZoneCode.mapOfGDgdjs_9546VS_959532ZoneCode_9546GDNewSprite4Objects1Objects = Hashtable.newFrom({"NewSprite4": gdjs.VS_32ZoneCode.GDNewSprite4Objects1});
gdjs.VS_32ZoneCode.mapOfGDgdjs_9546VS_959532ZoneCode_9546GDPlayerObjects1Objects = Hashtable.newFrom({"Player": gdjs.VS_32ZoneCode.GDPlayerObjects1});
gdjs.VS_32ZoneCode.mapOfGDgdjs_9546VS_959532ZoneCode_9546GDNewSprite4Objects1Objects = Hashtable.newFrom({"NewSprite4": gdjs.VS_32ZoneCode.GDNewSprite4Objects1});
gdjs.VS_32ZoneCode.mapOfGDgdjs_9546VS_959532ZoneCode_9546GDPlayer2Objects1Objects = Hashtable.newFrom({"Player2": gdjs.VS_32ZoneCode.GDPlayer2Objects1});
gdjs.VS_32ZoneCode.mapOfGDgdjs_9546VS_959532ZoneCode_9546GDspikeObjects1Objects = Hashtable.newFrom({"spike": gdjs.VS_32ZoneCode.GDspikeObjects1});
gdjs.VS_32ZoneCode.mapOfGDgdjs_9546VS_959532ZoneCode_9546GDPlayer2Objects1Objects = Hashtable.newFrom({"Player2": gdjs.VS_32ZoneCode.GDPlayer2Objects1});
gdjs.VS_32ZoneCode.mapOfGDgdjs_9546VS_959532ZoneCode_9546GDCoinsObjects1Objects = Hashtable.newFrom({"Coins": gdjs.VS_32ZoneCode.GDCoinsObjects1});
gdjs.VS_32ZoneCode.eventsList0 = function(runtimeScene) {

{


let isConditionTrue_0 = false;
{
{gdjs.evtTools.camera.setCameraZoom(runtimeScene, 2, "", 0);
}
{gdjs.evtTools.camera.setCameraZoom(runtimeScene, 2, "Background", 0);
}
}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.runtimeScene.sceneJustBegins(runtimeScene);
if (isConditionTrue_0) {
{gdjs.evtTools.sound.playMusicOnChannel(runtimeScene, "VS.mp3", 2, true, 50, 1);
}
}

}


{

gdjs.copyArray(runtimeScene.getObjects("Coins"), gdjs.VS_32ZoneCode.GDCoinsObjects1);
gdjs.copyArray(runtimeScene.getObjects("Player"), gdjs.VS_32ZoneCode.GDPlayerObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.VS_32ZoneCode.mapOfGDgdjs_9546VS_959532ZoneCode_9546GDPlayerObjects1Objects, gdjs.VS_32ZoneCode.mapOfGDgdjs_9546VS_959532ZoneCode_9546GDCoinsObjects1Objects, false, runtimeScene, false);
if (isConditionTrue_0) {
/* Reuse gdjs.VS_32ZoneCode.GDCoinsObjects1 */
{for(var i = 0, len = gdjs.VS_32ZoneCode.GDCoinsObjects1.length ;i < len;++i) {
    gdjs.VS_32ZoneCode.GDCoinsObjects1[i].deleteFromScene(runtimeScene);
}
}
{gdjs.evtTools.sound.playSound(runtimeScene, "Coin.wav", false, 100, 1);
}
}

}


{

gdjs.copyArray(runtimeScene.getObjects("Player"), gdjs.VS_32ZoneCode.GDPlayerObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.VS_32ZoneCode.GDPlayerObjects1.length;i<l;++i) {
    if ( gdjs.VS_32ZoneCode.GDPlayerObjects1[i].getBehavior("PlatformerObject").isOnFloor() ) {
        isConditionTrue_0 = true;
        gdjs.VS_32ZoneCode.GDPlayerObjects1[k] = gdjs.VS_32ZoneCode.GDPlayerObjects1[i];
        ++k;
    }
}
gdjs.VS_32ZoneCode.GDPlayerObjects1.length = k;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.VS_32ZoneCode.GDPlayerObjects1.length;i<l;++i) {
    if ( !(gdjs.VS_32ZoneCode.GDPlayerObjects1[i].getBehavior("PlatformerObject").isMovingEvenALittle()) ) {
        isConditionTrue_0 = true;
        gdjs.VS_32ZoneCode.GDPlayerObjects1[k] = gdjs.VS_32ZoneCode.GDPlayerObjects1[i];
        ++k;
    }
}
gdjs.VS_32ZoneCode.GDPlayerObjects1.length = k;
}
if (isConditionTrue_0) {
/* Reuse gdjs.VS_32ZoneCode.GDPlayerObjects1 */
{for(var i = 0, len = gdjs.VS_32ZoneCode.GDPlayerObjects1.length ;i < len;++i) {
    gdjs.VS_32ZoneCode.GDPlayerObjects1[i].getBehavior("Animation").setAnimationName("Idle");
}
}
}

}


{

gdjs.copyArray(runtimeScene.getObjects("Player"), gdjs.VS_32ZoneCode.GDPlayerObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.VS_32ZoneCode.GDPlayerObjects1.length;i<l;++i) {
    if ( gdjs.VS_32ZoneCode.GDPlayerObjects1[i].getBehavior("PlatformerObject").isOnFloor() ) {
        isConditionTrue_0 = true;
        gdjs.VS_32ZoneCode.GDPlayerObjects1[k] = gdjs.VS_32ZoneCode.GDPlayerObjects1[i];
        ++k;
    }
}
gdjs.VS_32ZoneCode.GDPlayerObjects1.length = k;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.VS_32ZoneCode.GDPlayerObjects1.length;i<l;++i) {
    if ( gdjs.VS_32ZoneCode.GDPlayerObjects1[i].getBehavior("PlatformerObject").isMovingEvenALittle() ) {
        isConditionTrue_0 = true;
        gdjs.VS_32ZoneCode.GDPlayerObjects1[k] = gdjs.VS_32ZoneCode.GDPlayerObjects1[i];
        ++k;
    }
}
gdjs.VS_32ZoneCode.GDPlayerObjects1.length = k;
}
if (isConditionTrue_0) {
/* Reuse gdjs.VS_32ZoneCode.GDPlayerObjects1 */
{for(var i = 0, len = gdjs.VS_32ZoneCode.GDPlayerObjects1.length ;i < len;++i) {
    gdjs.VS_32ZoneCode.GDPlayerObjects1[i].getBehavior("Animation").setAnimationName("Running");
}
}
}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.isKeyPressed(runtimeScene, "Left");
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("Player"), gdjs.VS_32ZoneCode.GDPlayerObjects1);
{for(var i = 0, len = gdjs.VS_32ZoneCode.GDPlayerObjects1.length ;i < len;++i) {
    gdjs.VS_32ZoneCode.GDPlayerObjects1[i].getBehavior("Flippable").flipX(true);
}
}
}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.isKeyPressed(runtimeScene, "Right");
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("Player"), gdjs.VS_32ZoneCode.GDPlayerObjects1);
{for(var i = 0, len = gdjs.VS_32ZoneCode.GDPlayerObjects1.length ;i < len;++i) {
    gdjs.VS_32ZoneCode.GDPlayerObjects1[i].getBehavior("Flippable").flipX(false);
}
}
}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.isKeyPressed(runtimeScene, "Left");
if (isConditionTrue_0) {
}

}


{

gdjs.copyArray(runtimeScene.getObjects("Player"), gdjs.VS_32ZoneCode.GDPlayerObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.VS_32ZoneCode.GDPlayerObjects1.length;i<l;++i) {
    if ( gdjs.VS_32ZoneCode.GDPlayerObjects1[i].getBehavior("PlatformerObject").isOnFloor() ) {
        isConditionTrue_0 = true;
        gdjs.VS_32ZoneCode.GDPlayerObjects1[k] = gdjs.VS_32ZoneCode.GDPlayerObjects1[i];
        ++k;
    }
}
gdjs.VS_32ZoneCode.GDPlayerObjects1.length = k;
if (isConditionTrue_0) {
}

}


{

gdjs.copyArray(runtimeScene.getObjects("Player"), gdjs.VS_32ZoneCode.GDPlayerObjects1);
gdjs.copyArray(runtimeScene.getObjects("spike"), gdjs.VS_32ZoneCode.GDspikeObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.VS_32ZoneCode.mapOfGDgdjs_9546VS_959532ZoneCode_9546GDPlayerObjects1Objects, gdjs.VS_32ZoneCode.mapOfGDgdjs_9546VS_959532ZoneCode_9546GDspikeObjects1Objects, false, runtimeScene, false);
if (isConditionTrue_0) {
/* Reuse gdjs.VS_32ZoneCode.GDPlayerObjects1 */
{for(var i = 0, len = gdjs.VS_32ZoneCode.GDPlayerObjects1.length ;i < len;++i) {
    gdjs.VS_32ZoneCode.GDPlayerObjects1[i].deleteFromScene(runtimeScene);
}
}
{gdjs.evtTools.sound.playMusicOnChannel(runtimeScene, "oof.mp3", 3, false, 100, 1);
}
{gdjs.evtTools.sound.pauseMusicOnChannel(runtimeScene, 2);
}
}

}


{

gdjs.copyArray(runtimeScene.getObjects("NewSprite4"), gdjs.VS_32ZoneCode.GDNewSprite4Objects1);
gdjs.copyArray(runtimeScene.getObjects("Player"), gdjs.VS_32ZoneCode.GDPlayerObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.VS_32ZoneCode.mapOfGDgdjs_9546VS_959532ZoneCode_9546GDPlayerObjects1Objects, gdjs.VS_32ZoneCode.mapOfGDgdjs_9546VS_959532ZoneCode_9546GDNewSprite4Objects1Objects, false, runtimeScene, false);
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.VS_32ZoneCode.mapOfGDgdjs_9546VS_959532ZoneCode_9546GDPlayerObjects1Objects, gdjs.VS_32ZoneCode.mapOfGDgdjs_9546VS_959532ZoneCode_9546GDNewSprite4Objects1Objects, false, runtimeScene, false);
}
if (isConditionTrue_0) {
/* Reuse gdjs.VS_32ZoneCode.GDNewSprite4Objects1 */
{for(var i = 0, len = gdjs.VS_32ZoneCode.GDNewSprite4Objects1.length ;i < len;++i) {
    gdjs.VS_32ZoneCode.GDNewSprite4Objects1[i].getBehavior("Animation").setAnimationName("cool");
}
}
{gdjs.evtTools.sound.playSound(runtimeScene, "TaDa.wav", false, 100, 1);
}
}

}


{

gdjs.copyArray(runtimeScene.getObjects("Player"), gdjs.VS_32ZoneCode.GDPlayerObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.VS_32ZoneCode.GDPlayerObjects1.length;i<l;++i) {
    if ( gdjs.VS_32ZoneCode.GDPlayerObjects1[i].getBehavior("PlatformerObject").isUsingControl("Left") ) {
        isConditionTrue_0 = true;
        gdjs.VS_32ZoneCode.GDPlayerObjects1[k] = gdjs.VS_32ZoneCode.GDPlayerObjects1[i];
        ++k;
    }
}
gdjs.VS_32ZoneCode.GDPlayerObjects1.length = k;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.VS_32ZoneCode.GDPlayerObjects1.length;i<l;++i) {
    if ( !(gdjs.VS_32ZoneCode.GDPlayerObjects1[i].getBehavior("PlatformerObject").isUsingControl("Right")) ) {
        isConditionTrue_0 = true;
        gdjs.VS_32ZoneCode.GDPlayerObjects1[k] = gdjs.VS_32ZoneCode.GDPlayerObjects1[i];
        ++k;
    }
}
gdjs.VS_32ZoneCode.GDPlayerObjects1.length = k;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.VS_32ZoneCode.GDPlayerObjects1.length;i<l;++i) {
    if ( gdjs.VS_32ZoneCode.GDPlayerObjects1[i].getBehavior("PlatformerObject").isUsingControl("Left") ) {
        isConditionTrue_0 = true;
        gdjs.VS_32ZoneCode.GDPlayerObjects1[k] = gdjs.VS_32ZoneCode.GDPlayerObjects1[i];
        ++k;
    }
}
gdjs.VS_32ZoneCode.GDPlayerObjects1.length = k;
}
}
if (isConditionTrue_0) {
/* Reuse gdjs.VS_32ZoneCode.GDPlayerObjects1 */
{for(var i = 0, len = gdjs.VS_32ZoneCode.GDPlayerObjects1.length ;i < len;++i) {
    gdjs.VS_32ZoneCode.GDPlayerObjects1[i].getBehavior("Flippable").flipX(false);
}
}
{for(var i = 0, len = gdjs.VS_32ZoneCode.GDPlayerObjects1.length ;i < len;++i) {
    gdjs.VS_32ZoneCode.GDPlayerObjects1[i].getBehavior("Flippable").flipX(false);
}
}
{for(var i = 0, len = gdjs.VS_32ZoneCode.GDPlayerObjects1.length ;i < len;++i) {
    gdjs.VS_32ZoneCode.GDPlayerObjects1[i].getBehavior("Flippable").flipX(true);
}
}
}

}


{

gdjs.copyArray(runtimeScene.getObjects("Player"), gdjs.VS_32ZoneCode.GDPlayerObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.VS_32ZoneCode.GDPlayerObjects1.length;i<l;++i) {
    if ( gdjs.VS_32ZoneCode.GDPlayerObjects1[i].getBehavior("PlatformerObject").isUsingControl("Right") ) {
        isConditionTrue_0 = true;
        gdjs.VS_32ZoneCode.GDPlayerObjects1[k] = gdjs.VS_32ZoneCode.GDPlayerObjects1[i];
        ++k;
    }
}
gdjs.VS_32ZoneCode.GDPlayerObjects1.length = k;
if (isConditionTrue_0) {
/* Reuse gdjs.VS_32ZoneCode.GDPlayerObjects1 */
{for(var i = 0, len = gdjs.VS_32ZoneCode.GDPlayerObjects1.length ;i < len;++i) {
    gdjs.VS_32ZoneCode.GDPlayerObjects1[i].getBehavior("Flippable").flipX(false);
}
}
}

}


{

gdjs.copyArray(runtimeScene.getObjects("Jump"), gdjs.VS_32ZoneCode.GDJumpObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.VS_32ZoneCode.GDJumpObjects1.length;i<l;++i) {
    if ( gdjs.VS_32ZoneCode.GDJumpObjects1[i].getBehavior("ButtonFSM").IsPressed(null) ) {
        isConditionTrue_0 = true;
        gdjs.VS_32ZoneCode.GDJumpObjects1[k] = gdjs.VS_32ZoneCode.GDJumpObjects1[i];
        ++k;
    }
}
gdjs.VS_32ZoneCode.GDJumpObjects1.length = k;
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("Player"), gdjs.VS_32ZoneCode.GDPlayerObjects1);
{for(var i = 0, len = gdjs.VS_32ZoneCode.GDPlayerObjects1.length ;i < len;++i) {
    gdjs.VS_32ZoneCode.GDPlayerObjects1[i].getBehavior("PlatformerObject").simulateJumpKey();
}
}
}

}


{

gdjs.copyArray(runtimeScene.getObjects("NewSprite4"), gdjs.VS_32ZoneCode.GDNewSprite4Objects1);
gdjs.copyArray(runtimeScene.getObjects("Player"), gdjs.VS_32ZoneCode.GDPlayerObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.VS_32ZoneCode.mapOfGDgdjs_9546VS_959532ZoneCode_9546GDPlayerObjects1Objects, gdjs.VS_32ZoneCode.mapOfGDgdjs_9546VS_959532ZoneCode_9546GDNewSprite4Objects1Objects, false, runtimeScene, false);
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("NewSprite"), gdjs.VS_32ZoneCode.GDNewSpriteObjects1);
/* Reuse gdjs.VS_32ZoneCode.GDPlayerObjects1 */
{for(var i = 0, len = gdjs.VS_32ZoneCode.GDPlayerObjects1.length ;i < len;++i) {
    gdjs.VS_32ZoneCode.GDPlayerObjects1[i].addForceTowardObject((gdjs.VS_32ZoneCode.GDNewSpriteObjects1.length !== 0 ? gdjs.VS_32ZoneCode.GDNewSpriteObjects1[0] : null), 20, 0);
}
}
}

}


{

gdjs.copyArray(runtimeScene.getObjects("NewSprite4"), gdjs.VS_32ZoneCode.GDNewSprite4Objects1);
gdjs.copyArray(runtimeScene.getObjects("Player"), gdjs.VS_32ZoneCode.GDPlayerObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.VS_32ZoneCode.mapOfGDgdjs_9546VS_959532ZoneCode_9546GDPlayerObjects1Objects, gdjs.VS_32ZoneCode.mapOfGDgdjs_9546VS_959532ZoneCode_9546GDNewSprite4Objects1Objects, false, runtimeScene, false);
if (isConditionTrue_0) {
{gdjs.evtTools.runtimeScene.replaceScene(runtimeScene, "2", false);
}
}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.runtimeScene.sceneJustBegins(runtimeScene);
if (isConditionTrue_0) {
}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.runtimeScene.sceneJustBegins(runtimeScene);
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("NewSprite10"), gdjs.VS_32ZoneCode.GDNewSprite10Objects1);
{for(var i = 0, len = gdjs.VS_32ZoneCode.GDNewSprite10Objects1.length ;i < len;++i) {
    gdjs.VS_32ZoneCode.GDNewSprite10Objects1[i].hide();
}
}
}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.sound.isMusicOnChannelPlaying(runtimeScene, 3);
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("NewSprite10"), gdjs.VS_32ZoneCode.GDNewSprite10Objects1);
{for(var i = 0, len = gdjs.VS_32ZoneCode.GDNewSprite10Objects1.length ;i < len;++i) {
    gdjs.VS_32ZoneCode.GDNewSprite10Objects1[i].hide(false);
}
}
}

}


{

gdjs.copyArray(runtimeScene.getObjects("Player"), gdjs.VS_32ZoneCode.GDPlayerObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.VS_32ZoneCode.GDPlayerObjects1.length;i<l;++i) {
    if ( gdjs.VS_32ZoneCode.GDPlayerObjects1[i].getBehavior("PlatformerObject").isJumping() ) {
        isConditionTrue_0 = true;
        gdjs.VS_32ZoneCode.GDPlayerObjects1[k] = gdjs.VS_32ZoneCode.GDPlayerObjects1[i];
        ++k;
    }
}
gdjs.VS_32ZoneCode.GDPlayerObjects1.length = k;
if (isConditionTrue_0) {
/* Reuse gdjs.VS_32ZoneCode.GDPlayerObjects1 */
{for(var i = 0, len = gdjs.VS_32ZoneCode.GDPlayerObjects1.length ;i < len;++i) {
    gdjs.VS_32ZoneCode.GDPlayerObjects1[i].getBehavior("Animation").setAnimationName("Jumping jacks");
}
}
}

}


{

gdjs.copyArray(runtimeScene.getObjects("Player"), gdjs.VS_32ZoneCode.GDPlayerObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.VS_32ZoneCode.GDPlayerObjects1.length;i<l;++i) {
    if ( gdjs.VS_32ZoneCode.GDPlayerObjects1[i].getBehavior("PlatformerObject").isFalling() ) {
        isConditionTrue_0 = true;
        gdjs.VS_32ZoneCode.GDPlayerObjects1[k] = gdjs.VS_32ZoneCode.GDPlayerObjects1[i];
        ++k;
    }
}
gdjs.VS_32ZoneCode.GDPlayerObjects1.length = k;
if (isConditionTrue_0) {
/* Reuse gdjs.VS_32ZoneCode.GDPlayerObjects1 */
{for(var i = 0, len = gdjs.VS_32ZoneCode.GDPlayerObjects1.length ;i < len;++i) {
    gdjs.VS_32ZoneCode.GDPlayerObjects1[i].getBehavior("Animation").setAnimationName("Fall");
}
}
}

}


{

gdjs.copyArray(runtimeScene.getObjects("Player"), gdjs.VS_32ZoneCode.GDPlayerObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.VS_32ZoneCode.GDPlayerObjects1.length;i<l;++i) {
    if ( gdjs.VS_32ZoneCode.GDPlayerObjects1[i].getBehavior("Animation").getAnimationName() == "Jumping jacks" ) {
        isConditionTrue_0 = true;
        gdjs.VS_32ZoneCode.GDPlayerObjects1[k] = gdjs.VS_32ZoneCode.GDPlayerObjects1[i];
        ++k;
    }
}
gdjs.VS_32ZoneCode.GDPlayerObjects1.length = k;
if (isConditionTrue_0) {
}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.sound.isMusicOnChannelPaused(runtimeScene, 3);
if (isConditionTrue_0) {
{gdjs.evtTools.runtimeScene.replaceScene(runtimeScene, "Settings", false);
}
}

}


{

gdjs.copyArray(runtimeScene.getObjects("Player2"), gdjs.VS_32ZoneCode.GDPlayer2Objects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.VS_32ZoneCode.GDPlayer2Objects1.length;i<l;++i) {
    if ( gdjs.VS_32ZoneCode.GDPlayer2Objects1[i].getBehavior("PlatformerObject").isUsingControl("Left") ) {
        isConditionTrue_0 = true;
        gdjs.VS_32ZoneCode.GDPlayer2Objects1[k] = gdjs.VS_32ZoneCode.GDPlayer2Objects1[i];
        ++k;
    }
}
gdjs.VS_32ZoneCode.GDPlayer2Objects1.length = k;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.VS_32ZoneCode.GDPlayer2Objects1.length;i<l;++i) {
    if ( !(gdjs.VS_32ZoneCode.GDPlayer2Objects1[i].getBehavior("PlatformerObject").isUsingControl("Left")) ) {
        isConditionTrue_0 = true;
        gdjs.VS_32ZoneCode.GDPlayer2Objects1[k] = gdjs.VS_32ZoneCode.GDPlayer2Objects1[i];
        ++k;
    }
}
gdjs.VS_32ZoneCode.GDPlayer2Objects1.length = k;
}
if (isConditionTrue_0) {
/* Reuse gdjs.VS_32ZoneCode.GDPlayer2Objects1 */
{for(var i = 0, len = gdjs.VS_32ZoneCode.GDPlayer2Objects1.length ;i < len;++i) {
    gdjs.VS_32ZoneCode.GDPlayer2Objects1[i].getBehavior("Flippable").flipX(false);
}
}
{for(var i = 0, len = gdjs.VS_32ZoneCode.GDPlayer2Objects1.length ;i < len;++i) {
    gdjs.VS_32ZoneCode.GDPlayer2Objects1[i].getBehavior("Flippable").flipX(true);
}
}
}

}


{


let isConditionTrue_0 = false;
{
}

}


{

gdjs.copyArray(runtimeScene.getObjects("Player2"), gdjs.VS_32ZoneCode.GDPlayer2Objects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.VS_32ZoneCode.GDPlayer2Objects1.length;i<l;++i) {
    if ( gdjs.VS_32ZoneCode.GDPlayer2Objects1[i].getBehavior("PlatformerObject").isJumping() ) {
        isConditionTrue_0 = true;
        gdjs.VS_32ZoneCode.GDPlayer2Objects1[k] = gdjs.VS_32ZoneCode.GDPlayer2Objects1[i];
        ++k;
    }
}
gdjs.VS_32ZoneCode.GDPlayer2Objects1.length = k;
if (isConditionTrue_0) {
/* Reuse gdjs.VS_32ZoneCode.GDPlayer2Objects1 */
{for(var i = 0, len = gdjs.VS_32ZoneCode.GDPlayer2Objects1.length ;i < len;++i) {
    gdjs.VS_32ZoneCode.GDPlayer2Objects1[i].getBehavior("Animation").setAnimationName("Jumping jacks");
}
}
}

}


{

gdjs.copyArray(runtimeScene.getObjects("Player2"), gdjs.VS_32ZoneCode.GDPlayer2Objects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.VS_32ZoneCode.GDPlayer2Objects1.length;i<l;++i) {
    if ( !(gdjs.VS_32ZoneCode.GDPlayer2Objects1[i].getBehavior("PlatformerObject").isMovingEvenALittle()) ) {
        isConditionTrue_0 = true;
        gdjs.VS_32ZoneCode.GDPlayer2Objects1[k] = gdjs.VS_32ZoneCode.GDPlayer2Objects1[i];
        ++k;
    }
}
gdjs.VS_32ZoneCode.GDPlayer2Objects1.length = k;
if (isConditionTrue_0) {
/* Reuse gdjs.VS_32ZoneCode.GDPlayer2Objects1 */
{for(var i = 0, len = gdjs.VS_32ZoneCode.GDPlayer2Objects1.length ;i < len;++i) {
    gdjs.VS_32ZoneCode.GDPlayer2Objects1[i].getBehavior("Animation").setAnimationName("Idle");
}
}
}

}


{

gdjs.copyArray(runtimeScene.getObjects("Player2"), gdjs.VS_32ZoneCode.GDPlayer2Objects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.VS_32ZoneCode.GDPlayer2Objects1.length;i<l;++i) {
    if ( gdjs.VS_32ZoneCode.GDPlayer2Objects1[i].getBehavior("PlatformerObject").isMovingEvenALittle() ) {
        isConditionTrue_0 = true;
        gdjs.VS_32ZoneCode.GDPlayer2Objects1[k] = gdjs.VS_32ZoneCode.GDPlayer2Objects1[i];
        ++k;
    }
}
gdjs.VS_32ZoneCode.GDPlayer2Objects1.length = k;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.VS_32ZoneCode.GDPlayer2Objects1.length;i<l;++i) {
    if ( gdjs.VS_32ZoneCode.GDPlayer2Objects1[i].getBehavior("PlatformerObject").isOnFloor() ) {
        isConditionTrue_0 = true;
        gdjs.VS_32ZoneCode.GDPlayer2Objects1[k] = gdjs.VS_32ZoneCode.GDPlayer2Objects1[i];
        ++k;
    }
}
gdjs.VS_32ZoneCode.GDPlayer2Objects1.length = k;
}
if (isConditionTrue_0) {
/* Reuse gdjs.VS_32ZoneCode.GDPlayer2Objects1 */
{for(var i = 0, len = gdjs.VS_32ZoneCode.GDPlayer2Objects1.length ;i < len;++i) {
    gdjs.VS_32ZoneCode.GDPlayer2Objects1[i].getBehavior("Animation").setAnimationName("Running");
}
}
}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtsExt__Gamepads__C_Axis_pushed.func(runtimeScene, 2, "Left", "Right", null);
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("Player2"), gdjs.VS_32ZoneCode.GDPlayer2Objects1);
{for(var i = 0, len = gdjs.VS_32ZoneCode.GDPlayer2Objects1.length ;i < len;++i) {
    gdjs.VS_32ZoneCode.GDPlayer2Objects1[i].getBehavior("Flippable").flipX(false);
}
}
}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtsExt__Gamepads__C_Axis_pushed.func(runtimeScene, 2, "Left", "Left", null);
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("Player2"), gdjs.VS_32ZoneCode.GDPlayer2Objects1);
{for(var i = 0, len = gdjs.VS_32ZoneCode.GDPlayer2Objects1.length ;i < len;++i) {
    gdjs.VS_32ZoneCode.GDPlayer2Objects1[i].getBehavior("Flippable").flipX(true);
}
}
}

}


{

gdjs.copyArray(runtimeScene.getObjects("Player2"), gdjs.VS_32ZoneCode.GDPlayer2Objects1);
gdjs.copyArray(runtimeScene.getObjects("spike"), gdjs.VS_32ZoneCode.GDspikeObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.VS_32ZoneCode.mapOfGDgdjs_9546VS_959532ZoneCode_9546GDPlayer2Objects1Objects, gdjs.VS_32ZoneCode.mapOfGDgdjs_9546VS_959532ZoneCode_9546GDspikeObjects1Objects, false, runtimeScene, false);
if (isConditionTrue_0) {
/* Reuse gdjs.VS_32ZoneCode.GDPlayer2Objects1 */
{for(var i = 0, len = gdjs.VS_32ZoneCode.GDPlayer2Objects1.length ;i < len;++i) {
    gdjs.VS_32ZoneCode.GDPlayer2Objects1[i].deleteFromScene(runtimeScene);
}
}
{gdjs.evtTools.sound.playMusicOnChannel(runtimeScene, "oof.mp3", 3, false, 100, 1);
}
{gdjs.evtTools.sound.pauseMusicOnChannel(runtimeScene, 2);
}
}

}


{

gdjs.copyArray(runtimeScene.getObjects("Player2"), gdjs.VS_32ZoneCode.GDPlayer2Objects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.VS_32ZoneCode.GDPlayer2Objects1.length;i<l;++i) {
    if ( gdjs.VS_32ZoneCode.GDPlayer2Objects1[i].getBehavior("PlatformerObject").isFalling() ) {
        isConditionTrue_0 = true;
        gdjs.VS_32ZoneCode.GDPlayer2Objects1[k] = gdjs.VS_32ZoneCode.GDPlayer2Objects1[i];
        ++k;
    }
}
gdjs.VS_32ZoneCode.GDPlayer2Objects1.length = k;
if (isConditionTrue_0) {
/* Reuse gdjs.VS_32ZoneCode.GDPlayer2Objects1 */
{for(var i = 0, len = gdjs.VS_32ZoneCode.GDPlayer2Objects1.length ;i < len;++i) {
    gdjs.VS_32ZoneCode.GDPlayer2Objects1[i].getBehavior("Animation").setAnimationName("Fall");
}
}
}

}


{

gdjs.copyArray(runtimeScene.getObjects("NewSprite10"), gdjs.VS_32ZoneCode.GDNewSprite10Objects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.VS_32ZoneCode.GDNewSprite10Objects1.length;i<l;++i) {
    if ( gdjs.VS_32ZoneCode.GDNewSprite10Objects1[i].getBehavior("Animation").hasAnimationEnded() ) {
        isConditionTrue_0 = true;
        gdjs.VS_32ZoneCode.GDNewSprite10Objects1[k] = gdjs.VS_32ZoneCode.GDNewSprite10Objects1[i];
        ++k;
    }
}
gdjs.VS_32ZoneCode.GDNewSprite10Objects1.length = k;
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("face"), gdjs.VS_32ZoneCode.GDfaceObjects1);
{for(var i = 0, len = gdjs.VS_32ZoneCode.GDfaceObjects1.length ;i < len;++i) {
    gdjs.VS_32ZoneCode.GDfaceObjects1[i].getBehavior("Animation").setAnimationName("bad");
}
}
}

}


{

gdjs.copyArray(runtimeScene.getObjects("NewSprite10"), gdjs.VS_32ZoneCode.GDNewSprite10Objects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.VS_32ZoneCode.GDNewSprite10Objects1.length;i<l;++i) {
    if ( gdjs.VS_32ZoneCode.GDNewSprite10Objects1[i].getBehavior("Animation").hasAnimationEnded() ) {
        isConditionTrue_0 = true;
        gdjs.VS_32ZoneCode.GDNewSprite10Objects1[k] = gdjs.VS_32ZoneCode.GDNewSprite10Objects1[i];
        ++k;
    }
}
gdjs.VS_32ZoneCode.GDNewSprite10Objects1.length = k;
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("faceplayer2"), gdjs.VS_32ZoneCode.GDfaceplayer2Objects1);
{for(var i = 0, len = gdjs.VS_32ZoneCode.GDfaceplayer2Objects1.length ;i < len;++i) {
    gdjs.VS_32ZoneCode.GDfaceplayer2Objects1[i].getBehavior("Animation").setAnimationName("bad");
}
}
}

}


{

gdjs.copyArray(runtimeScene.getObjects("Coins"), gdjs.VS_32ZoneCode.GDCoinsObjects1);
gdjs.copyArray(runtimeScene.getObjects("Player2"), gdjs.VS_32ZoneCode.GDPlayer2Objects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.VS_32ZoneCode.mapOfGDgdjs_9546VS_959532ZoneCode_9546GDPlayer2Objects1Objects, gdjs.VS_32ZoneCode.mapOfGDgdjs_9546VS_959532ZoneCode_9546GDCoinsObjects1Objects, false, runtimeScene, false);
if (isConditionTrue_0) {
/* Reuse gdjs.VS_32ZoneCode.GDCoinsObjects1 */
{for(var i = 0, len = gdjs.VS_32ZoneCode.GDCoinsObjects1.length ;i < len;++i) {
    gdjs.VS_32ZoneCode.GDCoinsObjects1[i].deleteFromScene(runtimeScene);
}
}
{gdjs.evtTools.sound.playSound(runtimeScene, "Coin.wav", false, 100, 1);
}
}

}


};

gdjs.VS_32ZoneCode.func = function(runtimeScene) {
runtimeScene.getOnceTriggers().startNewFrame();

gdjs.VS_32ZoneCode.GDPlayerObjects1.length = 0;
gdjs.VS_32ZoneCode.GDPlayerObjects2.length = 0;
gdjs.VS_32ZoneCode.GDCoinsObjects1.length = 0;
gdjs.VS_32ZoneCode.GDCoinsObjects2.length = 0;
gdjs.VS_32ZoneCode.GDPlatform_9595GroundObjects1.length = 0;
gdjs.VS_32ZoneCode.GDPlatform_9595GroundObjects2.length = 0;
gdjs.VS_32ZoneCode.GDNewSprite4Objects1.length = 0;
gdjs.VS_32ZoneCode.GDNewSprite4Objects2.length = 0;
gdjs.VS_32ZoneCode.GDNewSprite5Objects1.length = 0;
gdjs.VS_32ZoneCode.GDNewSprite5Objects2.length = 0;
gdjs.VS_32ZoneCode.GDNewSprite6Objects1.length = 0;
gdjs.VS_32ZoneCode.GDNewSprite6Objects2.length = 0;
gdjs.VS_32ZoneCode.GDspikeObjects1.length = 0;
gdjs.VS_32ZoneCode.GDspikeObjects2.length = 0;
gdjs.VS_32ZoneCode.GDNewSprite7Objects1.length = 0;
gdjs.VS_32ZoneCode.GDNewSprite7Objects2.length = 0;
gdjs.VS_32ZoneCode.GDNewSprite8Objects1.length = 0;
gdjs.VS_32ZoneCode.GDNewSprite8Objects2.length = 0;
gdjs.VS_32ZoneCode.GDNewSprite3Objects1.length = 0;
gdjs.VS_32ZoneCode.GDNewSprite3Objects2.length = 0;
gdjs.VS_32ZoneCode.GDpipeObjects1.length = 0;
gdjs.VS_32ZoneCode.GDpipeObjects2.length = 0;
gdjs.VS_32ZoneCode.GDStacyObjects1.length = 0;
gdjs.VS_32ZoneCode.GDStacyObjects2.length = 0;
gdjs.VS_32ZoneCode.GDShadedDarkJoystickObjects1.length = 0;
gdjs.VS_32ZoneCode.GDShadedDarkJoystickObjects2.length = 0;
gdjs.VS_32ZoneCode.GDNewSpriteObjects1.length = 0;
gdjs.VS_32ZoneCode.GDNewSpriteObjects2.length = 0;
gdjs.VS_32ZoneCode.GDNewSprite9Objects1.length = 0;
gdjs.VS_32ZoneCode.GDNewSprite9Objects2.length = 0;
gdjs.VS_32ZoneCode.GDMountain_9595dewObjects1.length = 0;
gdjs.VS_32ZoneCode.GDMountain_9595dewObjects2.length = 0;
gdjs.VS_32ZoneCode.GDNewSprite10Objects1.length = 0;
gdjs.VS_32ZoneCode.GDNewSprite10Objects2.length = 0;
gdjs.VS_32ZoneCode.GDJumpObjects1.length = 0;
gdjs.VS_32ZoneCode.GDJumpObjects2.length = 0;
gdjs.VS_32ZoneCode.GDPlayer2Objects1.length = 0;
gdjs.VS_32ZoneCode.GDPlayer2Objects2.length = 0;
gdjs.VS_32ZoneCode.GDfaceObjects1.length = 0;
gdjs.VS_32ZoneCode.GDfaceObjects2.length = 0;
gdjs.VS_32ZoneCode.GDfaceplayer2Objects1.length = 0;
gdjs.VS_32ZoneCode.GDfaceplayer2Objects2.length = 0;
gdjs.VS_32ZoneCode.GDCloudObjects1.length = 0;
gdjs.VS_32ZoneCode.GDCloudObjects2.length = 0;
gdjs.VS_32ZoneCode.GDMOuseclickObjects1.length = 0;
gdjs.VS_32ZoneCode.GDMOuseclickObjects2.length = 0;

gdjs.VS_32ZoneCode.eventsList0(runtimeScene);
gdjs.VS_32ZoneCode.GDPlayerObjects1.length = 0;
gdjs.VS_32ZoneCode.GDPlayerObjects2.length = 0;
gdjs.VS_32ZoneCode.GDCoinsObjects1.length = 0;
gdjs.VS_32ZoneCode.GDCoinsObjects2.length = 0;
gdjs.VS_32ZoneCode.GDPlatform_9595GroundObjects1.length = 0;
gdjs.VS_32ZoneCode.GDPlatform_9595GroundObjects2.length = 0;
gdjs.VS_32ZoneCode.GDNewSprite4Objects1.length = 0;
gdjs.VS_32ZoneCode.GDNewSprite4Objects2.length = 0;
gdjs.VS_32ZoneCode.GDNewSprite5Objects1.length = 0;
gdjs.VS_32ZoneCode.GDNewSprite5Objects2.length = 0;
gdjs.VS_32ZoneCode.GDNewSprite6Objects1.length = 0;
gdjs.VS_32ZoneCode.GDNewSprite6Objects2.length = 0;
gdjs.VS_32ZoneCode.GDspikeObjects1.length = 0;
gdjs.VS_32ZoneCode.GDspikeObjects2.length = 0;
gdjs.VS_32ZoneCode.GDNewSprite7Objects1.length = 0;
gdjs.VS_32ZoneCode.GDNewSprite7Objects2.length = 0;
gdjs.VS_32ZoneCode.GDNewSprite8Objects1.length = 0;
gdjs.VS_32ZoneCode.GDNewSprite8Objects2.length = 0;
gdjs.VS_32ZoneCode.GDNewSprite3Objects1.length = 0;
gdjs.VS_32ZoneCode.GDNewSprite3Objects2.length = 0;
gdjs.VS_32ZoneCode.GDpipeObjects1.length = 0;
gdjs.VS_32ZoneCode.GDpipeObjects2.length = 0;
gdjs.VS_32ZoneCode.GDStacyObjects1.length = 0;
gdjs.VS_32ZoneCode.GDStacyObjects2.length = 0;
gdjs.VS_32ZoneCode.GDShadedDarkJoystickObjects1.length = 0;
gdjs.VS_32ZoneCode.GDShadedDarkJoystickObjects2.length = 0;
gdjs.VS_32ZoneCode.GDNewSpriteObjects1.length = 0;
gdjs.VS_32ZoneCode.GDNewSpriteObjects2.length = 0;
gdjs.VS_32ZoneCode.GDNewSprite9Objects1.length = 0;
gdjs.VS_32ZoneCode.GDNewSprite9Objects2.length = 0;
gdjs.VS_32ZoneCode.GDMountain_9595dewObjects1.length = 0;
gdjs.VS_32ZoneCode.GDMountain_9595dewObjects2.length = 0;
gdjs.VS_32ZoneCode.GDNewSprite10Objects1.length = 0;
gdjs.VS_32ZoneCode.GDNewSprite10Objects2.length = 0;
gdjs.VS_32ZoneCode.GDJumpObjects1.length = 0;
gdjs.VS_32ZoneCode.GDJumpObjects2.length = 0;
gdjs.VS_32ZoneCode.GDPlayer2Objects1.length = 0;
gdjs.VS_32ZoneCode.GDPlayer2Objects2.length = 0;
gdjs.VS_32ZoneCode.GDfaceObjects1.length = 0;
gdjs.VS_32ZoneCode.GDfaceObjects2.length = 0;
gdjs.VS_32ZoneCode.GDfaceplayer2Objects1.length = 0;
gdjs.VS_32ZoneCode.GDfaceplayer2Objects2.length = 0;
gdjs.VS_32ZoneCode.GDCloudObjects1.length = 0;
gdjs.VS_32ZoneCode.GDCloudObjects2.length = 0;
gdjs.VS_32ZoneCode.GDMOuseclickObjects1.length = 0;
gdjs.VS_32ZoneCode.GDMOuseclickObjects2.length = 0;


return;

}

gdjs['VS_32ZoneCode'] = gdjs.VS_32ZoneCode;
