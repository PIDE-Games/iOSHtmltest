gdjs.World_32MapCode = {};
gdjs.World_32MapCode.localVariables = [];
gdjs.World_32MapCode.idToCallbackMap = new Map();
gdjs.World_32MapCode.GDNewSpriteObjects1= [];
gdjs.World_32MapCode.GDNewSpriteObjects2= [];
gdjs.World_32MapCode.GDRIghtObjects1= [];
gdjs.World_32MapCode.GDRIghtObjects2= [];
gdjs.World_32MapCode.GDDownieObjects1= [];
gdjs.World_32MapCode.GDDownieObjects2= [];
gdjs.World_32MapCode.GDLeftObjects1= [];
gdjs.World_32MapCode.GDLeftObjects2= [];
gdjs.World_32MapCode.GDUppieObjects1= [];
gdjs.World_32MapCode.GDUppieObjects2= [];


gdjs.World_32MapCode.mapOfGDgdjs_9546World_959532MapCode_9546GDRIghtObjects1Objects = Hashtable.newFrom({"RIght": gdjs.World_32MapCode.GDRIghtObjects1});
gdjs.World_32MapCode.mapOfGDgdjs_9546World_959532MapCode_9546GDDownieObjects1Objects = Hashtable.newFrom({"Downie": gdjs.World_32MapCode.GDDownieObjects1});
gdjs.World_32MapCode.mapOfGDgdjs_9546World_959532MapCode_9546GDLeftObjects1Objects = Hashtable.newFrom({"Left": gdjs.World_32MapCode.GDLeftObjects1});
gdjs.World_32MapCode.mapOfGDgdjs_9546World_959532MapCode_9546GDUppieObjects1Objects = Hashtable.newFrom({"Uppie": gdjs.World_32MapCode.GDUppieObjects1});
gdjs.World_32MapCode.eventsList0 = function(runtimeScene) {

{

gdjs.copyArray(runtimeScene.getObjects("RIght"), gdjs.World_32MapCode.GDRIghtObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.cursorOnObject(gdjs.World_32MapCode.mapOfGDgdjs_9546World_959532MapCode_9546GDRIghtObjects1Objects, runtimeScene, true, false);
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("NewSprite"), gdjs.World_32MapCode.GDNewSpriteObjects1);
{for(var i = 0, len = gdjs.World_32MapCode.GDNewSpriteObjects1.length ;i < len;++i) {
    gdjs.World_32MapCode.GDNewSpriteObjects1[i].getBehavior("TopDownMovement").simulateLeftKey();
}
}
}

}


{

gdjs.copyArray(runtimeScene.getObjects("Downie"), gdjs.World_32MapCode.GDDownieObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.cursorOnObject(gdjs.World_32MapCode.mapOfGDgdjs_9546World_959532MapCode_9546GDDownieObjects1Objects, runtimeScene, true, false);
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("NewSprite"), gdjs.World_32MapCode.GDNewSpriteObjects1);
{for(var i = 0, len = gdjs.World_32MapCode.GDNewSpriteObjects1.length ;i < len;++i) {
    gdjs.World_32MapCode.GDNewSpriteObjects1[i].getBehavior("TopDownMovement").simulateDownKey();
}
}
}

}


{

gdjs.copyArray(runtimeScene.getObjects("Left"), gdjs.World_32MapCode.GDLeftObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.cursorOnObject(gdjs.World_32MapCode.mapOfGDgdjs_9546World_959532MapCode_9546GDLeftObjects1Objects, runtimeScene, true, false);
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("NewSprite"), gdjs.World_32MapCode.GDNewSpriteObjects1);
{for(var i = 0, len = gdjs.World_32MapCode.GDNewSpriteObjects1.length ;i < len;++i) {
    gdjs.World_32MapCode.GDNewSpriteObjects1[i].getBehavior("TopDownMovement").simulateRightKey();
}
}
}

}


{

gdjs.copyArray(runtimeScene.getObjects("Uppie"), gdjs.World_32MapCode.GDUppieObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.cursorOnObject(gdjs.World_32MapCode.mapOfGDgdjs_9546World_959532MapCode_9546GDUppieObjects1Objects, runtimeScene, true, false);
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("NewSprite"), gdjs.World_32MapCode.GDNewSpriteObjects1);
{for(var i = 0, len = gdjs.World_32MapCode.GDNewSpriteObjects1.length ;i < len;++i) {
    gdjs.World_32MapCode.GDNewSpriteObjects1[i].getBehavior("TopDownMovement").simulateUpKey();
}
}
}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.isKeyPressed(runtimeScene, "Right");
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("NewSprite"), gdjs.World_32MapCode.GDNewSpriteObjects1);
{for(var i = 0, len = gdjs.World_32MapCode.GDNewSpriteObjects1.length ;i < len;++i) {
    gdjs.World_32MapCode.GDNewSpriteObjects1[i].getBehavior("Animation").setAnimationName("right");
}
}
}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.isKeyPressed(runtimeScene, "Down");
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("NewSprite"), gdjs.World_32MapCode.GDNewSpriteObjects1);
{for(var i = 0, len = gdjs.World_32MapCode.GDNewSpriteObjects1.length ;i < len;++i) {
    gdjs.World_32MapCode.GDNewSpriteObjects1[i].getBehavior("Animation").setAnimationName("NewSprite");
}
}
}

}


};

gdjs.World_32MapCode.func = function(runtimeScene) {
runtimeScene.getOnceTriggers().startNewFrame();

gdjs.World_32MapCode.GDNewSpriteObjects1.length = 0;
gdjs.World_32MapCode.GDNewSpriteObjects2.length = 0;
gdjs.World_32MapCode.GDRIghtObjects1.length = 0;
gdjs.World_32MapCode.GDRIghtObjects2.length = 0;
gdjs.World_32MapCode.GDDownieObjects1.length = 0;
gdjs.World_32MapCode.GDDownieObjects2.length = 0;
gdjs.World_32MapCode.GDLeftObjects1.length = 0;
gdjs.World_32MapCode.GDLeftObjects2.length = 0;
gdjs.World_32MapCode.GDUppieObjects1.length = 0;
gdjs.World_32MapCode.GDUppieObjects2.length = 0;

gdjs.World_32MapCode.eventsList0(runtimeScene);
gdjs.World_32MapCode.GDNewSpriteObjects1.length = 0;
gdjs.World_32MapCode.GDNewSpriteObjects2.length = 0;
gdjs.World_32MapCode.GDRIghtObjects1.length = 0;
gdjs.World_32MapCode.GDRIghtObjects2.length = 0;
gdjs.World_32MapCode.GDDownieObjects1.length = 0;
gdjs.World_32MapCode.GDDownieObjects2.length = 0;
gdjs.World_32MapCode.GDLeftObjects1.length = 0;
gdjs.World_32MapCode.GDLeftObjects2.length = 0;
gdjs.World_32MapCode.GDUppieObjects1.length = 0;
gdjs.World_32MapCode.GDUppieObjects2.length = 0;


return;

}

gdjs['World_32MapCode'] = gdjs.World_32MapCode;
