gdjs.TestLevelCode = {};
gdjs.TestLevelCode.localVariables = [];
gdjs.TestLevelCode.idToCallbackMap = new Map();
gdjs.TestLevelCode.GDPlayerObjects1= [];
gdjs.TestLevelCode.GDPlayerObjects2= [];
gdjs.TestLevelCode.GDCoinsObjects1= [];
gdjs.TestLevelCode.GDCoinsObjects2= [];
gdjs.TestLevelCode.GDPlatform_9595GroundObjects1= [];
gdjs.TestLevelCode.GDPlatform_9595GroundObjects2= [];
gdjs.TestLevelCode.GDNewSprite4Objects1= [];
gdjs.TestLevelCode.GDNewSprite4Objects2= [];
gdjs.TestLevelCode.GDNewSprite5Objects1= [];
gdjs.TestLevelCode.GDNewSprite5Objects2= [];
gdjs.TestLevelCode.GDNewSprite6Objects1= [];
gdjs.TestLevelCode.GDNewSprite6Objects2= [];
gdjs.TestLevelCode.GDspikeObjects1= [];
gdjs.TestLevelCode.GDspikeObjects2= [];
gdjs.TestLevelCode.GDNewSprite7Objects1= [];
gdjs.TestLevelCode.GDNewSprite7Objects2= [];
gdjs.TestLevelCode.GDNewSprite8Objects1= [];
gdjs.TestLevelCode.GDNewSprite8Objects2= [];
gdjs.TestLevelCode.GDNewSprite3Objects1= [];
gdjs.TestLevelCode.GDNewSprite3Objects2= [];
gdjs.TestLevelCode.GDpipeObjects1= [];
gdjs.TestLevelCode.GDpipeObjects2= [];
gdjs.TestLevelCode.GDStacyObjects1= [];
gdjs.TestLevelCode.GDStacyObjects2= [];
gdjs.TestLevelCode.GDShadedDarkJoystickObjects1= [];
gdjs.TestLevelCode.GDShadedDarkJoystickObjects2= [];
gdjs.TestLevelCode.GDNewSpriteObjects1= [];
gdjs.TestLevelCode.GDNewSpriteObjects2= [];
gdjs.TestLevelCode.GDNewSprite9Objects1= [];
gdjs.TestLevelCode.GDNewSprite9Objects2= [];
gdjs.TestLevelCode.GDMountain_9595dewObjects1= [];
gdjs.TestLevelCode.GDMountain_9595dewObjects2= [];
gdjs.TestLevelCode.GDNewSprite10Objects1= [];
gdjs.TestLevelCode.GDNewSprite10Objects2= [];
gdjs.TestLevelCode.GDJumpObjects1= [];
gdjs.TestLevelCode.GDJumpObjects2= [];
gdjs.TestLevelCode.GDCloudObjects1= [];
gdjs.TestLevelCode.GDCloudObjects2= [];
gdjs.TestLevelCode.GDTreeObjects1= [];
gdjs.TestLevelCode.GDTreeObjects2= [];
gdjs.TestLevelCode.GDPauseObjects1= [];
gdjs.TestLevelCode.GDPauseObjects2= [];
gdjs.TestLevelCode.GDMOuseclickObjects1= [];
gdjs.TestLevelCode.GDMOuseclickObjects2= [];
gdjs.TestLevelCode.GDNewTextObjects1= [];
gdjs.TestLevelCode.GDNewTextObjects2= [];
gdjs.TestLevelCode.GDNewSprite2Objects1= [];
gdjs.TestLevelCode.GDNewSprite2Objects2= [];
gdjs.TestLevelCode.GDNewSprite11Objects1= [];
gdjs.TestLevelCode.GDNewSprite11Objects2= [];
gdjs.TestLevelCode.GDNewSprite12Objects1= [];
gdjs.TestLevelCode.GDNewSprite12Objects2= [];
gdjs.TestLevelCode.GDNewSprite13Objects1= [];
gdjs.TestLevelCode.GDNewSprite13Objects2= [];
gdjs.TestLevelCode.GDNewTiledSpriteObjects1= [];
gdjs.TestLevelCode.GDNewTiledSpriteObjects2= [];


gdjs.TestLevelCode.mapOfGDgdjs_9546TestLevelCode_9546GDPlayerObjects1Objects = Hashtable.newFrom({"Player": gdjs.TestLevelCode.GDPlayerObjects1});
gdjs.TestLevelCode.mapOfGDgdjs_9546TestLevelCode_9546GDCoinsObjects1Objects = Hashtable.newFrom({"Coins": gdjs.TestLevelCode.GDCoinsObjects1});
gdjs.TestLevelCode.mapOfGDgdjs_9546TestLevelCode_9546GDPlayerObjects1Objects = Hashtable.newFrom({"Player": gdjs.TestLevelCode.GDPlayerObjects1});
gdjs.TestLevelCode.mapOfGDgdjs_9546TestLevelCode_9546GDspikeObjects1Objects = Hashtable.newFrom({"spike": gdjs.TestLevelCode.GDspikeObjects1});
gdjs.TestLevelCode.mapOfGDgdjs_9546TestLevelCode_9546GDPlayerObjects1Objects = Hashtable.newFrom({"Player": gdjs.TestLevelCode.GDPlayerObjects1});
gdjs.TestLevelCode.mapOfGDgdjs_9546TestLevelCode_9546GDNewSprite11Objects1Objects = Hashtable.newFrom({"NewSprite11": gdjs.TestLevelCode.GDNewSprite11Objects1});
gdjs.TestLevelCode.mapOfGDgdjs_9546TestLevelCode_9546GDPlayerObjects1Objects = Hashtable.newFrom({"Player": gdjs.TestLevelCode.GDPlayerObjects1});
gdjs.TestLevelCode.mapOfGDgdjs_9546TestLevelCode_9546GDNewSprite4Objects1Objects = Hashtable.newFrom({"NewSprite4": gdjs.TestLevelCode.GDNewSprite4Objects1});
gdjs.TestLevelCode.mapOfGDgdjs_9546TestLevelCode_9546GDPlayerObjects1Objects = Hashtable.newFrom({"Player": gdjs.TestLevelCode.GDPlayerObjects1});
gdjs.TestLevelCode.mapOfGDgdjs_9546TestLevelCode_9546GDNewSprite11Objects1Objects = Hashtable.newFrom({"NewSprite11": gdjs.TestLevelCode.GDNewSprite11Objects1});
gdjs.TestLevelCode.mapOfGDgdjs_9546TestLevelCode_9546GDPlayerObjects1Objects = Hashtable.newFrom({"Player": gdjs.TestLevelCode.GDPlayerObjects1});
gdjs.TestLevelCode.mapOfGDgdjs_9546TestLevelCode_9546GDNewSprite4Objects1Objects = Hashtable.newFrom({"NewSprite4": gdjs.TestLevelCode.GDNewSprite4Objects1});
gdjs.TestLevelCode.eventsList0 = function(runtimeScene) {

{


let isConditionTrue_0 = false;
{
{gdjs.evtTools.camera.setCameraZoom(runtimeScene, 2, "", 0);
}
{gdjs.evtTools.camera.setCameraZoom(runtimeScene, 2, "Background", 0);
}
}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.runtimeScene.sceneJustBegins(runtimeScene);
if (isConditionTrue_0) {
}

}


{

gdjs.copyArray(runtimeScene.getObjects("Coins"), gdjs.TestLevelCode.GDCoinsObjects1);
gdjs.copyArray(runtimeScene.getObjects("Player"), gdjs.TestLevelCode.GDPlayerObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.TestLevelCode.mapOfGDgdjs_9546TestLevelCode_9546GDPlayerObjects1Objects, gdjs.TestLevelCode.mapOfGDgdjs_9546TestLevelCode_9546GDCoinsObjects1Objects, false, runtimeScene, false);
if (isConditionTrue_0) {
/* Reuse gdjs.TestLevelCode.GDCoinsObjects1 */
{for(var i = 0, len = gdjs.TestLevelCode.GDCoinsObjects1.length ;i < len;++i) {
    gdjs.TestLevelCode.GDCoinsObjects1[i].deleteFromScene(runtimeScene);
}
}
{gdjs.evtTools.sound.playSound(runtimeScene, "Coin.wav", false, 100, 1);
}
}

}


{

gdjs.copyArray(runtimeScene.getObjects("Player"), gdjs.TestLevelCode.GDPlayerObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.TestLevelCode.GDPlayerObjects1.length;i<l;++i) {
    if ( gdjs.TestLevelCode.GDPlayerObjects1[i].getBehavior("PlatformerObject").isOnFloor() ) {
        isConditionTrue_0 = true;
        gdjs.TestLevelCode.GDPlayerObjects1[k] = gdjs.TestLevelCode.GDPlayerObjects1[i];
        ++k;
    }
}
gdjs.TestLevelCode.GDPlayerObjects1.length = k;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.TestLevelCode.GDPlayerObjects1.length;i<l;++i) {
    if ( !(gdjs.TestLevelCode.GDPlayerObjects1[i].getBehavior("PlatformerObject").isMovingEvenALittle()) ) {
        isConditionTrue_0 = true;
        gdjs.TestLevelCode.GDPlayerObjects1[k] = gdjs.TestLevelCode.GDPlayerObjects1[i];
        ++k;
    }
}
gdjs.TestLevelCode.GDPlayerObjects1.length = k;
}
if (isConditionTrue_0) {
/* Reuse gdjs.TestLevelCode.GDPlayerObjects1 */
{for(var i = 0, len = gdjs.TestLevelCode.GDPlayerObjects1.length ;i < len;++i) {
    gdjs.TestLevelCode.GDPlayerObjects1[i].getBehavior("Animation").setAnimationName("Idle");
}
}
}

}


{

gdjs.copyArray(runtimeScene.getObjects("Player"), gdjs.TestLevelCode.GDPlayerObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.TestLevelCode.GDPlayerObjects1.length;i<l;++i) {
    if ( gdjs.TestLevelCode.GDPlayerObjects1[i].getBehavior("PlatformerObject").isOnFloor() ) {
        isConditionTrue_0 = true;
        gdjs.TestLevelCode.GDPlayerObjects1[k] = gdjs.TestLevelCode.GDPlayerObjects1[i];
        ++k;
    }
}
gdjs.TestLevelCode.GDPlayerObjects1.length = k;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.TestLevelCode.GDPlayerObjects1.length;i<l;++i) {
    if ( gdjs.TestLevelCode.GDPlayerObjects1[i].getBehavior("PlatformerObject").isMovingEvenALittle() ) {
        isConditionTrue_0 = true;
        gdjs.TestLevelCode.GDPlayerObjects1[k] = gdjs.TestLevelCode.GDPlayerObjects1[i];
        ++k;
    }
}
gdjs.TestLevelCode.GDPlayerObjects1.length = k;
}
if (isConditionTrue_0) {
/* Reuse gdjs.TestLevelCode.GDPlayerObjects1 */
{for(var i = 0, len = gdjs.TestLevelCode.GDPlayerObjects1.length ;i < len;++i) {
    gdjs.TestLevelCode.GDPlayerObjects1[i].getBehavior("Animation").setAnimationName("Running");
}
}
}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.isKeyPressed(runtimeScene, "Left");
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("Player"), gdjs.TestLevelCode.GDPlayerObjects1);
{for(var i = 0, len = gdjs.TestLevelCode.GDPlayerObjects1.length ;i < len;++i) {
    gdjs.TestLevelCode.GDPlayerObjects1[i].getBehavior("Flippable").flipX(true);
}
}
}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.isKeyPressed(runtimeScene, "Right");
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("Player"), gdjs.TestLevelCode.GDPlayerObjects1);
{for(var i = 0, len = gdjs.TestLevelCode.GDPlayerObjects1.length ;i < len;++i) {
    gdjs.TestLevelCode.GDPlayerObjects1[i].getBehavior("Flippable").flipX(false);
}
}
}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.isKeyPressed(runtimeScene, "Left");
if (isConditionTrue_0) {
}

}


{

gdjs.copyArray(runtimeScene.getObjects("Player"), gdjs.TestLevelCode.GDPlayerObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.TestLevelCode.GDPlayerObjects1.length;i<l;++i) {
    if ( gdjs.TestLevelCode.GDPlayerObjects1[i].getBehavior("PlatformerObject").isOnFloor() ) {
        isConditionTrue_0 = true;
        gdjs.TestLevelCode.GDPlayerObjects1[k] = gdjs.TestLevelCode.GDPlayerObjects1[i];
        ++k;
    }
}
gdjs.TestLevelCode.GDPlayerObjects1.length = k;
if (isConditionTrue_0) {
}

}


{

gdjs.copyArray(runtimeScene.getObjects("Player"), gdjs.TestLevelCode.GDPlayerObjects1);
gdjs.copyArray(runtimeScene.getObjects("spike"), gdjs.TestLevelCode.GDspikeObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.TestLevelCode.mapOfGDgdjs_9546TestLevelCode_9546GDPlayerObjects1Objects, gdjs.TestLevelCode.mapOfGDgdjs_9546TestLevelCode_9546GDspikeObjects1Objects, false, runtimeScene, false);
if (isConditionTrue_0) {
/* Reuse gdjs.TestLevelCode.GDPlayerObjects1 */
{for(var i = 0, len = gdjs.TestLevelCode.GDPlayerObjects1.length ;i < len;++i) {
    gdjs.TestLevelCode.GDPlayerObjects1[i].deleteFromScene(runtimeScene);
}
}
{gdjs.evtTools.sound.playMusicOnChannel(runtimeScene, "oof.mp3", 3, false, 100, 1);
}
{gdjs.evtTools.sound.pauseMusicOnChannel(runtimeScene, 2);
}
}

}


{

gdjs.copyArray(runtimeScene.getObjects("NewSprite11"), gdjs.TestLevelCode.GDNewSprite11Objects1);
gdjs.copyArray(runtimeScene.getObjects("Player"), gdjs.TestLevelCode.GDPlayerObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.TestLevelCode.mapOfGDgdjs_9546TestLevelCode_9546GDPlayerObjects1Objects, gdjs.TestLevelCode.mapOfGDgdjs_9546TestLevelCode_9546GDNewSprite11Objects1Objects, false, runtimeScene, false);
if (isConditionTrue_0) {
{gdjs.evtTools.sound.playSound(runtimeScene, "TaDa.wav", false, 100, 1);
}
}

}


{

gdjs.copyArray(runtimeScene.getObjects("Player"), gdjs.TestLevelCode.GDPlayerObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.TestLevelCode.GDPlayerObjects1.length;i<l;++i) {
    if ( gdjs.TestLevelCode.GDPlayerObjects1[i].getBehavior("PlatformerObject").isUsingControl("Left") ) {
        isConditionTrue_0 = true;
        gdjs.TestLevelCode.GDPlayerObjects1[k] = gdjs.TestLevelCode.GDPlayerObjects1[i];
        ++k;
    }
}
gdjs.TestLevelCode.GDPlayerObjects1.length = k;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.TestLevelCode.GDPlayerObjects1.length;i<l;++i) {
    if ( !(gdjs.TestLevelCode.GDPlayerObjects1[i].getBehavior("PlatformerObject").isUsingControl("Right")) ) {
        isConditionTrue_0 = true;
        gdjs.TestLevelCode.GDPlayerObjects1[k] = gdjs.TestLevelCode.GDPlayerObjects1[i];
        ++k;
    }
}
gdjs.TestLevelCode.GDPlayerObjects1.length = k;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.TestLevelCode.GDPlayerObjects1.length;i<l;++i) {
    if ( gdjs.TestLevelCode.GDPlayerObjects1[i].getBehavior("PlatformerObject").isUsingControl("Left") ) {
        isConditionTrue_0 = true;
        gdjs.TestLevelCode.GDPlayerObjects1[k] = gdjs.TestLevelCode.GDPlayerObjects1[i];
        ++k;
    }
}
gdjs.TestLevelCode.GDPlayerObjects1.length = k;
}
}
if (isConditionTrue_0) {
/* Reuse gdjs.TestLevelCode.GDPlayerObjects1 */
{for(var i = 0, len = gdjs.TestLevelCode.GDPlayerObjects1.length ;i < len;++i) {
    gdjs.TestLevelCode.GDPlayerObjects1[i].getBehavior("Flippable").flipX(false);
}
}
{for(var i = 0, len = gdjs.TestLevelCode.GDPlayerObjects1.length ;i < len;++i) {
    gdjs.TestLevelCode.GDPlayerObjects1[i].getBehavior("Flippable").flipX(false);
}
}
{for(var i = 0, len = gdjs.TestLevelCode.GDPlayerObjects1.length ;i < len;++i) {
    gdjs.TestLevelCode.GDPlayerObjects1[i].getBehavior("Flippable").flipX(true);
}
}
}

}


{

gdjs.copyArray(runtimeScene.getObjects("Player"), gdjs.TestLevelCode.GDPlayerObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.TestLevelCode.GDPlayerObjects1.length;i<l;++i) {
    if ( gdjs.TestLevelCode.GDPlayerObjects1[i].getBehavior("PlatformerObject").isUsingControl("Right") ) {
        isConditionTrue_0 = true;
        gdjs.TestLevelCode.GDPlayerObjects1[k] = gdjs.TestLevelCode.GDPlayerObjects1[i];
        ++k;
    }
}
gdjs.TestLevelCode.GDPlayerObjects1.length = k;
if (isConditionTrue_0) {
/* Reuse gdjs.TestLevelCode.GDPlayerObjects1 */
{for(var i = 0, len = gdjs.TestLevelCode.GDPlayerObjects1.length ;i < len;++i) {
    gdjs.TestLevelCode.GDPlayerObjects1[i].getBehavior("Flippable").flipX(false);
}
}
}

}


{

gdjs.copyArray(runtimeScene.getObjects("Jump"), gdjs.TestLevelCode.GDJumpObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.TestLevelCode.GDJumpObjects1.length;i<l;++i) {
    if ( gdjs.TestLevelCode.GDJumpObjects1[i].getBehavior("ButtonFSM").IsPressed(null) ) {
        isConditionTrue_0 = true;
        gdjs.TestLevelCode.GDJumpObjects1[k] = gdjs.TestLevelCode.GDJumpObjects1[i];
        ++k;
    }
}
gdjs.TestLevelCode.GDJumpObjects1.length = k;
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("Player"), gdjs.TestLevelCode.GDPlayerObjects1);
{for(var i = 0, len = gdjs.TestLevelCode.GDPlayerObjects1.length ;i < len;++i) {
    gdjs.TestLevelCode.GDPlayerObjects1[i].getBehavior("PlatformerObject").simulateJumpKey();
}
}
}

}


{

gdjs.copyArray(runtimeScene.getObjects("NewSprite4"), gdjs.TestLevelCode.GDNewSprite4Objects1);
gdjs.copyArray(runtimeScene.getObjects("Player"), gdjs.TestLevelCode.GDPlayerObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.TestLevelCode.mapOfGDgdjs_9546TestLevelCode_9546GDPlayerObjects1Objects, gdjs.TestLevelCode.mapOfGDgdjs_9546TestLevelCode_9546GDNewSprite4Objects1Objects, false, runtimeScene, false);
if (isConditionTrue_0) {
/* Reuse gdjs.TestLevelCode.GDPlayerObjects1 */
{for(var i = 0, len = gdjs.TestLevelCode.GDPlayerObjects1.length ;i < len;++i) {
    gdjs.TestLevelCode.GDPlayerObjects1[i].getBehavior("PlatformerObject").simulateRightKey();
}
}
}

}


{

gdjs.copyArray(runtimeScene.getObjects("NewSprite11"), gdjs.TestLevelCode.GDNewSprite11Objects1);
gdjs.copyArray(runtimeScene.getObjects("Player"), gdjs.TestLevelCode.GDPlayerObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.TestLevelCode.mapOfGDgdjs_9546TestLevelCode_9546GDPlayerObjects1Objects, gdjs.TestLevelCode.mapOfGDgdjs_9546TestLevelCode_9546GDNewSprite11Objects1Objects, false, runtimeScene, false);
if (isConditionTrue_0) {
{gdjs.evtTools.runtimeScene.replaceScene(runtimeScene, "Settings", false);
}
}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.runtimeScene.sceneJustBegins(runtimeScene);
if (isConditionTrue_0) {
}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.runtimeScene.sceneJustBegins(runtimeScene);
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("NewSprite10"), gdjs.TestLevelCode.GDNewSprite10Objects1);
{for(var i = 0, len = gdjs.TestLevelCode.GDNewSprite10Objects1.length ;i < len;++i) {
    gdjs.TestLevelCode.GDNewSprite10Objects1[i].hide();
}
}
}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.sound.isMusicOnChannelPlaying(runtimeScene, 3);
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("NewSprite10"), gdjs.TestLevelCode.GDNewSprite10Objects1);
{for(var i = 0, len = gdjs.TestLevelCode.GDNewSprite10Objects1.length ;i < len;++i) {
    gdjs.TestLevelCode.GDNewSprite10Objects1[i].hide(false);
}
}
}

}


{

gdjs.copyArray(runtimeScene.getObjects("Player"), gdjs.TestLevelCode.GDPlayerObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.TestLevelCode.GDPlayerObjects1.length;i<l;++i) {
    if ( gdjs.TestLevelCode.GDPlayerObjects1[i].getBehavior("PlatformerObject").isJumping() ) {
        isConditionTrue_0 = true;
        gdjs.TestLevelCode.GDPlayerObjects1[k] = gdjs.TestLevelCode.GDPlayerObjects1[i];
        ++k;
    }
}
gdjs.TestLevelCode.GDPlayerObjects1.length = k;
if (isConditionTrue_0) {
/* Reuse gdjs.TestLevelCode.GDPlayerObjects1 */
{for(var i = 0, len = gdjs.TestLevelCode.GDPlayerObjects1.length ;i < len;++i) {
    gdjs.TestLevelCode.GDPlayerObjects1[i].getBehavior("Animation").setAnimationName("Jumping jacks");
}
}
}

}


{

gdjs.copyArray(runtimeScene.getObjects("Player"), gdjs.TestLevelCode.GDPlayerObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.TestLevelCode.GDPlayerObjects1.length;i<l;++i) {
    if ( gdjs.TestLevelCode.GDPlayerObjects1[i].getBehavior("PlatformerObject").isFalling() ) {
        isConditionTrue_0 = true;
        gdjs.TestLevelCode.GDPlayerObjects1[k] = gdjs.TestLevelCode.GDPlayerObjects1[i];
        ++k;
    }
}
gdjs.TestLevelCode.GDPlayerObjects1.length = k;
if (isConditionTrue_0) {
/* Reuse gdjs.TestLevelCode.GDPlayerObjects1 */
{for(var i = 0, len = gdjs.TestLevelCode.GDPlayerObjects1.length ;i < len;++i) {
    gdjs.TestLevelCode.GDPlayerObjects1[i].getBehavior("Animation").setAnimationName("Fall");
}
}
}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.sound.isMusicOnChannelPaused(runtimeScene, 3);
if (isConditionTrue_0) {
{gdjs.evtTools.runtimeScene.replaceScene(runtimeScene, "Settings", false);
}
}

}


{

gdjs.copyArray(runtimeScene.getObjects("Pause"), gdjs.TestLevelCode.GDPauseObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.TestLevelCode.GDPauseObjects1.length;i<l;++i) {
    if ( gdjs.TestLevelCode.GDPauseObjects1[i].getBehavior("ButtonFSM").IsPressed(null) ) {
        isConditionTrue_0 = true;
        gdjs.TestLevelCode.GDPauseObjects1[k] = gdjs.TestLevelCode.GDPauseObjects1[i];
        ++k;
    }
}
gdjs.TestLevelCode.GDPauseObjects1.length = k;
if (isConditionTrue_0) {
{gdjs.evtTools.runtimeScene.replaceScene(runtimeScene, "Settings", false);
}
}

}


{

gdjs.copyArray(runtimeScene.getObjects("NewSprite4"), gdjs.TestLevelCode.GDNewSprite4Objects1);
gdjs.copyArray(runtimeScene.getObjects("Player"), gdjs.TestLevelCode.GDPlayerObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.TestLevelCode.mapOfGDgdjs_9546TestLevelCode_9546GDPlayerObjects1Objects, gdjs.TestLevelCode.mapOfGDgdjs_9546TestLevelCode_9546GDNewSprite4Objects1Objects, false, runtimeScene, false);
if (isConditionTrue_0) {
/* Reuse gdjs.TestLevelCode.GDNewSprite4Objects1 */
{for(var i = 0, len = gdjs.TestLevelCode.GDNewSprite4Objects1.length ;i < len;++i) {
    gdjs.TestLevelCode.GDNewSprite4Objects1[i].getBehavior("Animation").setAnimationName("cool");
}
}
}

}


{


let isConditionTrue_0 = false;
{
}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtsExt__Gamepads__C_Axis_pushed.func(runtimeScene, 1, "Left", "Any", null);
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("Jump"), gdjs.TestLevelCode.GDJumpObjects1);
gdjs.copyArray(runtimeScene.getObjects("ShadedDarkJoystick"), gdjs.TestLevelCode.GDShadedDarkJoystickObjects1);
{for(var i = 0, len = gdjs.TestLevelCode.GDShadedDarkJoystickObjects1.length ;i < len;++i) {
    gdjs.TestLevelCode.GDShadedDarkJoystickObjects1[i].deleteFromScene(runtimeScene);
}
}
{for(var i = 0, len = gdjs.TestLevelCode.GDJumpObjects1.length ;i < len;++i) {
    gdjs.TestLevelCode.GDJumpObjects1[i].deleteFromScene(runtimeScene);
}
}
}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.anyKeyPressed(runtimeScene);
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("Jump"), gdjs.TestLevelCode.GDJumpObjects1);
gdjs.copyArray(runtimeScene.getObjects("ShadedDarkJoystick"), gdjs.TestLevelCode.GDShadedDarkJoystickObjects1);
{for(var i = 0, len = gdjs.TestLevelCode.GDShadedDarkJoystickObjects1.length ;i < len;++i) {
    gdjs.TestLevelCode.GDShadedDarkJoystickObjects1[i].deleteFromScene(runtimeScene);
}
}
{for(var i = 0, len = gdjs.TestLevelCode.GDJumpObjects1.length ;i < len;++i) {
    gdjs.TestLevelCode.GDJumpObjects1[i].deleteFromScene(runtimeScene);
}
}
}

}


};

gdjs.TestLevelCode.func = function(runtimeScene) {
runtimeScene.getOnceTriggers().startNewFrame();

gdjs.TestLevelCode.GDPlayerObjects1.length = 0;
gdjs.TestLevelCode.GDPlayerObjects2.length = 0;
gdjs.TestLevelCode.GDCoinsObjects1.length = 0;
gdjs.TestLevelCode.GDCoinsObjects2.length = 0;
gdjs.TestLevelCode.GDPlatform_9595GroundObjects1.length = 0;
gdjs.TestLevelCode.GDPlatform_9595GroundObjects2.length = 0;
gdjs.TestLevelCode.GDNewSprite4Objects1.length = 0;
gdjs.TestLevelCode.GDNewSprite4Objects2.length = 0;
gdjs.TestLevelCode.GDNewSprite5Objects1.length = 0;
gdjs.TestLevelCode.GDNewSprite5Objects2.length = 0;
gdjs.TestLevelCode.GDNewSprite6Objects1.length = 0;
gdjs.TestLevelCode.GDNewSprite6Objects2.length = 0;
gdjs.TestLevelCode.GDspikeObjects1.length = 0;
gdjs.TestLevelCode.GDspikeObjects2.length = 0;
gdjs.TestLevelCode.GDNewSprite7Objects1.length = 0;
gdjs.TestLevelCode.GDNewSprite7Objects2.length = 0;
gdjs.TestLevelCode.GDNewSprite8Objects1.length = 0;
gdjs.TestLevelCode.GDNewSprite8Objects2.length = 0;
gdjs.TestLevelCode.GDNewSprite3Objects1.length = 0;
gdjs.TestLevelCode.GDNewSprite3Objects2.length = 0;
gdjs.TestLevelCode.GDpipeObjects1.length = 0;
gdjs.TestLevelCode.GDpipeObjects2.length = 0;
gdjs.TestLevelCode.GDStacyObjects1.length = 0;
gdjs.TestLevelCode.GDStacyObjects2.length = 0;
gdjs.TestLevelCode.GDShadedDarkJoystickObjects1.length = 0;
gdjs.TestLevelCode.GDShadedDarkJoystickObjects2.length = 0;
gdjs.TestLevelCode.GDNewSpriteObjects1.length = 0;
gdjs.TestLevelCode.GDNewSpriteObjects2.length = 0;
gdjs.TestLevelCode.GDNewSprite9Objects1.length = 0;
gdjs.TestLevelCode.GDNewSprite9Objects2.length = 0;
gdjs.TestLevelCode.GDMountain_9595dewObjects1.length = 0;
gdjs.TestLevelCode.GDMountain_9595dewObjects2.length = 0;
gdjs.TestLevelCode.GDNewSprite10Objects1.length = 0;
gdjs.TestLevelCode.GDNewSprite10Objects2.length = 0;
gdjs.TestLevelCode.GDJumpObjects1.length = 0;
gdjs.TestLevelCode.GDJumpObjects2.length = 0;
gdjs.TestLevelCode.GDCloudObjects1.length = 0;
gdjs.TestLevelCode.GDCloudObjects2.length = 0;
gdjs.TestLevelCode.GDTreeObjects1.length = 0;
gdjs.TestLevelCode.GDTreeObjects2.length = 0;
gdjs.TestLevelCode.GDPauseObjects1.length = 0;
gdjs.TestLevelCode.GDPauseObjects2.length = 0;
gdjs.TestLevelCode.GDMOuseclickObjects1.length = 0;
gdjs.TestLevelCode.GDMOuseclickObjects2.length = 0;
gdjs.TestLevelCode.GDNewTextObjects1.length = 0;
gdjs.TestLevelCode.GDNewTextObjects2.length = 0;
gdjs.TestLevelCode.GDNewSprite2Objects1.length = 0;
gdjs.TestLevelCode.GDNewSprite2Objects2.length = 0;
gdjs.TestLevelCode.GDNewSprite11Objects1.length = 0;
gdjs.TestLevelCode.GDNewSprite11Objects2.length = 0;
gdjs.TestLevelCode.GDNewSprite12Objects1.length = 0;
gdjs.TestLevelCode.GDNewSprite12Objects2.length = 0;
gdjs.TestLevelCode.GDNewSprite13Objects1.length = 0;
gdjs.TestLevelCode.GDNewSprite13Objects2.length = 0;
gdjs.TestLevelCode.GDNewTiledSpriteObjects1.length = 0;
gdjs.TestLevelCode.GDNewTiledSpriteObjects2.length = 0;

gdjs.TestLevelCode.eventsList0(runtimeScene);
gdjs.TestLevelCode.GDPlayerObjects1.length = 0;
gdjs.TestLevelCode.GDPlayerObjects2.length = 0;
gdjs.TestLevelCode.GDCoinsObjects1.length = 0;
gdjs.TestLevelCode.GDCoinsObjects2.length = 0;
gdjs.TestLevelCode.GDPlatform_9595GroundObjects1.length = 0;
gdjs.TestLevelCode.GDPlatform_9595GroundObjects2.length = 0;
gdjs.TestLevelCode.GDNewSprite4Objects1.length = 0;
gdjs.TestLevelCode.GDNewSprite4Objects2.length = 0;
gdjs.TestLevelCode.GDNewSprite5Objects1.length = 0;
gdjs.TestLevelCode.GDNewSprite5Objects2.length = 0;
gdjs.TestLevelCode.GDNewSprite6Objects1.length = 0;
gdjs.TestLevelCode.GDNewSprite6Objects2.length = 0;
gdjs.TestLevelCode.GDspikeObjects1.length = 0;
gdjs.TestLevelCode.GDspikeObjects2.length = 0;
gdjs.TestLevelCode.GDNewSprite7Objects1.length = 0;
gdjs.TestLevelCode.GDNewSprite7Objects2.length = 0;
gdjs.TestLevelCode.GDNewSprite8Objects1.length = 0;
gdjs.TestLevelCode.GDNewSprite8Objects2.length = 0;
gdjs.TestLevelCode.GDNewSprite3Objects1.length = 0;
gdjs.TestLevelCode.GDNewSprite3Objects2.length = 0;
gdjs.TestLevelCode.GDpipeObjects1.length = 0;
gdjs.TestLevelCode.GDpipeObjects2.length = 0;
gdjs.TestLevelCode.GDStacyObjects1.length = 0;
gdjs.TestLevelCode.GDStacyObjects2.length = 0;
gdjs.TestLevelCode.GDShadedDarkJoystickObjects1.length = 0;
gdjs.TestLevelCode.GDShadedDarkJoystickObjects2.length = 0;
gdjs.TestLevelCode.GDNewSpriteObjects1.length = 0;
gdjs.TestLevelCode.GDNewSpriteObjects2.length = 0;
gdjs.TestLevelCode.GDNewSprite9Objects1.length = 0;
gdjs.TestLevelCode.GDNewSprite9Objects2.length = 0;
gdjs.TestLevelCode.GDMountain_9595dewObjects1.length = 0;
gdjs.TestLevelCode.GDMountain_9595dewObjects2.length = 0;
gdjs.TestLevelCode.GDNewSprite10Objects1.length = 0;
gdjs.TestLevelCode.GDNewSprite10Objects2.length = 0;
gdjs.TestLevelCode.GDJumpObjects1.length = 0;
gdjs.TestLevelCode.GDJumpObjects2.length = 0;
gdjs.TestLevelCode.GDCloudObjects1.length = 0;
gdjs.TestLevelCode.GDCloudObjects2.length = 0;
gdjs.TestLevelCode.GDTreeObjects1.length = 0;
gdjs.TestLevelCode.GDTreeObjects2.length = 0;
gdjs.TestLevelCode.GDPauseObjects1.length = 0;
gdjs.TestLevelCode.GDPauseObjects2.length = 0;
gdjs.TestLevelCode.GDMOuseclickObjects1.length = 0;
gdjs.TestLevelCode.GDMOuseclickObjects2.length = 0;
gdjs.TestLevelCode.GDNewTextObjects1.length = 0;
gdjs.TestLevelCode.GDNewTextObjects2.length = 0;
gdjs.TestLevelCode.GDNewSprite2Objects1.length = 0;
gdjs.TestLevelCode.GDNewSprite2Objects2.length = 0;
gdjs.TestLevelCode.GDNewSprite11Objects1.length = 0;
gdjs.TestLevelCode.GDNewSprite11Objects2.length = 0;
gdjs.TestLevelCode.GDNewSprite12Objects1.length = 0;
gdjs.TestLevelCode.GDNewSprite12Objects2.length = 0;
gdjs.TestLevelCode.GDNewSprite13Objects1.length = 0;
gdjs.TestLevelCode.GDNewSprite13Objects2.length = 0;
gdjs.TestLevelCode.GDNewTiledSpriteObjects1.length = 0;
gdjs.TestLevelCode.GDNewTiledSpriteObjects2.length = 0;


return;

}

gdjs['TestLevelCode'] = gdjs.TestLevelCode;
