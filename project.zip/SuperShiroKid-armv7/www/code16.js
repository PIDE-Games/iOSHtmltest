gdjs.EndingCode = {};
gdjs.EndingCode.localVariables = [];
gdjs.EndingCode.idToCallbackMap = new Map();
gdjs.EndingCode.GDNewSpriteObjects1= [];
gdjs.EndingCode.GDNewSpriteObjects2= [];
gdjs.EndingCode.GDEndinggameObjects1= [];
gdjs.EndingCode.GDEndinggameObjects2= [];
gdjs.EndingCode.GDNewSprite2Objects1= [];
gdjs.EndingCode.GDNewSprite2Objects2= [];
gdjs.EndingCode.GDNewTextObjects1= [];
gdjs.EndingCode.GDNewTextObjects2= [];
gdjs.EndingCode.GDNewSprite3Objects1= [];
gdjs.EndingCode.GDNewSprite3Objects2= [];
gdjs.EndingCode.GDNewText2Objects1= [];
gdjs.EndingCode.GDNewText2Objects2= [];
gdjs.EndingCode.GDSkipObjects1= [];
gdjs.EndingCode.GDSkipObjects2= [];
gdjs.EndingCode.GDNewSprite4Objects1= [];
gdjs.EndingCode.GDNewSprite4Objects2= [];
gdjs.EndingCode.GDNewSprite5Objects1= [];
gdjs.EndingCode.GDNewSprite5Objects2= [];
gdjs.EndingCode.GDNewSprite6Objects1= [];
gdjs.EndingCode.GDNewSprite6Objects2= [];
gdjs.EndingCode.GDNewText3Objects1= [];
gdjs.EndingCode.GDNewText3Objects2= [];
gdjs.EndingCode.GDSkip_9595IntroObjects1= [];
gdjs.EndingCode.GDSkip_9595IntroObjects2= [];
gdjs.EndingCode.GDWaterObjects1= [];
gdjs.EndingCode.GDWaterObjects2= [];
gdjs.EndingCode.GDNewSprite7Objects1= [];
gdjs.EndingCode.GDNewSprite7Objects2= [];


gdjs.EndingCode.mapOfGDgdjs_9546EndingCode_9546GDSkip_95959595IntroObjects1Objects = Hashtable.newFrom({"Skip_Intro": gdjs.EndingCode.GDSkip_9595IntroObjects1});
gdjs.EndingCode.eventsList0 = function(runtimeScene) {

{

gdjs.copyArray(runtimeScene.getObjects("Skip_Intro"), gdjs.EndingCode.GDSkip_9595IntroObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.cursorOnObject(gdjs.EndingCode.mapOfGDgdjs_9546EndingCode_9546GDSkip_95959595IntroObjects1Objects, runtimeScene, true, false);
if (isConditionTrue_0) {
{gdjs.evtTools.runtimeScene.replaceScene(runtimeScene, "Title screen", false);
}
}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.runtimeScene.sceneJustBegins(runtimeScene);
if (isConditionTrue_0) {
{gdjs.evtTools.input.showCursor(runtimeScene);
}
}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.runtimeScene.sceneJustBegins(runtimeScene);
if (isConditionTrue_0) {
{gdjs.evtTools.sound.playMusicOnChannel(runtimeScene, "Mini Action 64 _ Shop.mp3", 1, true, 100, 1);
}
}

}


{


let isConditionTrue_0 = false;
{
}

}


};

gdjs.EndingCode.func = function(runtimeScene) {
runtimeScene.getOnceTriggers().startNewFrame();

gdjs.EndingCode.GDNewSpriteObjects1.length = 0;
gdjs.EndingCode.GDNewSpriteObjects2.length = 0;
gdjs.EndingCode.GDEndinggameObjects1.length = 0;
gdjs.EndingCode.GDEndinggameObjects2.length = 0;
gdjs.EndingCode.GDNewSprite2Objects1.length = 0;
gdjs.EndingCode.GDNewSprite2Objects2.length = 0;
gdjs.EndingCode.GDNewTextObjects1.length = 0;
gdjs.EndingCode.GDNewTextObjects2.length = 0;
gdjs.EndingCode.GDNewSprite3Objects1.length = 0;
gdjs.EndingCode.GDNewSprite3Objects2.length = 0;
gdjs.EndingCode.GDNewText2Objects1.length = 0;
gdjs.EndingCode.GDNewText2Objects2.length = 0;
gdjs.EndingCode.GDSkipObjects1.length = 0;
gdjs.EndingCode.GDSkipObjects2.length = 0;
gdjs.EndingCode.GDNewSprite4Objects1.length = 0;
gdjs.EndingCode.GDNewSprite4Objects2.length = 0;
gdjs.EndingCode.GDNewSprite5Objects1.length = 0;
gdjs.EndingCode.GDNewSprite5Objects2.length = 0;
gdjs.EndingCode.GDNewSprite6Objects1.length = 0;
gdjs.EndingCode.GDNewSprite6Objects2.length = 0;
gdjs.EndingCode.GDNewText3Objects1.length = 0;
gdjs.EndingCode.GDNewText3Objects2.length = 0;
gdjs.EndingCode.GDSkip_9595IntroObjects1.length = 0;
gdjs.EndingCode.GDSkip_9595IntroObjects2.length = 0;
gdjs.EndingCode.GDWaterObjects1.length = 0;
gdjs.EndingCode.GDWaterObjects2.length = 0;
gdjs.EndingCode.GDNewSprite7Objects1.length = 0;
gdjs.EndingCode.GDNewSprite7Objects2.length = 0;

gdjs.EndingCode.eventsList0(runtimeScene);
gdjs.EndingCode.GDNewSpriteObjects1.length = 0;
gdjs.EndingCode.GDNewSpriteObjects2.length = 0;
gdjs.EndingCode.GDEndinggameObjects1.length = 0;
gdjs.EndingCode.GDEndinggameObjects2.length = 0;
gdjs.EndingCode.GDNewSprite2Objects1.length = 0;
gdjs.EndingCode.GDNewSprite2Objects2.length = 0;
gdjs.EndingCode.GDNewTextObjects1.length = 0;
gdjs.EndingCode.GDNewTextObjects2.length = 0;
gdjs.EndingCode.GDNewSprite3Objects1.length = 0;
gdjs.EndingCode.GDNewSprite3Objects2.length = 0;
gdjs.EndingCode.GDNewText2Objects1.length = 0;
gdjs.EndingCode.GDNewText2Objects2.length = 0;
gdjs.EndingCode.GDSkipObjects1.length = 0;
gdjs.EndingCode.GDSkipObjects2.length = 0;
gdjs.EndingCode.GDNewSprite4Objects1.length = 0;
gdjs.EndingCode.GDNewSprite4Objects2.length = 0;
gdjs.EndingCode.GDNewSprite5Objects1.length = 0;
gdjs.EndingCode.GDNewSprite5Objects2.length = 0;
gdjs.EndingCode.GDNewSprite6Objects1.length = 0;
gdjs.EndingCode.GDNewSprite6Objects2.length = 0;
gdjs.EndingCode.GDNewText3Objects1.length = 0;
gdjs.EndingCode.GDNewText3Objects2.length = 0;
gdjs.EndingCode.GDSkip_9595IntroObjects1.length = 0;
gdjs.EndingCode.GDSkip_9595IntroObjects2.length = 0;
gdjs.EndingCode.GDWaterObjects1.length = 0;
gdjs.EndingCode.GDWaterObjects2.length = 0;
gdjs.EndingCode.GDNewSprite7Objects1.length = 0;
gdjs.EndingCode.GDNewSprite7Objects2.length = 0;


return;

}

gdjs['EndingCode'] = gdjs.EndingCode;
