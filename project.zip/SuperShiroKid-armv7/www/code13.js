gdjs.SettingsCode = {};
gdjs.SettingsCode.localVariables = [];
gdjs.SettingsCode.idToCallbackMap = new Map();
gdjs.SettingsCode.GDLOGOObjects1= [];
gdjs.SettingsCode.GDLOGOObjects2= [];
gdjs.SettingsCode.GDNew3DBoxObjects1= [];
gdjs.SettingsCode.GDNew3DBoxObjects2= [];
gdjs.SettingsCode.GDNewTiledSpriteObjects1= [];
gdjs.SettingsCode.GDNewTiledSpriteObjects2= [];
gdjs.SettingsCode.GDCreditsObjects1= [];
gdjs.SettingsCode.GDCreditsObjects2= [];
gdjs.SettingsCode.GDshirotitleObjects1= [];
gdjs.SettingsCode.GDshirotitleObjects2= [];
gdjs.SettingsCode.GDNewSpriteObjects1= [];
gdjs.SettingsCode.GDNewSpriteObjects2= [];
gdjs.SettingsCode.GDNewSprite2Objects1= [];
gdjs.SettingsCode.GDNewSprite2Objects2= [];
gdjs.SettingsCode.GDNewSprite3Objects1= [];
gdjs.SettingsCode.GDNewSprite3Objects2= [];
gdjs.SettingsCode.GDNewSprite4Objects1= [];
gdjs.SettingsCode.GDNewSprite4Objects2= [];
gdjs.SettingsCode.GDStart_9595GameObjects1= [];
gdjs.SettingsCode.GDStart_9595GameObjects2= [];
gdjs.SettingsCode.GDpressObjects1= [];
gdjs.SettingsCode.GDpressObjects2= [];
gdjs.SettingsCode.GDCOntroller_9595support_9595vsObjects1= [];
gdjs.SettingsCode.GDCOntroller_9595support_9595vsObjects2= [];
gdjs.SettingsCode.GDNewSprite5Objects1= [];
gdjs.SettingsCode.GDNewSprite5Objects2= [];
gdjs.SettingsCode.GDShiroObjects1= [];
gdjs.SettingsCode.GDShiroObjects2= [];
gdjs.SettingsCode.GDNewSprite6Objects1= [];
gdjs.SettingsCode.GDNewSprite6Objects2= [];
gdjs.SettingsCode.GDNewSprite7Objects1= [];
gdjs.SettingsCode.GDNewSprite7Objects2= [];
gdjs.SettingsCode.GDNewSprite8Objects1= [];
gdjs.SettingsCode.GDNewSprite8Objects2= [];
gdjs.SettingsCode.GDStartthingyObjects1= [];
gdjs.SettingsCode.GDStartthingyObjects2= [];
gdjs.SettingsCode.GDNew3DModelObjects1= [];
gdjs.SettingsCode.GDNew3DModelObjects2= [];


gdjs.SettingsCode.mapOfGDgdjs_9546SettingsCode_9546GDNewSpriteObjects1Objects = Hashtable.newFrom({"NewSprite": gdjs.SettingsCode.GDNewSpriteObjects1});
gdjs.SettingsCode.mapOfGDgdjs_9546SettingsCode_9546GDNewSprite8Objects1Objects = Hashtable.newFrom({"NewSprite8": gdjs.SettingsCode.GDNewSprite8Objects1});
gdjs.SettingsCode.mapOfGDgdjs_9546SettingsCode_9546GDStartthingyObjects1Objects = Hashtable.newFrom({"Startthingy": gdjs.SettingsCode.GDStartthingyObjects1});
gdjs.SettingsCode.mapOfGDgdjs_9546SettingsCode_9546GDshirotitleObjects1Objects = Hashtable.newFrom({"shirotitle": gdjs.SettingsCode.GDshirotitleObjects1});
gdjs.SettingsCode.mapOfGDgdjs_9546SettingsCode_9546GDStartthingyObjects1Objects = Hashtable.newFrom({"Startthingy": gdjs.SettingsCode.GDStartthingyObjects1});
gdjs.SettingsCode.mapOfGDgdjs_9546SettingsCode_9546GDNewSpriteObjects1Objects = Hashtable.newFrom({"NewSprite": gdjs.SettingsCode.GDNewSpriteObjects1});
gdjs.SettingsCode.mapOfGDgdjs_9546SettingsCode_9546GDNewSpriteObjects1Objects = Hashtable.newFrom({"NewSprite": gdjs.SettingsCode.GDNewSpriteObjects1});
gdjs.SettingsCode.mapOfGDgdjs_9546SettingsCode_9546GDNewSprite8Objects1Objects = Hashtable.newFrom({"NewSprite8": gdjs.SettingsCode.GDNewSprite8Objects1});
gdjs.SettingsCode.eventsList0 = function(runtimeScene) {

{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.runtimeScene.sceneJustBegins(runtimeScene);
if (isConditionTrue_0) {
{gdjs.evtTools.sound.playMusicOnChannel(runtimeScene, "TESTSONG001.mp3", 4, true, 100, 1);
}
}

}


{

gdjs.copyArray(runtimeScene.getObjects("Start_Game"), gdjs.SettingsCode.GDStart_9595GameObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.SettingsCode.GDStart_9595GameObjects1.length;i<l;++i) {
    if ( gdjs.SettingsCode.GDStart_9595GameObjects1[i].getBehavior("ButtonFSM").IsPressed(null) ) {
        isConditionTrue_0 = true;
        gdjs.SettingsCode.GDStart_9595GameObjects1[k] = gdjs.SettingsCode.GDStart_9595GameObjects1[i];
        ++k;
    }
}
gdjs.SettingsCode.GDStart_9595GameObjects1.length = k;
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("NewSprite"), gdjs.SettingsCode.GDNewSpriteObjects1);
gdjs.copyArray(runtimeScene.getObjects("NewSprite8"), gdjs.SettingsCode.GDNewSprite8Objects1);
{gdjs.evtTools.sound.stopMusicOnChannel(runtimeScene, 4);
}
{gdjs.evtTools.sound.playMusicOnChannel(runtimeScene, "Selecttitle.mp3", 5, false, 100, 1);
}
{for(var i = 0, len = gdjs.SettingsCode.GDNewSpriteObjects1.length ;i < len;++i) {
    gdjs.SettingsCode.GDNewSpriteObjects1[i].addForceTowardObject((gdjs.SettingsCode.GDNewSprite8Objects1.length !== 0 ? gdjs.SettingsCode.GDNewSprite8Objects1[0] : null), 1000, 1);
}
}
}

}


{

gdjs.copyArray(runtimeScene.getObjects("NewSprite2"), gdjs.SettingsCode.GDNewSprite2Objects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.SettingsCode.GDNewSprite2Objects1.length;i<l;++i) {
    if ( gdjs.SettingsCode.GDNewSprite2Objects1[i].getBehavior("ButtonFSM").IsPressed(null) ) {
        isConditionTrue_0 = true;
        gdjs.SettingsCode.GDNewSprite2Objects1[k] = gdjs.SettingsCode.GDNewSprite2Objects1[i];
        ++k;
    }
}
gdjs.SettingsCode.GDNewSprite2Objects1.length = k;
if (isConditionTrue_0) {
}

}


{

gdjs.copyArray(runtimeScene.getObjects("Start_Game"), gdjs.SettingsCode.GDStart_9595GameObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.SettingsCode.GDStart_9595GameObjects1.length;i<l;++i) {
    if ( gdjs.SettingsCode.GDStart_9595GameObjects1[i].getBehavior("ButtonFSM").IsHovered(null) ) {
        isConditionTrue_0 = true;
        gdjs.SettingsCode.GDStart_9595GameObjects1[k] = gdjs.SettingsCode.GDStart_9595GameObjects1[i];
        ++k;
    }
}
gdjs.SettingsCode.GDStart_9595GameObjects1.length = k;
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("shirotitle"), gdjs.SettingsCode.GDshirotitleObjects1);
{for(var i = 0, len = gdjs.SettingsCode.GDshirotitleObjects1.length ;i < len;++i) {
    gdjs.SettingsCode.GDshirotitleObjects1[i].getBehavior("Animation").setAnimationName("shirohappy");
}
}
}

}


{

gdjs.copyArray(runtimeScene.getObjects("Start_Game"), gdjs.SettingsCode.GDStart_9595GameObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.SettingsCode.GDStart_9595GameObjects1.length;i<l;++i) {
    if ( gdjs.SettingsCode.GDStart_9595GameObjects1[i].getBehavior("ButtonFSM").IsIdle(null) ) {
        isConditionTrue_0 = true;
        gdjs.SettingsCode.GDStart_9595GameObjects1[k] = gdjs.SettingsCode.GDStart_9595GameObjects1[i];
        ++k;
    }
}
gdjs.SettingsCode.GDStart_9595GameObjects1.length = k;
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("shirotitle"), gdjs.SettingsCode.GDshirotitleObjects1);
{for(var i = 0, len = gdjs.SettingsCode.GDshirotitleObjects1.length ;i < len;++i) {
    gdjs.SettingsCode.GDshirotitleObjects1[i].getBehavior("Animation").setAnimationName("NewSprite");
}
}
}

}


{

gdjs.copyArray(runtimeScene.getObjects("press"), gdjs.SettingsCode.GDpressObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.SettingsCode.GDpressObjects1.length;i<l;++i) {
    if ( gdjs.SettingsCode.GDpressObjects1[i].getBehavior("ButtonFSM").IsHovered(null) ) {
        isConditionTrue_0 = true;
        gdjs.SettingsCode.GDpressObjects1[k] = gdjs.SettingsCode.GDpressObjects1[i];
        ++k;
    }
}
gdjs.SettingsCode.GDpressObjects1.length = k;
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("shirotitle"), gdjs.SettingsCode.GDshirotitleObjects1);
{for(var i = 0, len = gdjs.SettingsCode.GDshirotitleObjects1.length ;i < len;++i) {
    gdjs.SettingsCode.GDshirotitleObjects1[i].getBehavior("Animation").setAnimationName("shirohappy");
}
}
}

}


{

gdjs.copyArray(runtimeScene.getObjects("press"), gdjs.SettingsCode.GDpressObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.SettingsCode.GDpressObjects1.length;i<l;++i) {
    if ( gdjs.SettingsCode.GDpressObjects1[i].getBehavior("ButtonFSM").IsIdle(null) ) {
        isConditionTrue_0 = true;
        gdjs.SettingsCode.GDpressObjects1[k] = gdjs.SettingsCode.GDpressObjects1[i];
        ++k;
    }
}
gdjs.SettingsCode.GDpressObjects1.length = k;
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("shirotitle"), gdjs.SettingsCode.GDshirotitleObjects1);
{for(var i = 0, len = gdjs.SettingsCode.GDshirotitleObjects1.length ;i < len;++i) {
    gdjs.SettingsCode.GDshirotitleObjects1[i].getBehavior("Animation").setAnimationName("NewSprite");
}
}
}

}


{

gdjs.copyArray(runtimeScene.getObjects("press"), gdjs.SettingsCode.GDpressObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.SettingsCode.GDpressObjects1.length;i<l;++i) {
    if ( gdjs.SettingsCode.GDpressObjects1[i].getBehavior("ButtonFSM").IsPressed(null) ) {
        isConditionTrue_0 = true;
        gdjs.SettingsCode.GDpressObjects1[k] = gdjs.SettingsCode.GDpressObjects1[i];
        ++k;
    }
}
gdjs.SettingsCode.GDpressObjects1.length = k;
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("NewSprite"), gdjs.SettingsCode.GDNewSpriteObjects1);
gdjs.copyArray(runtimeScene.getObjects("NewSprite8"), gdjs.SettingsCode.GDNewSprite8Objects1);
{gdjs.evtTools.sound.stopMusicOnChannel(runtimeScene, 4);
}
{for(var i = 0, len = gdjs.SettingsCode.GDNewSpriteObjects1.length ;i < len;++i) {
    gdjs.SettingsCode.GDNewSpriteObjects1[i].addForceTowardObject((gdjs.SettingsCode.GDNewSprite8Objects1.length !== 0 ? gdjs.SettingsCode.GDNewSprite8Objects1[0] : null), 100, 1);
}
}
}

}


{

gdjs.copyArray(runtimeScene.getObjects("NewSprite7"), gdjs.SettingsCode.GDNewSprite7Objects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.SettingsCode.GDNewSprite7Objects1.length;i<l;++i) {
    if ( gdjs.SettingsCode.GDNewSprite7Objects1[i].getBehavior("ButtonFSM").IsClicked(null) ) {
        isConditionTrue_0 = true;
        gdjs.SettingsCode.GDNewSprite7Objects1[k] = gdjs.SettingsCode.GDNewSprite7Objects1[i];
        ++k;
    }
}
gdjs.SettingsCode.GDNewSprite7Objects1.length = k;
if (isConditionTrue_0) {
{gdjs.evtTools.window.openURL("https://pide-games.itch.io", runtimeScene);
}
}

}


{

gdjs.copyArray(runtimeScene.getObjects("NewSprite8"), gdjs.SettingsCode.GDNewSprite8Objects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.SettingsCode.GDNewSprite8Objects1.length;i<l;++i) {
    if ( gdjs.SettingsCode.GDNewSprite8Objects1[i].getBehavior("ButtonFSM").IsPressed(null) ) {
        isConditionTrue_0 = true;
        gdjs.SettingsCode.GDNewSprite8Objects1[k] = gdjs.SettingsCode.GDNewSprite8Objects1[i];
        ++k;
    }
}
gdjs.SettingsCode.GDNewSprite8Objects1.length = k;
if (isConditionTrue_0) {
{gdjs.evtTools.runtimeScene.replaceScene(runtimeScene, "TestLevel", false);
}
}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtsExt__Gamepads__C_Axis_pushed.func(runtimeScene, 1, "Left", "Up", null);
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("Start_Game"), gdjs.SettingsCode.GDStart_9595GameObjects1);
{for(var i = 0, len = gdjs.SettingsCode.GDStart_9595GameObjects1.length ;i < len;++i) {
    gdjs.SettingsCode.GDStart_9595GameObjects1[i].getBehavior("ButtonAnimationName").SetIdleAnimationName("press", null);
}
}
}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtsExt__Gamepads__C_Button_pressed.func(runtimeScene, 1, "Start", null);
if (isConditionTrue_0) {
{gdjs.evtTools.runtimeScene.replaceScene(runtimeScene, "TUTORIAL", false);
}
{gdjs.evtTools.sound.stopMusicOnChannel(runtimeScene, 4);
}
{gdjs.evtTools.sound.playMusicOnChannel(runtimeScene, "Selecttitle.mp3", 5, false, 100, 1);
}
}

}


{

gdjs.copyArray(runtimeScene.getObjects("NewSprite2"), gdjs.SettingsCode.GDNewSprite2Objects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.SettingsCode.GDNewSprite2Objects1.length;i<l;++i) {
    if ( gdjs.SettingsCode.GDNewSprite2Objects1[i].getBehavior("ButtonFSM").IsPressed(null) ) {
        isConditionTrue_0 = true;
        gdjs.SettingsCode.GDNewSprite2Objects1[k] = gdjs.SettingsCode.GDNewSprite2Objects1[i];
        ++k;
    }
}
gdjs.SettingsCode.GDNewSprite2Objects1.length = k;
if (isConditionTrue_0) {
{gdjs.evtTools.sound.playMusicOnChannel(runtimeScene, "Backy.wav", 5, false, 100, 1);
}
}

}


{

gdjs.copyArray(runtimeScene.getObjects("NewSprite"), gdjs.SettingsCode.GDNewSpriteObjects1);
gdjs.copyArray(runtimeScene.getObjects("NewSprite8"), gdjs.SettingsCode.GDNewSprite8Objects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.SettingsCode.mapOfGDgdjs_9546SettingsCode_9546GDNewSpriteObjects1Objects, gdjs.SettingsCode.mapOfGDgdjs_9546SettingsCode_9546GDNewSprite8Objects1Objects, false, runtimeScene, false);
if (isConditionTrue_0) {
{gdjs.evtTools.runtimeScene.replaceScene(runtimeScene, "TUTORIAL", false);
}
}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.runtimeScene.sceneJustBegins(runtimeScene);
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("NewSprite"), gdjs.SettingsCode.GDNewSpriteObjects1);
gdjs.copyArray(runtimeScene.getObjects("Startthingy"), gdjs.SettingsCode.GDStartthingyObjects1);
{for(var i = 0, len = gdjs.SettingsCode.GDStartthingyObjects1.length ;i < len;++i) {
    gdjs.SettingsCode.GDStartthingyObjects1[i].addForceTowardObject((gdjs.SettingsCode.GDNewSpriteObjects1.length !== 0 ? gdjs.SettingsCode.GDNewSpriteObjects1[0] : null), 4000, 1);
}
}
}

}


{

gdjs.copyArray(runtimeScene.getObjects("NewSprite2"), gdjs.SettingsCode.GDNewSprite2Objects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.SettingsCode.GDNewSprite2Objects1.length;i<l;++i) {
    if ( gdjs.SettingsCode.GDNewSprite2Objects1[i].getBehavior("ButtonFSM").IsPressed(null) ) {
        isConditionTrue_0 = true;
        gdjs.SettingsCode.GDNewSprite2Objects1[k] = gdjs.SettingsCode.GDNewSprite2Objects1[i];
        ++k;
    }
}
gdjs.SettingsCode.GDNewSprite2Objects1.length = k;
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("NewSprite"), gdjs.SettingsCode.GDNewSpriteObjects1);
gdjs.copyArray(runtimeScene.getObjects("Startthingy"), gdjs.SettingsCode.GDStartthingyObjects1);
{for(var i = 0, len = gdjs.SettingsCode.GDStartthingyObjects1.length ;i < len;++i) {
    gdjs.SettingsCode.GDStartthingyObjects1[i].addForceTowardObject((gdjs.SettingsCode.GDNewSpriteObjects1.length !== 0 ? gdjs.SettingsCode.GDNewSpriteObjects1[0] : null), 4000, 1);
}
}
}

}


{

gdjs.copyArray(runtimeScene.getObjects("Startthingy"), gdjs.SettingsCode.GDStartthingyObjects1);
gdjs.copyArray(runtimeScene.getObjects("shirotitle"), gdjs.SettingsCode.GDshirotitleObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.SettingsCode.mapOfGDgdjs_9546SettingsCode_9546GDStartthingyObjects1Objects, gdjs.SettingsCode.mapOfGDgdjs_9546SettingsCode_9546GDshirotitleObjects1Objects, false, runtimeScene, false);
if (isConditionTrue_0) {
{gdjs.evtTools.runtimeScene.replaceScene(runtimeScene, "Title screen", false);
}
}

}


{

gdjs.copyArray(runtimeScene.getObjects("NewSprite"), gdjs.SettingsCode.GDNewSpriteObjects1);
gdjs.copyArray(runtimeScene.getObjects("Startthingy"), gdjs.SettingsCode.GDStartthingyObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.SettingsCode.mapOfGDgdjs_9546SettingsCode_9546GDStartthingyObjects1Objects, gdjs.SettingsCode.mapOfGDgdjs_9546SettingsCode_9546GDNewSpriteObjects1Objects, false, runtimeScene, false);
if (isConditionTrue_0) {
/* Reuse gdjs.SettingsCode.GDStartthingyObjects1 */
{for(var i = 0, len = gdjs.SettingsCode.GDStartthingyObjects1.length ;i < len;++i) {
    gdjs.SettingsCode.GDStartthingyObjects1[i].addForce(0, 0, 1);
}
}
}

}


{

gdjs.copyArray(runtimeScene.getObjects("NewSprite"), gdjs.SettingsCode.GDNewSpriteObjects1);
gdjs.copyArray(runtimeScene.getObjects("NewSprite8"), gdjs.SettingsCode.GDNewSprite8Objects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.SettingsCode.mapOfGDgdjs_9546SettingsCode_9546GDNewSpriteObjects1Objects, gdjs.SettingsCode.mapOfGDgdjs_9546SettingsCode_9546GDNewSprite8Objects1Objects, false, runtimeScene, false);
if (isConditionTrue_0) {
{gdjs.evtTools.sound.pauseMusicOnChannel(runtimeScene, 4);
}
}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.sound.isMusicOnChannelStopped(runtimeScene, 4);
if (isConditionTrue_0) {
}

}


};

gdjs.SettingsCode.func = function(runtimeScene) {
runtimeScene.getOnceTriggers().startNewFrame();

gdjs.SettingsCode.GDLOGOObjects1.length = 0;
gdjs.SettingsCode.GDLOGOObjects2.length = 0;
gdjs.SettingsCode.GDNew3DBoxObjects1.length = 0;
gdjs.SettingsCode.GDNew3DBoxObjects2.length = 0;
gdjs.SettingsCode.GDNewTiledSpriteObjects1.length = 0;
gdjs.SettingsCode.GDNewTiledSpriteObjects2.length = 0;
gdjs.SettingsCode.GDCreditsObjects1.length = 0;
gdjs.SettingsCode.GDCreditsObjects2.length = 0;
gdjs.SettingsCode.GDshirotitleObjects1.length = 0;
gdjs.SettingsCode.GDshirotitleObjects2.length = 0;
gdjs.SettingsCode.GDNewSpriteObjects1.length = 0;
gdjs.SettingsCode.GDNewSpriteObjects2.length = 0;
gdjs.SettingsCode.GDNewSprite2Objects1.length = 0;
gdjs.SettingsCode.GDNewSprite2Objects2.length = 0;
gdjs.SettingsCode.GDNewSprite3Objects1.length = 0;
gdjs.SettingsCode.GDNewSprite3Objects2.length = 0;
gdjs.SettingsCode.GDNewSprite4Objects1.length = 0;
gdjs.SettingsCode.GDNewSprite4Objects2.length = 0;
gdjs.SettingsCode.GDStart_9595GameObjects1.length = 0;
gdjs.SettingsCode.GDStart_9595GameObjects2.length = 0;
gdjs.SettingsCode.GDpressObjects1.length = 0;
gdjs.SettingsCode.GDpressObjects2.length = 0;
gdjs.SettingsCode.GDCOntroller_9595support_9595vsObjects1.length = 0;
gdjs.SettingsCode.GDCOntroller_9595support_9595vsObjects2.length = 0;
gdjs.SettingsCode.GDNewSprite5Objects1.length = 0;
gdjs.SettingsCode.GDNewSprite5Objects2.length = 0;
gdjs.SettingsCode.GDShiroObjects1.length = 0;
gdjs.SettingsCode.GDShiroObjects2.length = 0;
gdjs.SettingsCode.GDNewSprite6Objects1.length = 0;
gdjs.SettingsCode.GDNewSprite6Objects2.length = 0;
gdjs.SettingsCode.GDNewSprite7Objects1.length = 0;
gdjs.SettingsCode.GDNewSprite7Objects2.length = 0;
gdjs.SettingsCode.GDNewSprite8Objects1.length = 0;
gdjs.SettingsCode.GDNewSprite8Objects2.length = 0;
gdjs.SettingsCode.GDStartthingyObjects1.length = 0;
gdjs.SettingsCode.GDStartthingyObjects2.length = 0;
gdjs.SettingsCode.GDNew3DModelObjects1.length = 0;
gdjs.SettingsCode.GDNew3DModelObjects2.length = 0;

gdjs.SettingsCode.eventsList0(runtimeScene);
gdjs.SettingsCode.GDLOGOObjects1.length = 0;
gdjs.SettingsCode.GDLOGOObjects2.length = 0;
gdjs.SettingsCode.GDNew3DBoxObjects1.length = 0;
gdjs.SettingsCode.GDNew3DBoxObjects2.length = 0;
gdjs.SettingsCode.GDNewTiledSpriteObjects1.length = 0;
gdjs.SettingsCode.GDNewTiledSpriteObjects2.length = 0;
gdjs.SettingsCode.GDCreditsObjects1.length = 0;
gdjs.SettingsCode.GDCreditsObjects2.length = 0;
gdjs.SettingsCode.GDshirotitleObjects1.length = 0;
gdjs.SettingsCode.GDshirotitleObjects2.length = 0;
gdjs.SettingsCode.GDNewSpriteObjects1.length = 0;
gdjs.SettingsCode.GDNewSpriteObjects2.length = 0;
gdjs.SettingsCode.GDNewSprite2Objects1.length = 0;
gdjs.SettingsCode.GDNewSprite2Objects2.length = 0;
gdjs.SettingsCode.GDNewSprite3Objects1.length = 0;
gdjs.SettingsCode.GDNewSprite3Objects2.length = 0;
gdjs.SettingsCode.GDNewSprite4Objects1.length = 0;
gdjs.SettingsCode.GDNewSprite4Objects2.length = 0;
gdjs.SettingsCode.GDStart_9595GameObjects1.length = 0;
gdjs.SettingsCode.GDStart_9595GameObjects2.length = 0;
gdjs.SettingsCode.GDpressObjects1.length = 0;
gdjs.SettingsCode.GDpressObjects2.length = 0;
gdjs.SettingsCode.GDCOntroller_9595support_9595vsObjects1.length = 0;
gdjs.SettingsCode.GDCOntroller_9595support_9595vsObjects2.length = 0;
gdjs.SettingsCode.GDNewSprite5Objects1.length = 0;
gdjs.SettingsCode.GDNewSprite5Objects2.length = 0;
gdjs.SettingsCode.GDShiroObjects1.length = 0;
gdjs.SettingsCode.GDShiroObjects2.length = 0;
gdjs.SettingsCode.GDNewSprite6Objects1.length = 0;
gdjs.SettingsCode.GDNewSprite6Objects2.length = 0;
gdjs.SettingsCode.GDNewSprite7Objects1.length = 0;
gdjs.SettingsCode.GDNewSprite7Objects2.length = 0;
gdjs.SettingsCode.GDNewSprite8Objects1.length = 0;
gdjs.SettingsCode.GDNewSprite8Objects2.length = 0;
gdjs.SettingsCode.GDStartthingyObjects1.length = 0;
gdjs.SettingsCode.GDStartthingyObjects2.length = 0;
gdjs.SettingsCode.GDNew3DModelObjects1.length = 0;
gdjs.SettingsCode.GDNew3DModelObjects2.length = 0;


return;

}

gdjs['SettingsCode'] = gdjs.SettingsCode;
