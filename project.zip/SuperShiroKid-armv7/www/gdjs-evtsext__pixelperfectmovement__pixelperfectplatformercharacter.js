
gdjs.evtsExt__PixelPerfectMovement__PixelPerfectPlatformerCharacter = gdjs.evtsExt__PixelPerfectMovement__PixelPerfectPlatformerCharacter || {};

/**
 * Behavior generated from Pixel perfect platformer character
 */
gdjs.evtsExt__PixelPerfectMovement__PixelPerfectPlatformerCharacter.PixelPerfectPlatformerCharacter = class PixelPerfectPlatformerCharacter extends gdjs.RuntimeBehavior {
  constructor(instanceContainer, behaviorData, owner) {
    super(instanceContainer, behaviorData, owner);
    this._runtimeScene = instanceContainer;

    this._onceTriggers = new gdjs.OnceTriggers();
    this._behaviorData = {};
    this._sharedData = gdjs.evtsExt__PixelPerfectMovement__PixelPerfectPlatformerCharacter.PixelPerfectPlatformerCharacter.getSharedData(
      instanceContainer,
      behaviorData.name
    );
    
    this._behaviorData.PlatformerCharacter = behaviorData.PlatformerCharacter !== undefined ? behaviorData.PlatformerCharacter : "";
    this._behaviorData.PixelSize = behaviorData.PixelSize !== undefined ? behaviorData.PixelSize : Number("1") || 0;
    this._behaviorData.OffsetX = behaviorData.OffsetX !== undefined ? behaviorData.OffsetX : Number("0") || 0;
    this._behaviorData.OffsetY = behaviorData.OffsetY !== undefined ? behaviorData.OffsetY : Number("0") || 0;
    this._behaviorData.TargetX = Number("0") || 0;
    this._behaviorData.TargetDirectionX = Number("0") || 0;
    this._behaviorData.TargetY = Number("0") || 0;
    this._behaviorData.TargetDirectionY = Number("0") || 0;
    this._behaviorData.PreviousSpeedX = Number("") || 0;
    this._behaviorData.IsDecelerating = false;
  }

  // Hot-reload:
  applyBehaviorOverriding(behaviorOverriding) {
    
    if (behaviorOverriding.PlatformerCharacter !== undefined)
      this._behaviorData.PlatformerCharacter = behaviorOverriding.PlatformerCharacter;
    if (behaviorOverriding.PixelSize !== undefined)
      this._behaviorData.PixelSize = behaviorOverriding.PixelSize;
    if (behaviorOverriding.OffsetX !== undefined)
      this._behaviorData.OffsetX = behaviorOverriding.OffsetX;
    if (behaviorOverriding.OffsetY !== undefined)
      this._behaviorData.OffsetY = behaviorOverriding.OffsetY;
    if (behaviorOverriding.TargetX !== undefined)
      this._behaviorData.TargetX = behaviorOverriding.TargetX;
    if (behaviorOverriding.TargetDirectionX !== undefined)
      this._behaviorData.TargetDirectionX = behaviorOverriding.TargetDirectionX;
    if (behaviorOverriding.TargetY !== undefined)
      this._behaviorData.TargetY = behaviorOverriding.TargetY;
    if (behaviorOverriding.TargetDirectionY !== undefined)
      this._behaviorData.TargetDirectionY = behaviorOverriding.TargetDirectionY;
    if (behaviorOverriding.PreviousSpeedX !== undefined)
      this._behaviorData.PreviousSpeedX = behaviorOverriding.PreviousSpeedX;
    if (behaviorOverriding.IsDecelerating !== undefined)
      this._behaviorData.IsDecelerating = behaviorOverriding.IsDecelerating;

    return true;
  }

  // Network sync:
  getNetworkSyncData(syncOptions) {
    return {
      ...super.getNetworkSyncData(syncOptions),
      props: {
        
    PlatformerCharacter: this._behaviorData.PlatformerCharacter,
    PixelSize: this._behaviorData.PixelSize,
    OffsetX: this._behaviorData.OffsetX,
    OffsetY: this._behaviorData.OffsetY,
    TargetX: this._behaviorData.TargetX,
    TargetDirectionX: this._behaviorData.TargetDirectionX,
    TargetY: this._behaviorData.TargetY,
    TargetDirectionY: this._behaviorData.TargetDirectionY,
    PreviousSpeedX: this._behaviorData.PreviousSpeedX,
    IsDecelerating: this._behaviorData.IsDecelerating,
      }
    };
  }
  updateFromNetworkSyncData(networkSyncData, options) {
    super.updateFromNetworkSyncData(networkSyncData, options);
    
    if (networkSyncData.props.PlatformerCharacter !== undefined)
      this._behaviorData.PlatformerCharacter = networkSyncData.props.PlatformerCharacter;
    if (networkSyncData.props.PixelSize !== undefined)
      this._behaviorData.PixelSize = networkSyncData.props.PixelSize;
    if (networkSyncData.props.OffsetX !== undefined)
      this._behaviorData.OffsetX = networkSyncData.props.OffsetX;
    if (networkSyncData.props.OffsetY !== undefined)
      this._behaviorData.OffsetY = networkSyncData.props.OffsetY;
    if (networkSyncData.props.TargetX !== undefined)
      this._behaviorData.TargetX = networkSyncData.props.TargetX;
    if (networkSyncData.props.TargetDirectionX !== undefined)
      this._behaviorData.TargetDirectionX = networkSyncData.props.TargetDirectionX;
    if (networkSyncData.props.TargetY !== undefined)
      this._behaviorData.TargetY = networkSyncData.props.TargetY;
    if (networkSyncData.props.TargetDirectionY !== undefined)
      this._behaviorData.TargetDirectionY = networkSyncData.props.TargetDirectionY;
    if (networkSyncData.props.PreviousSpeedX !== undefined)
      this._behaviorData.PreviousSpeedX = networkSyncData.props.PreviousSpeedX;
    if (networkSyncData.props.IsDecelerating !== undefined)
      this._behaviorData.IsDecelerating = networkSyncData.props.IsDecelerating;
  }

  // Properties:
  
  _getPlatformerCharacter() {
    return this._behaviorData.PlatformerCharacter !== undefined ? this._behaviorData.PlatformerCharacter : "";
  }
  _setPlatformerCharacter(newValue) {
    this._behaviorData.PlatformerCharacter = newValue;
  }
  _getPixelSize() {
    return this._behaviorData.PixelSize !== undefined ? this._behaviorData.PixelSize : Number("1") || 0;
  }
  _setPixelSize(newValue) {
    this._behaviorData.PixelSize = newValue;
  }
  _getOffsetX() {
    return this._behaviorData.OffsetX !== undefined ? this._behaviorData.OffsetX : Number("0") || 0;
  }
  _setOffsetX(newValue) {
    this._behaviorData.OffsetX = newValue;
  }
  _getOffsetY() {
    return this._behaviorData.OffsetY !== undefined ? this._behaviorData.OffsetY : Number("0") || 0;
  }
  _setOffsetY(newValue) {
    this._behaviorData.OffsetY = newValue;
  }
  _getTargetX() {
    return this._behaviorData.TargetX !== undefined ? this._behaviorData.TargetX : Number("0") || 0;
  }
  _setTargetX(newValue) {
    this._behaviorData.TargetX = newValue;
  }
  _getTargetDirectionX() {
    return this._behaviorData.TargetDirectionX !== undefined ? this._behaviorData.TargetDirectionX : Number("0") || 0;
  }
  _setTargetDirectionX(newValue) {
    this._behaviorData.TargetDirectionX = newValue;
  }
  _getTargetY() {
    return this._behaviorData.TargetY !== undefined ? this._behaviorData.TargetY : Number("0") || 0;
  }
  _setTargetY(newValue) {
    this._behaviorData.TargetY = newValue;
  }
  _getTargetDirectionY() {
    return this._behaviorData.TargetDirectionY !== undefined ? this._behaviorData.TargetDirectionY : Number("0") || 0;
  }
  _setTargetDirectionY(newValue) {
    this._behaviorData.TargetDirectionY = newValue;
  }
  _getPreviousSpeedX() {
    return this._behaviorData.PreviousSpeedX !== undefined ? this._behaviorData.PreviousSpeedX : Number("") || 0;
  }
  _setPreviousSpeedX(newValue) {
    this._behaviorData.PreviousSpeedX = newValue;
  }
  _getIsDecelerating() {
    return this._behaviorData.IsDecelerating !== undefined ? this._behaviorData.IsDecelerating : false;
  }
  _setIsDecelerating(newValue) {
    this._behaviorData.IsDecelerating = newValue;
  }
  _toggleIsDecelerating() {
    this._setIsDecelerating(!this._getIsDecelerating());
  }
}

/**
 * Shared data generated from Pixel perfect platformer character
 */
gdjs.evtsExt__PixelPerfectMovement__PixelPerfectPlatformerCharacter.PixelPerfectPlatformerCharacter.SharedData = class PixelPerfectPlatformerCharacterSharedData {
  constructor(sharedData) {
    
  }
  
  // Shared properties:
  
}

gdjs.evtsExt__PixelPerfectMovement__PixelPerfectPlatformerCharacter.PixelPerfectPlatformerCharacter.getSharedData = function(instanceContainer, behaviorName) {
  if (!instanceContainer._PixelPerfectMovement_PixelPerfectPlatformerCharacterSharedData) {
    const initialData = instanceContainer.getInitialSharedDataForBehavior(
      behaviorName
    );
    instanceContainer._PixelPerfectMovement_PixelPerfectPlatformerCharacterSharedData = new gdjs.evtsExt__PixelPerfectMovement__PixelPerfectPlatformerCharacter.PixelPerfectPlatformerCharacter.SharedData(
      initialData
    );
  }
  return instanceContainer._PixelPerfectMovement_PixelPerfectPlatformerCharacterSharedData;
}

// Methods:
gdjs.evtsExt__PixelPerfectMovement__PixelPerfectPlatformerCharacter.PixelPerfectPlatformerCharacter.prototype.doStepPreEventsContext = {};
gdjs.evtsExt__PixelPerfectMovement__PixelPerfectPlatformerCharacter.PixelPerfectPlatformerCharacter.prototype.doStepPreEventsContext.idToCallbackMap = new Map();
gdjs.evtsExt__PixelPerfectMovement__PixelPerfectPlatformerCharacter.PixelPerfectPlatformerCharacter.prototype.doStepPreEventsContext.GDObjectObjects1_1final = [];

gdjs.evtsExt__PixelPerfectMovement__PixelPerfectPlatformerCharacter.PixelPerfectPlatformerCharacter.prototype.doStepPreEventsContext.GDObjectObjects2_1final = [];

gdjs.evtsExt__PixelPerfectMovement__PixelPerfectPlatformerCharacter.PixelPerfectPlatformerCharacter.prototype.doStepPreEventsContext.GDObjectObjects1= [];
gdjs.evtsExt__PixelPerfectMovement__PixelPerfectPlatformerCharacter.PixelPerfectPlatformerCharacter.prototype.doStepPreEventsContext.GDObjectObjects2= [];
gdjs.evtsExt__PixelPerfectMovement__PixelPerfectPlatformerCharacter.PixelPerfectPlatformerCharacter.prototype.doStepPreEventsContext.GDObjectObjects3= [];
gdjs.evtsExt__PixelPerfectMovement__PixelPerfectPlatformerCharacter.PixelPerfectPlatformerCharacter.prototype.doStepPreEventsContext.GDObjectObjects4= [];


gdjs.evtsExt__PixelPerfectMovement__PixelPerfectPlatformerCharacter.PixelPerfectPlatformerCharacter.prototype.doStepPreEventsContext.eventsList0 = function(runtimeScene, eventsFunctionContext) {

};gdjs.evtsExt__PixelPerfectMovement__PixelPerfectPlatformerCharacter.PixelPerfectPlatformerCharacter.prototype.doStepPreEventsContext.eventsList1 = function(runtimeScene, eventsFunctionContext) {

};gdjs.evtsExt__PixelPerfectMovement__PixelPerfectPlatformerCharacter.PixelPerfectPlatformerCharacter.prototype.doStepPreEventsContext.eventsList2 = function(runtimeScene, eventsFunctionContext) {

{

gdjs.copyArray(gdjs.evtsExt__PixelPerfectMovement__PixelPerfectPlatformerCharacter.PixelPerfectPlatformerCharacter.prototype.doStepPreEventsContext.GDObjectObjects1, gdjs.evtsExt__PixelPerfectMovement__PixelPerfectPlatformerCharacter.PixelPerfectPlatformerCharacter.prototype.doStepPreEventsContext.GDObjectObjects3);


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.evtsExt__PixelPerfectMovement__PixelPerfectPlatformerCharacter.PixelPerfectPlatformerCharacter.prototype.doStepPreEventsContext.GDObjectObjects3.length;i<l;++i) {
    if ( gdjs.evtsExt__PixelPerfectMovement__PixelPerfectPlatformerCharacter.PixelPerfectPlatformerCharacter.prototype.doStepPreEventsContext.GDObjectObjects3[i].getBehavior(eventsFunctionContext.getBehaviorName("PlatformerCharacter")).getCurrentSpeed() > 0 ) {
        isConditionTrue_0 = true;
        gdjs.evtsExt__PixelPerfectMovement__PixelPerfectPlatformerCharacter.PixelPerfectPlatformerCharacter.prototype.doStepPreEventsContext.GDObjectObjects3[k] = gdjs.evtsExt__PixelPerfectMovement__PixelPerfectPlatformerCharacter.PixelPerfectPlatformerCharacter.prototype.doStepPreEventsContext.GDObjectObjects3[i];
        ++k;
    }
}
gdjs.evtsExt__PixelPerfectMovement__PixelPerfectPlatformerCharacter.PixelPerfectPlatformerCharacter.prototype.doStepPreEventsContext.GDObjectObjects3.length = k;
if (isConditionTrue_0) {
/* Reuse gdjs.evtsExt__PixelPerfectMovement__PixelPerfectPlatformerCharacter.PixelPerfectPlatformerCharacter.prototype.doStepPreEventsContext.GDObjectObjects3 */
{eventsFunctionContext.getObjects("Object")[0].getBehavior(eventsFunctionContext.getBehaviorName("Behavior"))._setTargetX(eventsFunctionContext.getObjects("Object")[0].getBehavior(eventsFunctionContext.getBehaviorName("Behavior"))._getOffsetX() + eventsFunctionContext.getObjects("Object")[0].getBehavior(eventsFunctionContext.getBehaviorName("Behavior"))._getPixelSize() * Math.ceil(((( gdjs.evtsExt__PixelPerfectMovement__PixelPerfectPlatformerCharacter.PixelPerfectPlatformerCharacter.prototype.doStepPreEventsContext.GDObjectObjects3.length === 0 ) ? 0 :gdjs.evtsExt__PixelPerfectMovement__PixelPerfectPlatformerCharacter.PixelPerfectPlatformerCharacter.prototype.doStepPreEventsContext.GDObjectObjects3[0].getX()) + gdjs.evtsExt__PixelPerfectMovement__BrakingDistance.func(runtimeScene, (( gdjs.evtsExt__PixelPerfectMovement__PixelPerfectPlatformerCharacter.PixelPerfectPlatformerCharacter.prototype.doStepPreEventsContext.GDObjectObjects3.length === 0 ) ? 0 :gdjs.evtsExt__PixelPerfectMovement__PixelPerfectPlatformerCharacter.PixelPerfectPlatformerCharacter.prototype.doStepPreEventsContext.GDObjectObjects3[0].getBehavior(eventsFunctionContext.getBehaviorName("PlatformerCharacter")).getCurrentSpeed()), (( gdjs.evtsExt__PixelPerfectMovement__PixelPerfectPlatformerCharacter.PixelPerfectPlatformerCharacter.prototype.doStepPreEventsContext.GDObjectObjects3.length === 0 ) ? 0 :gdjs.evtsExt__PixelPerfectMovement__PixelPerfectPlatformerCharacter.PixelPerfectPlatformerCharacter.prototype.doStepPreEventsContext.GDObjectObjects3[0].getBehavior(eventsFunctionContext.getBehaviorName("PlatformerCharacter")).getDeceleration()), eventsFunctionContext) - eventsFunctionContext.getObjects("Object")[0].getBehavior(eventsFunctionContext.getBehaviorName("Behavior"))._getOffsetX()) / eventsFunctionContext.getObjects("Object")[0].getBehavior(eventsFunctionContext.getBehaviorName("Behavior"))._getPixelSize()))
}
{eventsFunctionContext.getObjects("Object")[0].getBehavior(eventsFunctionContext.getBehaviorName("Behavior"))._setTargetDirectionX(1)
}

{ //Subevents
gdjs.evtsExt__PixelPerfectMovement__PixelPerfectPlatformerCharacter.PixelPerfectPlatformerCharacter.prototype.doStepPreEventsContext.eventsList0(runtimeScene, eventsFunctionContext);} //End of subevents
}

}


{

gdjs.copyArray(gdjs.evtsExt__PixelPerfectMovement__PixelPerfectPlatformerCharacter.PixelPerfectPlatformerCharacter.prototype.doStepPreEventsContext.GDObjectObjects1, gdjs.evtsExt__PixelPerfectMovement__PixelPerfectPlatformerCharacter.PixelPerfectPlatformerCharacter.prototype.doStepPreEventsContext.GDObjectObjects2);


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.evtsExt__PixelPerfectMovement__PixelPerfectPlatformerCharacter.PixelPerfectPlatformerCharacter.prototype.doStepPreEventsContext.GDObjectObjects2.length;i<l;++i) {
    if ( gdjs.evtsExt__PixelPerfectMovement__PixelPerfectPlatformerCharacter.PixelPerfectPlatformerCharacter.prototype.doStepPreEventsContext.GDObjectObjects2[i].getBehavior(eventsFunctionContext.getBehaviorName("PlatformerCharacter")).getCurrentSpeed() < 0 ) {
        isConditionTrue_0 = true;
        gdjs.evtsExt__PixelPerfectMovement__PixelPerfectPlatformerCharacter.PixelPerfectPlatformerCharacter.prototype.doStepPreEventsContext.GDObjectObjects2[k] = gdjs.evtsExt__PixelPerfectMovement__PixelPerfectPlatformerCharacter.PixelPerfectPlatformerCharacter.prototype.doStepPreEventsContext.GDObjectObjects2[i];
        ++k;
    }
}
gdjs.evtsExt__PixelPerfectMovement__PixelPerfectPlatformerCharacter.PixelPerfectPlatformerCharacter.prototype.doStepPreEventsContext.GDObjectObjects2.length = k;
if (isConditionTrue_0) {
/* Reuse gdjs.evtsExt__PixelPerfectMovement__PixelPerfectPlatformerCharacter.PixelPerfectPlatformerCharacter.prototype.doStepPreEventsContext.GDObjectObjects2 */
{eventsFunctionContext.getObjects("Object")[0].getBehavior(eventsFunctionContext.getBehaviorName("Behavior"))._setTargetX(eventsFunctionContext.getObjects("Object")[0].getBehavior(eventsFunctionContext.getBehaviorName("Behavior"))._getOffsetX() + eventsFunctionContext.getObjects("Object")[0].getBehavior(eventsFunctionContext.getBehaviorName("Behavior"))._getPixelSize() * Math.floor(((( gdjs.evtsExt__PixelPerfectMovement__PixelPerfectPlatformerCharacter.PixelPerfectPlatformerCharacter.prototype.doStepPreEventsContext.GDObjectObjects2.length === 0 ) ? 0 :gdjs.evtsExt__PixelPerfectMovement__PixelPerfectPlatformerCharacter.PixelPerfectPlatformerCharacter.prototype.doStepPreEventsContext.GDObjectObjects2[0].getX()) - gdjs.evtsExt__PixelPerfectMovement__BrakingDistance.func(runtimeScene, (( gdjs.evtsExt__PixelPerfectMovement__PixelPerfectPlatformerCharacter.PixelPerfectPlatformerCharacter.prototype.doStepPreEventsContext.GDObjectObjects2.length === 0 ) ? 0 :gdjs.evtsExt__PixelPerfectMovement__PixelPerfectPlatformerCharacter.PixelPerfectPlatformerCharacter.prototype.doStepPreEventsContext.GDObjectObjects2[0].getBehavior(eventsFunctionContext.getBehaviorName("PlatformerCharacter")).getCurrentSpeed()), (( gdjs.evtsExt__PixelPerfectMovement__PixelPerfectPlatformerCharacter.PixelPerfectPlatformerCharacter.prototype.doStepPreEventsContext.GDObjectObjects2.length === 0 ) ? 0 :gdjs.evtsExt__PixelPerfectMovement__PixelPerfectPlatformerCharacter.PixelPerfectPlatformerCharacter.prototype.doStepPreEventsContext.GDObjectObjects2[0].getBehavior(eventsFunctionContext.getBehaviorName("PlatformerCharacter")).getDeceleration()), eventsFunctionContext) - eventsFunctionContext.getObjects("Object")[0].getBehavior(eventsFunctionContext.getBehaviorName("Behavior"))._getOffsetX()) / eventsFunctionContext.getObjects("Object")[0].getBehavior(eventsFunctionContext.getBehaviorName("Behavior"))._getPixelSize()))
}
{eventsFunctionContext.getObjects("Object")[0].getBehavior(eventsFunctionContext.getBehaviorName("Behavior"))._setTargetDirectionX(-1)
}

{ //Subevents
gdjs.evtsExt__PixelPerfectMovement__PixelPerfectPlatformerCharacter.PixelPerfectPlatformerCharacter.prototype.doStepPreEventsContext.eventsList1(runtimeScene, eventsFunctionContext);} //End of subevents
}

}


};gdjs.evtsExt__PixelPerfectMovement__PixelPerfectPlatformerCharacter.PixelPerfectPlatformerCharacter.prototype.doStepPreEventsContext.eventsList3 = function(runtimeScene, eventsFunctionContext) {

};gdjs.evtsExt__PixelPerfectMovement__PixelPerfectPlatformerCharacter.PixelPerfectPlatformerCharacter.prototype.doStepPreEventsContext.eventsList4 = function(runtimeScene, eventsFunctionContext) {

{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
{isConditionTrue_0 = eventsFunctionContext.getOnceTriggers().triggerOnce(31704620);
}
if (isConditionTrue_0) {

{ //Subevents
gdjs.evtsExt__PixelPerfectMovement__PixelPerfectPlatformerCharacter.PixelPerfectPlatformerCharacter.prototype.doStepPreEventsContext.eventsList2(runtimeScene, eventsFunctionContext);} //End of subevents
}

}


{

gdjs.copyArray(gdjs.evtsExt__PixelPerfectMovement__PixelPerfectPlatformerCharacter.PixelPerfectPlatformerCharacter.prototype.doStepPreEventsContext.GDObjectObjects1, gdjs.evtsExt__PixelPerfectMovement__PixelPerfectPlatformerCharacter.PixelPerfectPlatformerCharacter.prototype.doStepPreEventsContext.GDObjectObjects2);


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.evtsExt__PixelPerfectMovement__PixelPerfectPlatformerCharacter.PixelPerfectPlatformerCharacter.prototype.doStepPreEventsContext.GDObjectObjects2.length;i<l;++i) {
    if ( gdjs.evtsExt__PixelPerfectMovement__PixelPerfectPlatformerCharacter.PixelPerfectPlatformerCharacter.prototype.doStepPreEventsContext.GDObjectObjects2[i].getX() < eventsFunctionContext.getObjects("Object")[0].getBehavior(eventsFunctionContext.getBehaviorName("Behavior"))._getTargetX() ) {
        isConditionTrue_0 = true;
        gdjs.evtsExt__PixelPerfectMovement__PixelPerfectPlatformerCharacter.PixelPerfectPlatformerCharacter.prototype.doStepPreEventsContext.GDObjectObjects2[k] = gdjs.evtsExt__PixelPerfectMovement__PixelPerfectPlatformerCharacter.PixelPerfectPlatformerCharacter.prototype.doStepPreEventsContext.GDObjectObjects2[i];
        ++k;
    }
}
gdjs.evtsExt__PixelPerfectMovement__PixelPerfectPlatformerCharacter.PixelPerfectPlatformerCharacter.prototype.doStepPreEventsContext.GDObjectObjects2.length = k;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{isConditionTrue_0 = (eventsFunctionContext.getObjects("Object")[0].getBehavior(eventsFunctionContext.getBehaviorName("Behavior"))._getTargetDirectionX() == 1);
}
}
if (isConditionTrue_0) {
/* Reuse gdjs.evtsExt__PixelPerfectMovement__PixelPerfectPlatformerCharacter.PixelPerfectPlatformerCharacter.prototype.doStepPreEventsContext.GDObjectObjects2 */
{for(var i = 0, len = gdjs.evtsExt__PixelPerfectMovement__PixelPerfectPlatformerCharacter.PixelPerfectPlatformerCharacter.prototype.doStepPreEventsContext.GDObjectObjects2.length ;i < len;++i) {
    gdjs.evtsExt__PixelPerfectMovement__PixelPerfectPlatformerCharacter.PixelPerfectPlatformerCharacter.prototype.doStepPreEventsContext.GDObjectObjects2[i].getBehavior(eventsFunctionContext.getBehaviorName("PlatformerCharacter")).setCurrentSpeed(Math.min((gdjs.evtsExt__PixelPerfectMovement__PixelPerfectPlatformerCharacter.PixelPerfectPlatformerCharacter.prototype.doStepPreEventsContext.GDObjectObjects2[i].getBehavior(eventsFunctionContext.getBehaviorName("PlatformerCharacter")).getCurrentSpeed()) + (gdjs.evtsExt__PixelPerfectMovement__PixelPerfectPlatformerCharacter.PixelPerfectPlatformerCharacter.prototype.doStepPreEventsContext.GDObjectObjects2[i].getBehavior(eventsFunctionContext.getBehaviorName("PlatformerCharacter")).getAcceleration()), Math.min((gdjs.evtsExt__PixelPerfectMovement__PixelPerfectPlatformerCharacter.PixelPerfectPlatformerCharacter.prototype.doStepPreEventsContext.GDObjectObjects2[i].getBehavior(eventsFunctionContext.getBehaviorName("PlatformerCharacter")).getMaxSpeed()), gdjs.evtsExt__PixelPerfectMovement__SpeedToReach.func(runtimeScene, eventsFunctionContext.getObjects("Object")[0].getBehavior(eventsFunctionContext.getBehaviorName("Behavior"))._getTargetX() - (gdjs.evtsExt__PixelPerfectMovement__PixelPerfectPlatformerCharacter.PixelPerfectPlatformerCharacter.prototype.doStepPreEventsContext.GDObjectObjects2[i].getX()), (gdjs.evtsExt__PixelPerfectMovement__PixelPerfectPlatformerCharacter.PixelPerfectPlatformerCharacter.prototype.doStepPreEventsContext.GDObjectObjects2[i].getBehavior(eventsFunctionContext.getBehaviorName("PlatformerCharacter")).getDeceleration()), eventsFunctionContext))));
}
}
}

}


{

gdjs.copyArray(gdjs.evtsExt__PixelPerfectMovement__PixelPerfectPlatformerCharacter.PixelPerfectPlatformerCharacter.prototype.doStepPreEventsContext.GDObjectObjects1, gdjs.evtsExt__PixelPerfectMovement__PixelPerfectPlatformerCharacter.PixelPerfectPlatformerCharacter.prototype.doStepPreEventsContext.GDObjectObjects2);


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.evtsExt__PixelPerfectMovement__PixelPerfectPlatformerCharacter.PixelPerfectPlatformerCharacter.prototype.doStepPreEventsContext.GDObjectObjects2.length;i<l;++i) {
    if ( gdjs.evtsExt__PixelPerfectMovement__PixelPerfectPlatformerCharacter.PixelPerfectPlatformerCharacter.prototype.doStepPreEventsContext.GDObjectObjects2[i].getX() > eventsFunctionContext.getObjects("Object")[0].getBehavior(eventsFunctionContext.getBehaviorName("Behavior"))._getTargetX() ) {
        isConditionTrue_0 = true;
        gdjs.evtsExt__PixelPerfectMovement__PixelPerfectPlatformerCharacter.PixelPerfectPlatformerCharacter.prototype.doStepPreEventsContext.GDObjectObjects2[k] = gdjs.evtsExt__PixelPerfectMovement__PixelPerfectPlatformerCharacter.PixelPerfectPlatformerCharacter.prototype.doStepPreEventsContext.GDObjectObjects2[i];
        ++k;
    }
}
gdjs.evtsExt__PixelPerfectMovement__PixelPerfectPlatformerCharacter.PixelPerfectPlatformerCharacter.prototype.doStepPreEventsContext.GDObjectObjects2.length = k;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{isConditionTrue_0 = (eventsFunctionContext.getObjects("Object")[0].getBehavior(eventsFunctionContext.getBehaviorName("Behavior"))._getTargetDirectionX() == -1);
}
}
if (isConditionTrue_0) {
/* Reuse gdjs.evtsExt__PixelPerfectMovement__PixelPerfectPlatformerCharacter.PixelPerfectPlatformerCharacter.prototype.doStepPreEventsContext.GDObjectObjects2 */
{for(var i = 0, len = gdjs.evtsExt__PixelPerfectMovement__PixelPerfectPlatformerCharacter.PixelPerfectPlatformerCharacter.prototype.doStepPreEventsContext.GDObjectObjects2.length ;i < len;++i) {
    gdjs.evtsExt__PixelPerfectMovement__PixelPerfectPlatformerCharacter.PixelPerfectPlatformerCharacter.prototype.doStepPreEventsContext.GDObjectObjects2[i].getBehavior(eventsFunctionContext.getBehaviorName("PlatformerCharacter")).setCurrentSpeed(Math.max((gdjs.evtsExt__PixelPerfectMovement__PixelPerfectPlatformerCharacter.PixelPerfectPlatformerCharacter.prototype.doStepPreEventsContext.GDObjectObjects2[i].getBehavior(eventsFunctionContext.getBehaviorName("PlatformerCharacter")).getCurrentSpeed()) - (gdjs.evtsExt__PixelPerfectMovement__PixelPerfectPlatformerCharacter.PixelPerfectPlatformerCharacter.prototype.doStepPreEventsContext.GDObjectObjects2[i].getBehavior(eventsFunctionContext.getBehaviorName("PlatformerCharacter")).getAcceleration()), Math.max(-((gdjs.evtsExt__PixelPerfectMovement__PixelPerfectPlatformerCharacter.PixelPerfectPlatformerCharacter.prototype.doStepPreEventsContext.GDObjectObjects2[i].getBehavior(eventsFunctionContext.getBehaviorName("PlatformerCharacter")).getMaxSpeed())), gdjs.evtsExt__PixelPerfectMovement__SpeedToReach.func(runtimeScene, eventsFunctionContext.getObjects("Object")[0].getBehavior(eventsFunctionContext.getBehaviorName("Behavior"))._getTargetX() - (gdjs.evtsExt__PixelPerfectMovement__PixelPerfectPlatformerCharacter.PixelPerfectPlatformerCharacter.prototype.doStepPreEventsContext.GDObjectObjects2[i].getX()), (gdjs.evtsExt__PixelPerfectMovement__PixelPerfectPlatformerCharacter.PixelPerfectPlatformerCharacter.prototype.doStepPreEventsContext.GDObjectObjects2[i].getBehavior(eventsFunctionContext.getBehaviorName("PlatformerCharacter")).getDeceleration()), eventsFunctionContext))));
}
}
}

}


{

/* Reuse gdjs.evtsExt__PixelPerfectMovement__PixelPerfectPlatformerCharacter.PixelPerfectPlatformerCharacter.prototype.doStepPreEventsContext.GDObjectObjects1 */

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
{gdjs.evtsExt__PixelPerfectMovement__PixelPerfectPlatformerCharacter.PixelPerfectPlatformerCharacter.prototype.doStepPreEventsContext.GDObjectObjects1_1final.length = 0;
let isConditionTrue_1 = false;
isConditionTrue_0 = false;
{
gdjs.copyArray(gdjs.evtsExt__PixelPerfectMovement__PixelPerfectPlatformerCharacter.PixelPerfectPlatformerCharacter.prototype.doStepPreEventsContext.GDObjectObjects1, gdjs.evtsExt__PixelPerfectMovement__PixelPerfectPlatformerCharacter.PixelPerfectPlatformerCharacter.prototype.doStepPreEventsContext.GDObjectObjects2);

{let isConditionTrue_2 = false;
isConditionTrue_2 = false;
for (var i = 0, k = 0, l = gdjs.evtsExt__PixelPerfectMovement__PixelPerfectPlatformerCharacter.PixelPerfectPlatformerCharacter.prototype.doStepPreEventsContext.GDObjectObjects2.length;i<l;++i) {
    if ( gdjs.evtsExt__PixelPerfectMovement__PixelPerfectPlatformerCharacter.PixelPerfectPlatformerCharacter.prototype.doStepPreEventsContext.GDObjectObjects2[i].getX() >= eventsFunctionContext.getObjects("Object")[0].getBehavior(eventsFunctionContext.getBehaviorName("Behavior"))._getTargetX() ) {
        isConditionTrue_2 = true;
        gdjs.evtsExt__PixelPerfectMovement__PixelPerfectPlatformerCharacter.PixelPerfectPlatformerCharacter.prototype.doStepPreEventsContext.GDObjectObjects2[k] = gdjs.evtsExt__PixelPerfectMovement__PixelPerfectPlatformerCharacter.PixelPerfectPlatformerCharacter.prototype.doStepPreEventsContext.GDObjectObjects2[i];
        ++k;
    }
}
gdjs.evtsExt__PixelPerfectMovement__PixelPerfectPlatformerCharacter.PixelPerfectPlatformerCharacter.prototype.doStepPreEventsContext.GDObjectObjects2.length = k;
if (isConditionTrue_2) {
isConditionTrue_2 = false;
{isConditionTrue_2 = (eventsFunctionContext.getObjects("Object")[0].getBehavior(eventsFunctionContext.getBehaviorName("Behavior"))._getTargetDirectionX() == 1);
}
}
isConditionTrue_1 = isConditionTrue_2;
}
if(isConditionTrue_1) {
    isConditionTrue_0 = true;
    for (let j = 0, jLen = gdjs.evtsExt__PixelPerfectMovement__PixelPerfectPlatformerCharacter.PixelPerfectPlatformerCharacter.prototype.doStepPreEventsContext.GDObjectObjects2.length; j < jLen ; ++j) {
        if ( gdjs.evtsExt__PixelPerfectMovement__PixelPerfectPlatformerCharacter.PixelPerfectPlatformerCharacter.prototype.doStepPreEventsContext.GDObjectObjects1_1final.indexOf(gdjs.evtsExt__PixelPerfectMovement__PixelPerfectPlatformerCharacter.PixelPerfectPlatformerCharacter.prototype.doStepPreEventsContext.GDObjectObjects2[j]) === -1 )
            gdjs.evtsExt__PixelPerfectMovement__PixelPerfectPlatformerCharacter.PixelPerfectPlatformerCharacter.prototype.doStepPreEventsContext.GDObjectObjects1_1final.push(gdjs.evtsExt__PixelPerfectMovement__PixelPerfectPlatformerCharacter.PixelPerfectPlatformerCharacter.prototype.doStepPreEventsContext.GDObjectObjects2[j]);
    }
}
}
{
gdjs.copyArray(gdjs.evtsExt__PixelPerfectMovement__PixelPerfectPlatformerCharacter.PixelPerfectPlatformerCharacter.prototype.doStepPreEventsContext.GDObjectObjects1, gdjs.evtsExt__PixelPerfectMovement__PixelPerfectPlatformerCharacter.PixelPerfectPlatformerCharacter.prototype.doStepPreEventsContext.GDObjectObjects2);

{let isConditionTrue_2 = false;
isConditionTrue_2 = false;
for (var i = 0, k = 0, l = gdjs.evtsExt__PixelPerfectMovement__PixelPerfectPlatformerCharacter.PixelPerfectPlatformerCharacter.prototype.doStepPreEventsContext.GDObjectObjects2.length;i<l;++i) {
    if ( gdjs.evtsExt__PixelPerfectMovement__PixelPerfectPlatformerCharacter.PixelPerfectPlatformerCharacter.prototype.doStepPreEventsContext.GDObjectObjects2[i].getX() <= eventsFunctionContext.getObjects("Object")[0].getBehavior(eventsFunctionContext.getBehaviorName("Behavior"))._getTargetX() ) {
        isConditionTrue_2 = true;
        gdjs.evtsExt__PixelPerfectMovement__PixelPerfectPlatformerCharacter.PixelPerfectPlatformerCharacter.prototype.doStepPreEventsContext.GDObjectObjects2[k] = gdjs.evtsExt__PixelPerfectMovement__PixelPerfectPlatformerCharacter.PixelPerfectPlatformerCharacter.prototype.doStepPreEventsContext.GDObjectObjects2[i];
        ++k;
    }
}
gdjs.evtsExt__PixelPerfectMovement__PixelPerfectPlatformerCharacter.PixelPerfectPlatformerCharacter.prototype.doStepPreEventsContext.GDObjectObjects2.length = k;
if (isConditionTrue_2) {
isConditionTrue_2 = false;
{isConditionTrue_2 = (eventsFunctionContext.getObjects("Object")[0].getBehavior(eventsFunctionContext.getBehaviorName("Behavior"))._getTargetDirectionX() == -1);
}
}
isConditionTrue_1 = isConditionTrue_2;
}
if(isConditionTrue_1) {
    isConditionTrue_0 = true;
    for (let j = 0, jLen = gdjs.evtsExt__PixelPerfectMovement__PixelPerfectPlatformerCharacter.PixelPerfectPlatformerCharacter.prototype.doStepPreEventsContext.GDObjectObjects2.length; j < jLen ; ++j) {
        if ( gdjs.evtsExt__PixelPerfectMovement__PixelPerfectPlatformerCharacter.PixelPerfectPlatformerCharacter.prototype.doStepPreEventsContext.GDObjectObjects1_1final.indexOf(gdjs.evtsExt__PixelPerfectMovement__PixelPerfectPlatformerCharacter.PixelPerfectPlatformerCharacter.prototype.doStepPreEventsContext.GDObjectObjects2[j]) === -1 )
            gdjs.evtsExt__PixelPerfectMovement__PixelPerfectPlatformerCharacter.PixelPerfectPlatformerCharacter.prototype.doStepPreEventsContext.GDObjectObjects1_1final.push(gdjs.evtsExt__PixelPerfectMovement__PixelPerfectPlatformerCharacter.PixelPerfectPlatformerCharacter.prototype.doStepPreEventsContext.GDObjectObjects2[j]);
    }
}
}
{
gdjs.copyArray(gdjs.evtsExt__PixelPerfectMovement__PixelPerfectPlatformerCharacter.PixelPerfectPlatformerCharacter.prototype.doStepPreEventsContext.GDObjectObjects1_1final, gdjs.evtsExt__PixelPerfectMovement__PixelPerfectPlatformerCharacter.PixelPerfectPlatformerCharacter.prototype.doStepPreEventsContext.GDObjectObjects1);
}
}
if (isConditionTrue_0) {
/* Reuse gdjs.evtsExt__PixelPerfectMovement__PixelPerfectPlatformerCharacter.PixelPerfectPlatformerCharacter.prototype.doStepPreEventsContext.GDObjectObjects1 */
{for(var i = 0, len = gdjs.evtsExt__PixelPerfectMovement__PixelPerfectPlatformerCharacter.PixelPerfectPlatformerCharacter.prototype.doStepPreEventsContext.GDObjectObjects1.length ;i < len;++i) {
    gdjs.evtsExt__PixelPerfectMovement__PixelPerfectPlatformerCharacter.PixelPerfectPlatformerCharacter.prototype.doStepPreEventsContext.GDObjectObjects1[i].setX(eventsFunctionContext.getObjects("Object")[0].getBehavior(eventsFunctionContext.getBehaviorName("Behavior"))._getOffsetX() + eventsFunctionContext.getObjects("Object")[0].getBehavior(eventsFunctionContext.getBehaviorName("Behavior"))._getPixelSize() * Math.round(((gdjs.evtsExt__PixelPerfectMovement__PixelPerfectPlatformerCharacter.PixelPerfectPlatformerCharacter.prototype.doStepPreEventsContext.GDObjectObjects1[i].getX()) - eventsFunctionContext.getObjects("Object")[0].getBehavior(eventsFunctionContext.getBehaviorName("Behavior"))._getOffsetX()) / eventsFunctionContext.getObjects("Object")[0].getBehavior(eventsFunctionContext.getBehaviorName("Behavior"))._getPixelSize()));
}
}
{eventsFunctionContext.getObjects("Object")[0].getBehavior(eventsFunctionContext.getBehaviorName("Behavior"))._setTargetDirectionX(0)
}
{for(var i = 0, len = gdjs.evtsExt__PixelPerfectMovement__PixelPerfectPlatformerCharacter.PixelPerfectPlatformerCharacter.prototype.doStepPreEventsContext.GDObjectObjects1.length ;i < len;++i) {
    gdjs.evtsExt__PixelPerfectMovement__PixelPerfectPlatformerCharacter.PixelPerfectPlatformerCharacter.prototype.doStepPreEventsContext.GDObjectObjects1[i].getBehavior(eventsFunctionContext.getBehaviorName("PlatformerCharacter")).setCurrentSpeed(0);
}
}

{ //Subevents
gdjs.evtsExt__PixelPerfectMovement__PixelPerfectPlatformerCharacter.PixelPerfectPlatformerCharacter.prototype.doStepPreEventsContext.eventsList3(runtimeScene, eventsFunctionContext);} //End of subevents
}

}


};gdjs.evtsExt__PixelPerfectMovement__PixelPerfectPlatformerCharacter.PixelPerfectPlatformerCharacter.prototype.doStepPreEventsContext.eventsList5 = function(runtimeScene, eventsFunctionContext) {

{

gdjs.copyArray(eventsFunctionContext.getObjects("Object"), gdjs.evtsExt__PixelPerfectMovement__PixelPerfectPlatformerCharacter.PixelPerfectPlatformerCharacter.prototype.doStepPreEventsContext.GDObjectObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
{isConditionTrue_0 = eventsFunctionContext.getObjects("Object")[0].getBehavior(eventsFunctionContext.getBehaviorName("Behavior"))._getIsDecelerating();
}
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{isConditionTrue_0 = (Math.abs((( gdjs.evtsExt__PixelPerfectMovement__PixelPerfectPlatformerCharacter.PixelPerfectPlatformerCharacter.prototype.doStepPreEventsContext.GDObjectObjects1.length === 0 ) ? 0 :gdjs.evtsExt__PixelPerfectMovement__PixelPerfectPlatformerCharacter.PixelPerfectPlatformerCharacter.prototype.doStepPreEventsContext.GDObjectObjects1[0].getBehavior(eventsFunctionContext.getBehaviorName("PlatformerCharacter")).getCurrentSpeed()) - eventsFunctionContext.getObjects("Object")[0].getBehavior(eventsFunctionContext.getBehaviorName("Behavior"))._getPreviousSpeedX()) < (( gdjs.evtsExt__PixelPerfectMovement__PixelPerfectPlatformerCharacter.PixelPerfectPlatformerCharacter.prototype.doStepPreEventsContext.GDObjectObjects1.length === 0 ) ? 0 :gdjs.evtsExt__PixelPerfectMovement__PixelPerfectPlatformerCharacter.PixelPerfectPlatformerCharacter.prototype.doStepPreEventsContext.GDObjectObjects1[0].getBehavior(eventsFunctionContext.getBehaviorName("PlatformerCharacter")).getCurrentSpeed()) * 0.01 + (( gdjs.evtsExt__PixelPerfectMovement__PixelPerfectPlatformerCharacter.PixelPerfectPlatformerCharacter.prototype.doStepPreEventsContext.GDObjectObjects1.length === 0 ) ? 0 :gdjs.evtsExt__PixelPerfectMovement__PixelPerfectPlatformerCharacter.PixelPerfectPlatformerCharacter.prototype.doStepPreEventsContext.GDObjectObjects1[0].getBehavior(eventsFunctionContext.getBehaviorName("PlatformerCharacter")).getDeceleration()) * gdjs.evtTools.runtimeScene.getElapsedTimeInSeconds(runtimeScene));
}
}
if (isConditionTrue_0) {

{ //Subevents
gdjs.evtsExt__PixelPerfectMovement__PixelPerfectPlatformerCharacter.PixelPerfectPlatformerCharacter.prototype.doStepPreEventsContext.eventsList4(runtimeScene, eventsFunctionContext);} //End of subevents
}

}


};gdjs.evtsExt__PixelPerfectMovement__PixelPerfectPlatformerCharacter.PixelPerfectPlatformerCharacter.prototype.doStepPreEventsContext.eventsList6 = function(runtimeScene, eventsFunctionContext) {

};gdjs.evtsExt__PixelPerfectMovement__PixelPerfectPlatformerCharacter.PixelPerfectPlatformerCharacter.prototype.doStepPreEventsContext.eventsList7 = function(runtimeScene, eventsFunctionContext) {

{

/* Reuse gdjs.evtsExt__PixelPerfectMovement__PixelPerfectPlatformerCharacter.PixelPerfectPlatformerCharacter.prototype.doStepPreEventsContext.GDObjectObjects2 */

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.evtsExt__PixelPerfectMovement__PixelPerfectPlatformerCharacter.PixelPerfectPlatformerCharacter.prototype.doStepPreEventsContext.GDObjectObjects2.length;i<l;++i) {
    if ( !(gdjs.evtsExt__PixelPerfectMovement__PixelPerfectPlatformerCharacter.PixelPerfectPlatformerCharacter.prototype.doStepPreEventsContext.GDObjectObjects2[i].getBehavior(eventsFunctionContext.getBehaviorName("PlatformerCharacter")).isUsingControl("Up")) ) {
        isConditionTrue_0 = true;
        gdjs.evtsExt__PixelPerfectMovement__PixelPerfectPlatformerCharacter.PixelPerfectPlatformerCharacter.prototype.doStepPreEventsContext.GDObjectObjects2[k] = gdjs.evtsExt__PixelPerfectMovement__PixelPerfectPlatformerCharacter.PixelPerfectPlatformerCharacter.prototype.doStepPreEventsContext.GDObjectObjects2[i];
        ++k;
    }
}
gdjs.evtsExt__PixelPerfectMovement__PixelPerfectPlatformerCharacter.PixelPerfectPlatformerCharacter.prototype.doStepPreEventsContext.GDObjectObjects2.length = k;
if (isConditionTrue_0) {
/* Reuse gdjs.evtsExt__PixelPerfectMovement__PixelPerfectPlatformerCharacter.PixelPerfectPlatformerCharacter.prototype.doStepPreEventsContext.GDObjectObjects2 */
{eventsFunctionContext.getObjects("Object")[0].getBehavior(eventsFunctionContext.getBehaviorName("Behavior"))._setTargetY(eventsFunctionContext.getObjects("Object")[0].getBehavior(eventsFunctionContext.getBehaviorName("Behavior"))._getOffsetY() + eventsFunctionContext.getObjects("Object")[0].getBehavior(eventsFunctionContext.getBehaviorName("Behavior"))._getPixelSize() * Math.ceil(((( gdjs.evtsExt__PixelPerfectMovement__PixelPerfectPlatformerCharacter.PixelPerfectPlatformerCharacter.prototype.doStepPreEventsContext.GDObjectObjects2.length === 0 ) ? 0 :gdjs.evtsExt__PixelPerfectMovement__PixelPerfectPlatformerCharacter.PixelPerfectPlatformerCharacter.prototype.doStepPreEventsContext.GDObjectObjects2[0].getY()) - eventsFunctionContext.getObjects("Object")[0].getBehavior(eventsFunctionContext.getBehaviorName("Behavior"))._getOffsetY()) / eventsFunctionContext.getObjects("Object")[0].getBehavior(eventsFunctionContext.getBehaviorName("Behavior"))._getPixelSize()))
}
{eventsFunctionContext.getObjects("Object")[0].getBehavior(eventsFunctionContext.getBehaviorName("Behavior"))._setTargetDirectionY(1)
}

{ //Subevents
gdjs.evtsExt__PixelPerfectMovement__PixelPerfectPlatformerCharacter.PixelPerfectPlatformerCharacter.prototype.doStepPreEventsContext.eventsList6(runtimeScene, eventsFunctionContext);} //End of subevents
}

}


};gdjs.evtsExt__PixelPerfectMovement__PixelPerfectPlatformerCharacter.PixelPerfectPlatformerCharacter.prototype.doStepPreEventsContext.eventsList8 = function(runtimeScene, eventsFunctionContext) {

};gdjs.evtsExt__PixelPerfectMovement__PixelPerfectPlatformerCharacter.PixelPerfectPlatformerCharacter.prototype.doStepPreEventsContext.eventsList9 = function(runtimeScene, eventsFunctionContext) {

{

/* Reuse gdjs.evtsExt__PixelPerfectMovement__PixelPerfectPlatformerCharacter.PixelPerfectPlatformerCharacter.prototype.doStepPreEventsContext.GDObjectObjects2 */

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.evtsExt__PixelPerfectMovement__PixelPerfectPlatformerCharacter.PixelPerfectPlatformerCharacter.prototype.doStepPreEventsContext.GDObjectObjects2.length;i<l;++i) {
    if ( !(gdjs.evtsExt__PixelPerfectMovement__PixelPerfectPlatformerCharacter.PixelPerfectPlatformerCharacter.prototype.doStepPreEventsContext.GDObjectObjects2[i].getBehavior(eventsFunctionContext.getBehaviorName("PlatformerCharacter")).isUsingControl("Down")) ) {
        isConditionTrue_0 = true;
        gdjs.evtsExt__PixelPerfectMovement__PixelPerfectPlatformerCharacter.PixelPerfectPlatformerCharacter.prototype.doStepPreEventsContext.GDObjectObjects2[k] = gdjs.evtsExt__PixelPerfectMovement__PixelPerfectPlatformerCharacter.PixelPerfectPlatformerCharacter.prototype.doStepPreEventsContext.GDObjectObjects2[i];
        ++k;
    }
}
gdjs.evtsExt__PixelPerfectMovement__PixelPerfectPlatformerCharacter.PixelPerfectPlatformerCharacter.prototype.doStepPreEventsContext.GDObjectObjects2.length = k;
if (isConditionTrue_0) {
/* Reuse gdjs.evtsExt__PixelPerfectMovement__PixelPerfectPlatformerCharacter.PixelPerfectPlatformerCharacter.prototype.doStepPreEventsContext.GDObjectObjects2 */
{eventsFunctionContext.getObjects("Object")[0].getBehavior(eventsFunctionContext.getBehaviorName("Behavior"))._setTargetY(eventsFunctionContext.getObjects("Object")[0].getBehavior(eventsFunctionContext.getBehaviorName("Behavior"))._getOffsetY() + eventsFunctionContext.getObjects("Object")[0].getBehavior(eventsFunctionContext.getBehaviorName("Behavior"))._getPixelSize() * Math.floor(((( gdjs.evtsExt__PixelPerfectMovement__PixelPerfectPlatformerCharacter.PixelPerfectPlatformerCharacter.prototype.doStepPreEventsContext.GDObjectObjects2.length === 0 ) ? 0 :gdjs.evtsExt__PixelPerfectMovement__PixelPerfectPlatformerCharacter.PixelPerfectPlatformerCharacter.prototype.doStepPreEventsContext.GDObjectObjects2[0].getY()) - eventsFunctionContext.getObjects("Object")[0].getBehavior(eventsFunctionContext.getBehaviorName("Behavior"))._getOffsetY()) / eventsFunctionContext.getObjects("Object")[0].getBehavior(eventsFunctionContext.getBehaviorName("Behavior"))._getPixelSize()))
}
{eventsFunctionContext.getObjects("Object")[0].getBehavior(eventsFunctionContext.getBehaviorName("Behavior"))._setTargetDirectionY(-1)
}

{ //Subevents
gdjs.evtsExt__PixelPerfectMovement__PixelPerfectPlatformerCharacter.PixelPerfectPlatformerCharacter.prototype.doStepPreEventsContext.eventsList8(runtimeScene, eventsFunctionContext);} //End of subevents
}

}


};gdjs.evtsExt__PixelPerfectMovement__PixelPerfectPlatformerCharacter.PixelPerfectPlatformerCharacter.prototype.doStepPreEventsContext.eventsList10 = function(runtimeScene, eventsFunctionContext) {

{

gdjs.copyArray(gdjs.evtsExt__PixelPerfectMovement__PixelPerfectPlatformerCharacter.PixelPerfectPlatformerCharacter.prototype.doStepPreEventsContext.GDObjectObjects1, gdjs.evtsExt__PixelPerfectMovement__PixelPerfectPlatformerCharacter.PixelPerfectPlatformerCharacter.prototype.doStepPreEventsContext.GDObjectObjects2);


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.evtsExt__PixelPerfectMovement__PixelPerfectPlatformerCharacter.PixelPerfectPlatformerCharacter.prototype.doStepPreEventsContext.GDObjectObjects2.length;i<l;++i) {
    if ( gdjs.evtsExt__PixelPerfectMovement__PixelPerfectPlatformerCharacter.PixelPerfectPlatformerCharacter.prototype.doStepPreEventsContext.GDObjectObjects2[i].getY() < eventsFunctionContext.getObjects("Object")[0].getBehavior(eventsFunctionContext.getBehaviorName("Behavior"))._getTargetY() ) {
        isConditionTrue_0 = true;
        gdjs.evtsExt__PixelPerfectMovement__PixelPerfectPlatformerCharacter.PixelPerfectPlatformerCharacter.prototype.doStepPreEventsContext.GDObjectObjects2[k] = gdjs.evtsExt__PixelPerfectMovement__PixelPerfectPlatformerCharacter.PixelPerfectPlatformerCharacter.prototype.doStepPreEventsContext.GDObjectObjects2[i];
        ++k;
    }
}
gdjs.evtsExt__PixelPerfectMovement__PixelPerfectPlatformerCharacter.PixelPerfectPlatformerCharacter.prototype.doStepPreEventsContext.GDObjectObjects2.length = k;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{isConditionTrue_0 = (eventsFunctionContext.getObjects("Object")[0].getBehavior(eventsFunctionContext.getBehaviorName("Behavior"))._getTargetDirectionY() == 1);
}
}
if (isConditionTrue_0) {
/* Reuse gdjs.evtsExt__PixelPerfectMovement__PixelPerfectPlatformerCharacter.PixelPerfectPlatformerCharacter.prototype.doStepPreEventsContext.GDObjectObjects2 */
{for(var i = 0, len = gdjs.evtsExt__PixelPerfectMovement__PixelPerfectPlatformerCharacter.PixelPerfectPlatformerCharacter.prototype.doStepPreEventsContext.GDObjectObjects2.length ;i < len;++i) {
    gdjs.evtsExt__PixelPerfectMovement__PixelPerfectPlatformerCharacter.PixelPerfectPlatformerCharacter.prototype.doStepPreEventsContext.GDObjectObjects2[i].setY(gdjs.evtsExt__PixelPerfectMovement__PixelPerfectPlatformerCharacter.PixelPerfectPlatformerCharacter.prototype.doStepPreEventsContext.GDObjectObjects2[i].getY() + ((gdjs.evtsExt__PixelPerfectMovement__PixelPerfectPlatformerCharacter.PixelPerfectPlatformerCharacter.prototype.doStepPreEventsContext.GDObjectObjects2[i].getBehavior(eventsFunctionContext.getBehaviorName("PlatformerCharacter")).getMaxSpeed()) * gdjs.evtTools.runtimeScene.getElapsedTimeInSeconds(runtimeScene)));
}
}
}

}


{

gdjs.copyArray(gdjs.evtsExt__PixelPerfectMovement__PixelPerfectPlatformerCharacter.PixelPerfectPlatformerCharacter.prototype.doStepPreEventsContext.GDObjectObjects1, gdjs.evtsExt__PixelPerfectMovement__PixelPerfectPlatformerCharacter.PixelPerfectPlatformerCharacter.prototype.doStepPreEventsContext.GDObjectObjects2);


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.evtsExt__PixelPerfectMovement__PixelPerfectPlatformerCharacter.PixelPerfectPlatformerCharacter.prototype.doStepPreEventsContext.GDObjectObjects2.length;i<l;++i) {
    if ( gdjs.evtsExt__PixelPerfectMovement__PixelPerfectPlatformerCharacter.PixelPerfectPlatformerCharacter.prototype.doStepPreEventsContext.GDObjectObjects2[i].getY() > eventsFunctionContext.getObjects("Object")[0].getBehavior(eventsFunctionContext.getBehaviorName("Behavior"))._getTargetY() ) {
        isConditionTrue_0 = true;
        gdjs.evtsExt__PixelPerfectMovement__PixelPerfectPlatformerCharacter.PixelPerfectPlatformerCharacter.prototype.doStepPreEventsContext.GDObjectObjects2[k] = gdjs.evtsExt__PixelPerfectMovement__PixelPerfectPlatformerCharacter.PixelPerfectPlatformerCharacter.prototype.doStepPreEventsContext.GDObjectObjects2[i];
        ++k;
    }
}
gdjs.evtsExt__PixelPerfectMovement__PixelPerfectPlatformerCharacter.PixelPerfectPlatformerCharacter.prototype.doStepPreEventsContext.GDObjectObjects2.length = k;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{isConditionTrue_0 = (eventsFunctionContext.getObjects("Object")[0].getBehavior(eventsFunctionContext.getBehaviorName("Behavior"))._getTargetDirectionY() == -1);
}
}
if (isConditionTrue_0) {
/* Reuse gdjs.evtsExt__PixelPerfectMovement__PixelPerfectPlatformerCharacter.PixelPerfectPlatformerCharacter.prototype.doStepPreEventsContext.GDObjectObjects2 */
{for(var i = 0, len = gdjs.evtsExt__PixelPerfectMovement__PixelPerfectPlatformerCharacter.PixelPerfectPlatformerCharacter.prototype.doStepPreEventsContext.GDObjectObjects2.length ;i < len;++i) {
    gdjs.evtsExt__PixelPerfectMovement__PixelPerfectPlatformerCharacter.PixelPerfectPlatformerCharacter.prototype.doStepPreEventsContext.GDObjectObjects2[i].setY(gdjs.evtsExt__PixelPerfectMovement__PixelPerfectPlatformerCharacter.PixelPerfectPlatformerCharacter.prototype.doStepPreEventsContext.GDObjectObjects2[i].getY() - ((gdjs.evtsExt__PixelPerfectMovement__PixelPerfectPlatformerCharacter.PixelPerfectPlatformerCharacter.prototype.doStepPreEventsContext.GDObjectObjects2[i].getBehavior(eventsFunctionContext.getBehaviorName("PlatformerCharacter")).getMaxSpeed()) * gdjs.evtTools.runtimeScene.getElapsedTimeInSeconds(runtimeScene)));
}
}
}

}


{

gdjs.copyArray(gdjs.evtsExt__PixelPerfectMovement__PixelPerfectPlatformerCharacter.PixelPerfectPlatformerCharacter.prototype.doStepPreEventsContext.GDObjectObjects1, gdjs.evtsExt__PixelPerfectMovement__PixelPerfectPlatformerCharacter.PixelPerfectPlatformerCharacter.prototype.doStepPreEventsContext.GDObjectObjects2);


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
{gdjs.evtsExt__PixelPerfectMovement__PixelPerfectPlatformerCharacter.PixelPerfectPlatformerCharacter.prototype.doStepPreEventsContext.GDObjectObjects2_1final.length = 0;
let isConditionTrue_1 = false;
isConditionTrue_0 = false;
{
gdjs.copyArray(gdjs.evtsExt__PixelPerfectMovement__PixelPerfectPlatformerCharacter.PixelPerfectPlatformerCharacter.prototype.doStepPreEventsContext.GDObjectObjects1, gdjs.evtsExt__PixelPerfectMovement__PixelPerfectPlatformerCharacter.PixelPerfectPlatformerCharacter.prototype.doStepPreEventsContext.GDObjectObjects3);

{let isConditionTrue_2 = false;
isConditionTrue_2 = false;
for (var i = 0, k = 0, l = gdjs.evtsExt__PixelPerfectMovement__PixelPerfectPlatformerCharacter.PixelPerfectPlatformerCharacter.prototype.doStepPreEventsContext.GDObjectObjects3.length;i<l;++i) {
    if ( gdjs.evtsExt__PixelPerfectMovement__PixelPerfectPlatformerCharacter.PixelPerfectPlatformerCharacter.prototype.doStepPreEventsContext.GDObjectObjects3[i].getY() >= eventsFunctionContext.getObjects("Object")[0].getBehavior(eventsFunctionContext.getBehaviorName("Behavior"))._getTargetY() ) {
        isConditionTrue_2 = true;
        gdjs.evtsExt__PixelPerfectMovement__PixelPerfectPlatformerCharacter.PixelPerfectPlatformerCharacter.prototype.doStepPreEventsContext.GDObjectObjects3[k] = gdjs.evtsExt__PixelPerfectMovement__PixelPerfectPlatformerCharacter.PixelPerfectPlatformerCharacter.prototype.doStepPreEventsContext.GDObjectObjects3[i];
        ++k;
    }
}
gdjs.evtsExt__PixelPerfectMovement__PixelPerfectPlatformerCharacter.PixelPerfectPlatformerCharacter.prototype.doStepPreEventsContext.GDObjectObjects3.length = k;
if (isConditionTrue_2) {
isConditionTrue_2 = false;
{isConditionTrue_2 = (eventsFunctionContext.getObjects("Object")[0].getBehavior(eventsFunctionContext.getBehaviorName("Behavior"))._getTargetDirectionY() == 1);
}
}
isConditionTrue_1 = isConditionTrue_2;
}
if(isConditionTrue_1) {
    isConditionTrue_0 = true;
    for (let j = 0, jLen = gdjs.evtsExt__PixelPerfectMovement__PixelPerfectPlatformerCharacter.PixelPerfectPlatformerCharacter.prototype.doStepPreEventsContext.GDObjectObjects3.length; j < jLen ; ++j) {
        if ( gdjs.evtsExt__PixelPerfectMovement__PixelPerfectPlatformerCharacter.PixelPerfectPlatformerCharacter.prototype.doStepPreEventsContext.GDObjectObjects2_1final.indexOf(gdjs.evtsExt__PixelPerfectMovement__PixelPerfectPlatformerCharacter.PixelPerfectPlatformerCharacter.prototype.doStepPreEventsContext.GDObjectObjects3[j]) === -1 )
            gdjs.evtsExt__PixelPerfectMovement__PixelPerfectPlatformerCharacter.PixelPerfectPlatformerCharacter.prototype.doStepPreEventsContext.GDObjectObjects2_1final.push(gdjs.evtsExt__PixelPerfectMovement__PixelPerfectPlatformerCharacter.PixelPerfectPlatformerCharacter.prototype.doStepPreEventsContext.GDObjectObjects3[j]);
    }
}
}
{
gdjs.copyArray(gdjs.evtsExt__PixelPerfectMovement__PixelPerfectPlatformerCharacter.PixelPerfectPlatformerCharacter.prototype.doStepPreEventsContext.GDObjectObjects1, gdjs.evtsExt__PixelPerfectMovement__PixelPerfectPlatformerCharacter.PixelPerfectPlatformerCharacter.prototype.doStepPreEventsContext.GDObjectObjects3);

{let isConditionTrue_2 = false;
isConditionTrue_2 = false;
for (var i = 0, k = 0, l = gdjs.evtsExt__PixelPerfectMovement__PixelPerfectPlatformerCharacter.PixelPerfectPlatformerCharacter.prototype.doStepPreEventsContext.GDObjectObjects3.length;i<l;++i) {
    if ( gdjs.evtsExt__PixelPerfectMovement__PixelPerfectPlatformerCharacter.PixelPerfectPlatformerCharacter.prototype.doStepPreEventsContext.GDObjectObjects3[i].getY() <= eventsFunctionContext.getObjects("Object")[0].getBehavior(eventsFunctionContext.getBehaviorName("Behavior"))._getTargetY() ) {
        isConditionTrue_2 = true;
        gdjs.evtsExt__PixelPerfectMovement__PixelPerfectPlatformerCharacter.PixelPerfectPlatformerCharacter.prototype.doStepPreEventsContext.GDObjectObjects3[k] = gdjs.evtsExt__PixelPerfectMovement__PixelPerfectPlatformerCharacter.PixelPerfectPlatformerCharacter.prototype.doStepPreEventsContext.GDObjectObjects3[i];
        ++k;
    }
}
gdjs.evtsExt__PixelPerfectMovement__PixelPerfectPlatformerCharacter.PixelPerfectPlatformerCharacter.prototype.doStepPreEventsContext.GDObjectObjects3.length = k;
if (isConditionTrue_2) {
isConditionTrue_2 = false;
{isConditionTrue_2 = (eventsFunctionContext.getObjects("Object")[0].getBehavior(eventsFunctionContext.getBehaviorName("Behavior"))._getTargetDirectionY() == -1);
}
}
isConditionTrue_1 = isConditionTrue_2;
}
if(isConditionTrue_1) {
    isConditionTrue_0 = true;
    for (let j = 0, jLen = gdjs.evtsExt__PixelPerfectMovement__PixelPerfectPlatformerCharacter.PixelPerfectPlatformerCharacter.prototype.doStepPreEventsContext.GDObjectObjects3.length; j < jLen ; ++j) {
        if ( gdjs.evtsExt__PixelPerfectMovement__PixelPerfectPlatformerCharacter.PixelPerfectPlatformerCharacter.prototype.doStepPreEventsContext.GDObjectObjects2_1final.indexOf(gdjs.evtsExt__PixelPerfectMovement__PixelPerfectPlatformerCharacter.PixelPerfectPlatformerCharacter.prototype.doStepPreEventsContext.GDObjectObjects3[j]) === -1 )
            gdjs.evtsExt__PixelPerfectMovement__PixelPerfectPlatformerCharacter.PixelPerfectPlatformerCharacter.prototype.doStepPreEventsContext.GDObjectObjects2_1final.push(gdjs.evtsExt__PixelPerfectMovement__PixelPerfectPlatformerCharacter.PixelPerfectPlatformerCharacter.prototype.doStepPreEventsContext.GDObjectObjects3[j]);
    }
}
}
{
gdjs.copyArray(gdjs.evtsExt__PixelPerfectMovement__PixelPerfectPlatformerCharacter.PixelPerfectPlatformerCharacter.prototype.doStepPreEventsContext.GDObjectObjects2_1final, gdjs.evtsExt__PixelPerfectMovement__PixelPerfectPlatformerCharacter.PixelPerfectPlatformerCharacter.prototype.doStepPreEventsContext.GDObjectObjects2);
}
}
if (isConditionTrue_0) {
/* Reuse gdjs.evtsExt__PixelPerfectMovement__PixelPerfectPlatformerCharacter.PixelPerfectPlatformerCharacter.prototype.doStepPreEventsContext.GDObjectObjects2 */
{for(var i = 0, len = gdjs.evtsExt__PixelPerfectMovement__PixelPerfectPlatformerCharacter.PixelPerfectPlatformerCharacter.prototype.doStepPreEventsContext.GDObjectObjects2.length ;i < len;++i) {
    gdjs.evtsExt__PixelPerfectMovement__PixelPerfectPlatformerCharacter.PixelPerfectPlatformerCharacter.prototype.doStepPreEventsContext.GDObjectObjects2[i].setY(eventsFunctionContext.getObjects("Object")[0].getBehavior(eventsFunctionContext.getBehaviorName("Behavior"))._getOffsetY() + eventsFunctionContext.getObjects("Object")[0].getBehavior(eventsFunctionContext.getBehaviorName("Behavior"))._getPixelSize() * Math.round(((gdjs.evtsExt__PixelPerfectMovement__PixelPerfectPlatformerCharacter.PixelPerfectPlatformerCharacter.prototype.doStepPreEventsContext.GDObjectObjects2[i].getY()) - eventsFunctionContext.getObjects("Object")[0].getBehavior(eventsFunctionContext.getBehaviorName("Behavior"))._getOffsetY()) / eventsFunctionContext.getObjects("Object")[0].getBehavior(eventsFunctionContext.getBehaviorName("Behavior"))._getPixelSize()));
}
}
{eventsFunctionContext.getObjects("Object")[0].getBehavior(eventsFunctionContext.getBehaviorName("Behavior"))._setTargetDirectionY(0)
}
}

}


};gdjs.evtsExt__PixelPerfectMovement__PixelPerfectPlatformerCharacter.PixelPerfectPlatformerCharacter.prototype.doStepPreEventsContext.eventsList11 = function(runtimeScene, eventsFunctionContext) {

{

gdjs.copyArray(gdjs.evtsExt__PixelPerfectMovement__PixelPerfectPlatformerCharacter.PixelPerfectPlatformerCharacter.prototype.doStepPreEventsContext.GDObjectObjects1, gdjs.evtsExt__PixelPerfectMovement__PixelPerfectPlatformerCharacter.PixelPerfectPlatformerCharacter.prototype.doStepPreEventsContext.GDObjectObjects2);


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.evtsExt__PixelPerfectMovement__PixelPerfectPlatformerCharacter.PixelPerfectPlatformerCharacter.prototype.doStepPreEventsContext.GDObjectObjects2.length;i<l;++i) {
    if ( !(gdjs.evtsExt__PixelPerfectMovement__PixelPerfectPlatformerCharacter.PixelPerfectPlatformerCharacter.prototype.doStepPreEventsContext.GDObjectObjects2[i].getBehavior(eventsFunctionContext.getBehaviorName("PlatformerCharacter")).isUsingControl("Down")) ) {
        isConditionTrue_0 = true;
        gdjs.evtsExt__PixelPerfectMovement__PixelPerfectPlatformerCharacter.PixelPerfectPlatformerCharacter.prototype.doStepPreEventsContext.GDObjectObjects2[k] = gdjs.evtsExt__PixelPerfectMovement__PixelPerfectPlatformerCharacter.PixelPerfectPlatformerCharacter.prototype.doStepPreEventsContext.GDObjectObjects2[i];
        ++k;
    }
}
gdjs.evtsExt__PixelPerfectMovement__PixelPerfectPlatformerCharacter.PixelPerfectPlatformerCharacter.prototype.doStepPreEventsContext.GDObjectObjects2.length = k;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{isConditionTrue_0 = eventsFunctionContext.getOnceTriggers().triggerOnce(31710212);
}
}
if (isConditionTrue_0) {

{ //Subevents
gdjs.evtsExt__PixelPerfectMovement__PixelPerfectPlatformerCharacter.PixelPerfectPlatformerCharacter.prototype.doStepPreEventsContext.eventsList7(runtimeScene, eventsFunctionContext);} //End of subevents
}

}


{

gdjs.copyArray(gdjs.evtsExt__PixelPerfectMovement__PixelPerfectPlatformerCharacter.PixelPerfectPlatformerCharacter.prototype.doStepPreEventsContext.GDObjectObjects1, gdjs.evtsExt__PixelPerfectMovement__PixelPerfectPlatformerCharacter.PixelPerfectPlatformerCharacter.prototype.doStepPreEventsContext.GDObjectObjects2);


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.evtsExt__PixelPerfectMovement__PixelPerfectPlatformerCharacter.PixelPerfectPlatformerCharacter.prototype.doStepPreEventsContext.GDObjectObjects2.length;i<l;++i) {
    if ( !(gdjs.evtsExt__PixelPerfectMovement__PixelPerfectPlatformerCharacter.PixelPerfectPlatformerCharacter.prototype.doStepPreEventsContext.GDObjectObjects2[i].getBehavior(eventsFunctionContext.getBehaviorName("PlatformerCharacter")).isUsingControl("Up")) ) {
        isConditionTrue_0 = true;
        gdjs.evtsExt__PixelPerfectMovement__PixelPerfectPlatformerCharacter.PixelPerfectPlatformerCharacter.prototype.doStepPreEventsContext.GDObjectObjects2[k] = gdjs.evtsExt__PixelPerfectMovement__PixelPerfectPlatformerCharacter.PixelPerfectPlatformerCharacter.prototype.doStepPreEventsContext.GDObjectObjects2[i];
        ++k;
    }
}
gdjs.evtsExt__PixelPerfectMovement__PixelPerfectPlatformerCharacter.PixelPerfectPlatformerCharacter.prototype.doStepPreEventsContext.GDObjectObjects2.length = k;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{isConditionTrue_0 = eventsFunctionContext.getOnceTriggers().triggerOnce(31714308);
}
}
if (isConditionTrue_0) {

{ //Subevents
gdjs.evtsExt__PixelPerfectMovement__PixelPerfectPlatformerCharacter.PixelPerfectPlatformerCharacter.prototype.doStepPreEventsContext.eventsList9(runtimeScene, eventsFunctionContext);} //End of subevents
}

}


{

/* Reuse gdjs.evtsExt__PixelPerfectMovement__PixelPerfectPlatformerCharacter.PixelPerfectPlatformerCharacter.prototype.doStepPreEventsContext.GDObjectObjects1 */

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.evtsExt__PixelPerfectMovement__PixelPerfectPlatformerCharacter.PixelPerfectPlatformerCharacter.prototype.doStepPreEventsContext.GDObjectObjects1.length;i<l;++i) {
    if ( !(gdjs.evtsExt__PixelPerfectMovement__PixelPerfectPlatformerCharacter.PixelPerfectPlatformerCharacter.prototype.doStepPreEventsContext.GDObjectObjects1[i].getBehavior(eventsFunctionContext.getBehaviorName("PlatformerCharacter")).isUsingControl("Up")) ) {
        isConditionTrue_0 = true;
        gdjs.evtsExt__PixelPerfectMovement__PixelPerfectPlatformerCharacter.PixelPerfectPlatformerCharacter.prototype.doStepPreEventsContext.GDObjectObjects1[k] = gdjs.evtsExt__PixelPerfectMovement__PixelPerfectPlatformerCharacter.PixelPerfectPlatformerCharacter.prototype.doStepPreEventsContext.GDObjectObjects1[i];
        ++k;
    }
}
gdjs.evtsExt__PixelPerfectMovement__PixelPerfectPlatformerCharacter.PixelPerfectPlatformerCharacter.prototype.doStepPreEventsContext.GDObjectObjects1.length = k;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.evtsExt__PixelPerfectMovement__PixelPerfectPlatformerCharacter.PixelPerfectPlatformerCharacter.prototype.doStepPreEventsContext.GDObjectObjects1.length;i<l;++i) {
    if ( !(gdjs.evtsExt__PixelPerfectMovement__PixelPerfectPlatformerCharacter.PixelPerfectPlatformerCharacter.prototype.doStepPreEventsContext.GDObjectObjects1[i].getBehavior(eventsFunctionContext.getBehaviorName("PlatformerCharacter")).isUsingControl("Down")) ) {
        isConditionTrue_0 = true;
        gdjs.evtsExt__PixelPerfectMovement__PixelPerfectPlatformerCharacter.PixelPerfectPlatformerCharacter.prototype.doStepPreEventsContext.GDObjectObjects1[k] = gdjs.evtsExt__PixelPerfectMovement__PixelPerfectPlatformerCharacter.PixelPerfectPlatformerCharacter.prototype.doStepPreEventsContext.GDObjectObjects1[i];
        ++k;
    }
}
gdjs.evtsExt__PixelPerfectMovement__PixelPerfectPlatformerCharacter.PixelPerfectPlatformerCharacter.prototype.doStepPreEventsContext.GDObjectObjects1.length = k;
}
if (isConditionTrue_0) {

{ //Subevents
gdjs.evtsExt__PixelPerfectMovement__PixelPerfectPlatformerCharacter.PixelPerfectPlatformerCharacter.prototype.doStepPreEventsContext.eventsList10(runtimeScene, eventsFunctionContext);} //End of subevents
}

}


};gdjs.evtsExt__PixelPerfectMovement__PixelPerfectPlatformerCharacter.PixelPerfectPlatformerCharacter.prototype.doStepPreEventsContext.eventsList12 = function(runtimeScene, eventsFunctionContext) {

{

gdjs.copyArray(eventsFunctionContext.getObjects("Object"), gdjs.evtsExt__PixelPerfectMovement__PixelPerfectPlatformerCharacter.PixelPerfectPlatformerCharacter.prototype.doStepPreEventsContext.GDObjectObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.evtsExt__PixelPerfectMovement__PixelPerfectPlatformerCharacter.PixelPerfectPlatformerCharacter.prototype.doStepPreEventsContext.GDObjectObjects1.length;i<l;++i) {
    if ( gdjs.evtsExt__PixelPerfectMovement__PixelPerfectPlatformerCharacter.PixelPerfectPlatformerCharacter.prototype.doStepPreEventsContext.GDObjectObjects1[i].getBehavior(eventsFunctionContext.getBehaviorName("PlatformerCharacter")).isOnLadder() ) {
        isConditionTrue_0 = true;
        gdjs.evtsExt__PixelPerfectMovement__PixelPerfectPlatformerCharacter.PixelPerfectPlatformerCharacter.prototype.doStepPreEventsContext.GDObjectObjects1[k] = gdjs.evtsExt__PixelPerfectMovement__PixelPerfectPlatformerCharacter.PixelPerfectPlatformerCharacter.prototype.doStepPreEventsContext.GDObjectObjects1[i];
        ++k;
    }
}
gdjs.evtsExt__PixelPerfectMovement__PixelPerfectPlatformerCharacter.PixelPerfectPlatformerCharacter.prototype.doStepPreEventsContext.GDObjectObjects1.length = k;
if (isConditionTrue_0) {

{ //Subevents
gdjs.evtsExt__PixelPerfectMovement__PixelPerfectPlatformerCharacter.PixelPerfectPlatformerCharacter.prototype.doStepPreEventsContext.eventsList11(runtimeScene, eventsFunctionContext);} //End of subevents
}

}


};gdjs.evtsExt__PixelPerfectMovement__PixelPerfectPlatformerCharacter.PixelPerfectPlatformerCharacter.prototype.doStepPreEventsContext.eventsList13 = function(runtimeScene, eventsFunctionContext) {

{


gdjs.evtsExt__PixelPerfectMovement__PixelPerfectPlatformerCharacter.PixelPerfectPlatformerCharacter.prototype.doStepPreEventsContext.eventsList5(runtimeScene, eventsFunctionContext);
}


{


gdjs.evtsExt__PixelPerfectMovement__PixelPerfectPlatformerCharacter.PixelPerfectPlatformerCharacter.prototype.doStepPreEventsContext.eventsList12(runtimeScene, eventsFunctionContext);
}


};

gdjs.evtsExt__PixelPerfectMovement__PixelPerfectPlatformerCharacter.PixelPerfectPlatformerCharacter.prototype.doStepPreEvents = function(parentEventsFunctionContext) {
this._onceTriggers.startNewFrame();
var that = this;
var runtimeScene = this._runtimeScene;
let scopeInstanceContainer = null;
var thisObjectList = [this.owner];
var Object = Hashtable.newFrom({Object: thisObjectList});
var Behavior = this.name;
var eventsFunctionContext = {
  _objectsMap: {
"Object": Object
},
  _objectArraysMap: {
"Object": thisObjectList
},
  _behaviorNamesMap: {
"Behavior": Behavior
, "PlatformerCharacter": this._getPlatformerCharacter()
},
  globalVariablesForExtension: runtimeScene.getGame().getVariablesForExtension("PixelPerfectMovement"),
  sceneVariablesForExtension: runtimeScene.getScene().getVariablesForExtension("PixelPerfectMovement"),
  localVariables: [],
  getObjects: function(objectName) {
    return eventsFunctionContext._objectArraysMap[objectName] || [];
  },
  getObjectsLists: function(objectName) {
    return eventsFunctionContext._objectsMap[objectName] || null;
  },
  getBehaviorName: function(behaviorName) {
    return eventsFunctionContext._behaviorNamesMap[behaviorName] || behaviorName;
  },
  createObject: function(objectName) {
    const objectsList = eventsFunctionContext._objectsMap[objectName];
    if (objectsList) {
      const object = parentEventsFunctionContext && !(scopeInstanceContainer && scopeInstanceContainer.isObjectRegistered(objectName)) ?
        parentEventsFunctionContext.createObject(objectsList.firstKey()) :
        runtimeScene.createObject(objectsList.firstKey());
      if (object) {
        objectsList.get(objectsList.firstKey()).push(object);
        if (!(scopeInstanceContainer && scopeInstanceContainer.isObjectRegistered(objectName))) {
          eventsFunctionContext._objectArraysMap[objectName].push(object);
        }
      }
      return object;
    }
    return null;
  },
  getInstancesCountOnScene: function(objectName) {
    const objectsList = eventsFunctionContext._objectsMap[objectName];
    let count = 0;
    if (objectsList) {
      for(const objectName in objectsList.items)
        count += parentEventsFunctionContext && !(scopeInstanceContainer && scopeInstanceContainer.isObjectRegistered(objectName)) ?
parentEventsFunctionContext.getInstancesCountOnScene(objectName) :
        runtimeScene.getInstancesCountOnScene(objectName);
    }
    return count;
  },
  getLayer: function(layerName) {
    return runtimeScene.getLayer(layerName);
  },
  getArgument: function(argName) {
    return "";
  },
  getOnceTriggers: function() { return that._onceTriggers; }
};

gdjs.evtsExt__PixelPerfectMovement__PixelPerfectPlatformerCharacter.PixelPerfectPlatformerCharacter.prototype.doStepPreEventsContext.GDObjectObjects1.length = 0;
gdjs.evtsExt__PixelPerfectMovement__PixelPerfectPlatformerCharacter.PixelPerfectPlatformerCharacter.prototype.doStepPreEventsContext.GDObjectObjects2.length = 0;
gdjs.evtsExt__PixelPerfectMovement__PixelPerfectPlatformerCharacter.PixelPerfectPlatformerCharacter.prototype.doStepPreEventsContext.GDObjectObjects3.length = 0;
gdjs.evtsExt__PixelPerfectMovement__PixelPerfectPlatformerCharacter.PixelPerfectPlatformerCharacter.prototype.doStepPreEventsContext.GDObjectObjects4.length = 0;

gdjs.evtsExt__PixelPerfectMovement__PixelPerfectPlatformerCharacter.PixelPerfectPlatformerCharacter.prototype.doStepPreEventsContext.eventsList13(runtimeScene, eventsFunctionContext);
gdjs.evtsExt__PixelPerfectMovement__PixelPerfectPlatformerCharacter.PixelPerfectPlatformerCharacter.prototype.doStepPreEventsContext.GDObjectObjects1.length = 0;
gdjs.evtsExt__PixelPerfectMovement__PixelPerfectPlatformerCharacter.PixelPerfectPlatformerCharacter.prototype.doStepPreEventsContext.GDObjectObjects2.length = 0;
gdjs.evtsExt__PixelPerfectMovement__PixelPerfectPlatformerCharacter.PixelPerfectPlatformerCharacter.prototype.doStepPreEventsContext.GDObjectObjects3.length = 0;
gdjs.evtsExt__PixelPerfectMovement__PixelPerfectPlatformerCharacter.PixelPerfectPlatformerCharacter.prototype.doStepPreEventsContext.GDObjectObjects4.length = 0;


return;
}
gdjs.evtsExt__PixelPerfectMovement__PixelPerfectPlatformerCharacter.PixelPerfectPlatformerCharacter.prototype.doStepPostEventsContext = {};
gdjs.evtsExt__PixelPerfectMovement__PixelPerfectPlatformerCharacter.PixelPerfectPlatformerCharacter.prototype.doStepPostEventsContext.idToCallbackMap = new Map();
gdjs.evtsExt__PixelPerfectMovement__PixelPerfectPlatformerCharacter.PixelPerfectPlatformerCharacter.prototype.doStepPostEventsContext.GDObjectObjects1_1final = [];

gdjs.evtsExt__PixelPerfectMovement__PixelPerfectPlatformerCharacter.PixelPerfectPlatformerCharacter.prototype.doStepPostEventsContext.GDObjectObjects1= [];
gdjs.evtsExt__PixelPerfectMovement__PixelPerfectPlatformerCharacter.PixelPerfectPlatformerCharacter.prototype.doStepPostEventsContext.GDObjectObjects2= [];


gdjs.evtsExt__PixelPerfectMovement__PixelPerfectPlatformerCharacter.PixelPerfectPlatformerCharacter.prototype.doStepPostEventsContext.eventsList0 = function(runtimeScene, eventsFunctionContext) {

{


let isConditionTrue_0 = false;
{
{eventsFunctionContext.getObjects("Object")[0].getBehavior(eventsFunctionContext.getBehaviorName("Behavior"))._setIsDecelerating(false)
}
}

}


{

gdjs.evtsExt__PixelPerfectMovement__PixelPerfectPlatformerCharacter.PixelPerfectPlatformerCharacter.prototype.doStepPostEventsContext.GDObjectObjects1.length = 0;


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
{gdjs.evtsExt__PixelPerfectMovement__PixelPerfectPlatformerCharacter.PixelPerfectPlatformerCharacter.prototype.doStepPostEventsContext.GDObjectObjects1_1final.length = 0;
let isConditionTrue_1 = false;
isConditionTrue_0 = false;
{
gdjs.copyArray(eventsFunctionContext.getObjects("Object"), gdjs.evtsExt__PixelPerfectMovement__PixelPerfectPlatformerCharacter.PixelPerfectPlatformerCharacter.prototype.doStepPostEventsContext.GDObjectObjects2);
for (var i = 0, k = 0, l = gdjs.evtsExt__PixelPerfectMovement__PixelPerfectPlatformerCharacter.PixelPerfectPlatformerCharacter.prototype.doStepPostEventsContext.GDObjectObjects2.length;i<l;++i) {
    if ( gdjs.evtsExt__PixelPerfectMovement__PixelPerfectPlatformerCharacter.PixelPerfectPlatformerCharacter.prototype.doStepPostEventsContext.GDObjectObjects2[i].getBehavior(eventsFunctionContext.getBehaviorName("PlatformerCharacter")).getCurrentSpeed() == 0 ) {
        isConditionTrue_1 = true;
        gdjs.evtsExt__PixelPerfectMovement__PixelPerfectPlatformerCharacter.PixelPerfectPlatformerCharacter.prototype.doStepPostEventsContext.GDObjectObjects2[k] = gdjs.evtsExt__PixelPerfectMovement__PixelPerfectPlatformerCharacter.PixelPerfectPlatformerCharacter.prototype.doStepPostEventsContext.GDObjectObjects2[i];
        ++k;
    }
}
gdjs.evtsExt__PixelPerfectMovement__PixelPerfectPlatformerCharacter.PixelPerfectPlatformerCharacter.prototype.doStepPostEventsContext.GDObjectObjects2.length = k;
if(isConditionTrue_1) {
    isConditionTrue_0 = true;
    for (let j = 0, jLen = gdjs.evtsExt__PixelPerfectMovement__PixelPerfectPlatformerCharacter.PixelPerfectPlatformerCharacter.prototype.doStepPostEventsContext.GDObjectObjects2.length; j < jLen ; ++j) {
        if ( gdjs.evtsExt__PixelPerfectMovement__PixelPerfectPlatformerCharacter.PixelPerfectPlatformerCharacter.prototype.doStepPostEventsContext.GDObjectObjects1_1final.indexOf(gdjs.evtsExt__PixelPerfectMovement__PixelPerfectPlatformerCharacter.PixelPerfectPlatformerCharacter.prototype.doStepPostEventsContext.GDObjectObjects2[j]) === -1 )
            gdjs.evtsExt__PixelPerfectMovement__PixelPerfectPlatformerCharacter.PixelPerfectPlatformerCharacter.prototype.doStepPostEventsContext.GDObjectObjects1_1final.push(gdjs.evtsExt__PixelPerfectMovement__PixelPerfectPlatformerCharacter.PixelPerfectPlatformerCharacter.prototype.doStepPostEventsContext.GDObjectObjects2[j]);
    }
}
}
{
gdjs.copyArray(eventsFunctionContext.getObjects("Object"), gdjs.evtsExt__PixelPerfectMovement__PixelPerfectPlatformerCharacter.PixelPerfectPlatformerCharacter.prototype.doStepPostEventsContext.GDObjectObjects2);
{isConditionTrue_1 = (Math.abs((( gdjs.evtsExt__PixelPerfectMovement__PixelPerfectPlatformerCharacter.PixelPerfectPlatformerCharacter.prototype.doStepPostEventsContext.GDObjectObjects2.length === 0 ) ? 0 :gdjs.evtsExt__PixelPerfectMovement__PixelPerfectPlatformerCharacter.PixelPerfectPlatformerCharacter.prototype.doStepPostEventsContext.GDObjectObjects2[0].getBehavior(eventsFunctionContext.getBehaviorName("PlatformerCharacter")).getCurrentSpeed())) == Math.abs(eventsFunctionContext.getObjects("Object")[0].getBehavior(eventsFunctionContext.getBehaviorName("Behavior"))._getPreviousSpeedX()) - (( gdjs.evtsExt__PixelPerfectMovement__PixelPerfectPlatformerCharacter.PixelPerfectPlatformerCharacter.prototype.doStepPostEventsContext.GDObjectObjects2.length === 0 ) ? 0 :gdjs.evtsExt__PixelPerfectMovement__PixelPerfectPlatformerCharacter.PixelPerfectPlatformerCharacter.prototype.doStepPostEventsContext.GDObjectObjects2[0].getBehavior(eventsFunctionContext.getBehaviorName("PlatformerCharacter")).getDeceleration()) * gdjs.evtTools.runtimeScene.getElapsedTimeInSeconds(runtimeScene));
}
if(isConditionTrue_1) {
    isConditionTrue_0 = true;
    for (let j = 0, jLen = gdjs.evtsExt__PixelPerfectMovement__PixelPerfectPlatformerCharacter.PixelPerfectPlatformerCharacter.prototype.doStepPostEventsContext.GDObjectObjects2.length; j < jLen ; ++j) {
        if ( gdjs.evtsExt__PixelPerfectMovement__PixelPerfectPlatformerCharacter.PixelPerfectPlatformerCharacter.prototype.doStepPostEventsContext.GDObjectObjects1_1final.indexOf(gdjs.evtsExt__PixelPerfectMovement__PixelPerfectPlatformerCharacter.PixelPerfectPlatformerCharacter.prototype.doStepPostEventsContext.GDObjectObjects2[j]) === -1 )
            gdjs.evtsExt__PixelPerfectMovement__PixelPerfectPlatformerCharacter.PixelPerfectPlatformerCharacter.prototype.doStepPostEventsContext.GDObjectObjects1_1final.push(gdjs.evtsExt__PixelPerfectMovement__PixelPerfectPlatformerCharacter.PixelPerfectPlatformerCharacter.prototype.doStepPostEventsContext.GDObjectObjects2[j]);
    }
}
}
{
gdjs.copyArray(gdjs.evtsExt__PixelPerfectMovement__PixelPerfectPlatformerCharacter.PixelPerfectPlatformerCharacter.prototype.doStepPostEventsContext.GDObjectObjects1_1final, gdjs.evtsExt__PixelPerfectMovement__PixelPerfectPlatformerCharacter.PixelPerfectPlatformerCharacter.prototype.doStepPostEventsContext.GDObjectObjects1);
}
}
if (isConditionTrue_0) {
{eventsFunctionContext.getObjects("Object")[0].getBehavior(eventsFunctionContext.getBehaviorName("Behavior"))._setIsDecelerating(true)
}
}

}


{


let isConditionTrue_0 = false;
{
gdjs.copyArray(eventsFunctionContext.getObjects("Object"), gdjs.evtsExt__PixelPerfectMovement__PixelPerfectPlatformerCharacter.PixelPerfectPlatformerCharacter.prototype.doStepPostEventsContext.GDObjectObjects1);
{eventsFunctionContext.getObjects("Object")[0].getBehavior(eventsFunctionContext.getBehaviorName("Behavior"))._setPreviousSpeedX((( gdjs.evtsExt__PixelPerfectMovement__PixelPerfectPlatformerCharacter.PixelPerfectPlatformerCharacter.prototype.doStepPostEventsContext.GDObjectObjects1.length === 0 ) ? 0 :gdjs.evtsExt__PixelPerfectMovement__PixelPerfectPlatformerCharacter.PixelPerfectPlatformerCharacter.prototype.doStepPostEventsContext.GDObjectObjects1[0].getBehavior(eventsFunctionContext.getBehaviorName("PlatformerCharacter")).getCurrentSpeed()))
}
}

}


};

gdjs.evtsExt__PixelPerfectMovement__PixelPerfectPlatformerCharacter.PixelPerfectPlatformerCharacter.prototype.doStepPostEvents = function(parentEventsFunctionContext) {

var that = this;
var runtimeScene = this._runtimeScene;
let scopeInstanceContainer = null;
var thisObjectList = [this.owner];
var Object = Hashtable.newFrom({Object: thisObjectList});
var Behavior = this.name;
var eventsFunctionContext = {
  _objectsMap: {
"Object": Object
},
  _objectArraysMap: {
"Object": thisObjectList
},
  _behaviorNamesMap: {
"Behavior": Behavior
, "PlatformerCharacter": this._getPlatformerCharacter()
},
  globalVariablesForExtension: runtimeScene.getGame().getVariablesForExtension("PixelPerfectMovement"),
  sceneVariablesForExtension: runtimeScene.getScene().getVariablesForExtension("PixelPerfectMovement"),
  localVariables: [],
  getObjects: function(objectName) {
    return eventsFunctionContext._objectArraysMap[objectName] || [];
  },
  getObjectsLists: function(objectName) {
    return eventsFunctionContext._objectsMap[objectName] || null;
  },
  getBehaviorName: function(behaviorName) {
    return eventsFunctionContext._behaviorNamesMap[behaviorName] || behaviorName;
  },
  createObject: function(objectName) {
    const objectsList = eventsFunctionContext._objectsMap[objectName];
    if (objectsList) {
      const object = parentEventsFunctionContext && !(scopeInstanceContainer && scopeInstanceContainer.isObjectRegistered(objectName)) ?
        parentEventsFunctionContext.createObject(objectsList.firstKey()) :
        runtimeScene.createObject(objectsList.firstKey());
      if (object) {
        objectsList.get(objectsList.firstKey()).push(object);
        if (!(scopeInstanceContainer && scopeInstanceContainer.isObjectRegistered(objectName))) {
          eventsFunctionContext._objectArraysMap[objectName].push(object);
        }
      }
      return object;
    }
    return null;
  },
  getInstancesCountOnScene: function(objectName) {
    const objectsList = eventsFunctionContext._objectsMap[objectName];
    let count = 0;
    if (objectsList) {
      for(const objectName in objectsList.items)
        count += parentEventsFunctionContext && !(scopeInstanceContainer && scopeInstanceContainer.isObjectRegistered(objectName)) ?
parentEventsFunctionContext.getInstancesCountOnScene(objectName) :
        runtimeScene.getInstancesCountOnScene(objectName);
    }
    return count;
  },
  getLayer: function(layerName) {
    return runtimeScene.getLayer(layerName);
  },
  getArgument: function(argName) {
    return "";
  },
  getOnceTriggers: function() { return that._onceTriggers; }
};

gdjs.evtsExt__PixelPerfectMovement__PixelPerfectPlatformerCharacter.PixelPerfectPlatformerCharacter.prototype.doStepPostEventsContext.GDObjectObjects1.length = 0;
gdjs.evtsExt__PixelPerfectMovement__PixelPerfectPlatformerCharacter.PixelPerfectPlatformerCharacter.prototype.doStepPostEventsContext.GDObjectObjects2.length = 0;

gdjs.evtsExt__PixelPerfectMovement__PixelPerfectPlatformerCharacter.PixelPerfectPlatformerCharacter.prototype.doStepPostEventsContext.eventsList0(runtimeScene, eventsFunctionContext);
gdjs.evtsExt__PixelPerfectMovement__PixelPerfectPlatformerCharacter.PixelPerfectPlatformerCharacter.prototype.doStepPostEventsContext.GDObjectObjects1.length = 0;
gdjs.evtsExt__PixelPerfectMovement__PixelPerfectPlatformerCharacter.PixelPerfectPlatformerCharacter.prototype.doStepPostEventsContext.GDObjectObjects2.length = 0;


return;
}


gdjs.registerBehavior("PixelPerfectMovement::PixelPerfectPlatformerCharacter", gdjs.evtsExt__PixelPerfectMovement__PixelPerfectPlatformerCharacter.PixelPerfectPlatformerCharacter);
