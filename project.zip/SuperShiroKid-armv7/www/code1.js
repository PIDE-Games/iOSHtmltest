gdjs.PIDELOGOCode = {};
gdjs.PIDELOGOCode.localVariables = [];
gdjs.PIDELOGOCode.idToCallbackMap = new Map();
gdjs.PIDELOGOCode.GDNewSpriteObjects1= [];
gdjs.PIDELOGOCode.GDNewSpriteObjects2= [];
gdjs.PIDELOGOCode.GDShiroStartObjects1= [];
gdjs.PIDELOGOCode.GDShiroStartObjects2= [];
gdjs.PIDELOGOCode.GDNew3DModelObjects1= [];
gdjs.PIDELOGOCode.GDNew3DModelObjects2= [];
gdjs.PIDELOGOCode.GDGroundObjects1= [];
gdjs.PIDELOGOCode.GDGroundObjects2= [];


gdjs.PIDELOGOCode.eventsList0 = function(runtimeScene) {

{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.runtimeScene.sceneJustBegins(runtimeScene);
if (isConditionTrue_0) {
{gdjs.evtTools.sound.playMusic(runtimeScene, "PIDE logo jingle Bitcrush.wav", false, 100, 1);
}
}

}


{

gdjs.copyArray(runtimeScene.getObjects("NewSprite"), gdjs.PIDELOGOCode.GDNewSpriteObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.PIDELOGOCode.GDNewSpriteObjects1.length;i<l;++i) {
    if ( gdjs.PIDELOGOCode.GDNewSpriteObjects1[i].getBehavior("Animation").hasAnimationEnded() ) {
        isConditionTrue_0 = true;
        gdjs.PIDELOGOCode.GDNewSpriteObjects1[k] = gdjs.PIDELOGOCode.GDNewSpriteObjects1[i];
        ++k;
    }
}
gdjs.PIDELOGOCode.GDNewSpriteObjects1.length = k;
if (isConditionTrue_0) {
{gdjs.evtTools.runtimeScene.replaceScene(runtimeScene, "11LOAD", false);
}
}

}


{

gdjs.copyArray(runtimeScene.getObjects("NewSprite"), gdjs.PIDELOGOCode.GDNewSpriteObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.PIDELOGOCode.GDNewSpriteObjects1.length;i<l;++i) {
    if ( gdjs.PIDELOGOCode.GDNewSpriteObjects1[i].getBehavior("FlashOpacity").HalfPeriodTime(null) == 4 ) {
        isConditionTrue_0 = true;
        gdjs.PIDELOGOCode.GDNewSpriteObjects1[k] = gdjs.PIDELOGOCode.GDNewSpriteObjects1[i];
        ++k;
    }
}
gdjs.PIDELOGOCode.GDNewSpriteObjects1.length = k;
if (isConditionTrue_0) {
/* Reuse gdjs.PIDELOGOCode.GDNewSpriteObjects1 */
{for(var i = 0, len = gdjs.PIDELOGOCode.GDNewSpriteObjects1.length ;i < len;++i) {
    gdjs.PIDELOGOCode.GDNewSpriteObjects1[i].getBehavior("FlashOpacity").Flash("Tween", 0, 0, null);
}
}
}

}


{


let isConditionTrue_0 = false;
{
}

}


};

gdjs.PIDELOGOCode.func = function(runtimeScene) {
runtimeScene.getOnceTriggers().startNewFrame();

gdjs.PIDELOGOCode.GDNewSpriteObjects1.length = 0;
gdjs.PIDELOGOCode.GDNewSpriteObjects2.length = 0;
gdjs.PIDELOGOCode.GDShiroStartObjects1.length = 0;
gdjs.PIDELOGOCode.GDShiroStartObjects2.length = 0;
gdjs.PIDELOGOCode.GDNew3DModelObjects1.length = 0;
gdjs.PIDELOGOCode.GDNew3DModelObjects2.length = 0;
gdjs.PIDELOGOCode.GDGroundObjects1.length = 0;
gdjs.PIDELOGOCode.GDGroundObjects2.length = 0;

gdjs.PIDELOGOCode.eventsList0(runtimeScene);
gdjs.PIDELOGOCode.GDNewSpriteObjects1.length = 0;
gdjs.PIDELOGOCode.GDNewSpriteObjects2.length = 0;
gdjs.PIDELOGOCode.GDShiroStartObjects1.length = 0;
gdjs.PIDELOGOCode.GDShiroStartObjects2.length = 0;
gdjs.PIDELOGOCode.GDNew3DModelObjects1.length = 0;
gdjs.PIDELOGOCode.GDNew3DModelObjects2.length = 0;
gdjs.PIDELOGOCode.GDGroundObjects1.length = 0;
gdjs.PIDELOGOCode.GDGroundObjects2.length = 0;


return;

}

gdjs['PIDELOGOCode'] = gdjs.PIDELOGOCode;
