gdjs._49Code = {};
gdjs._49Code.localVariables = [];
gdjs._49Code.idToCallbackMap = new Map();
gdjs._49Code.GDPlayerObjects1= [];
gdjs._49Code.GDPlayerObjects2= [];
gdjs._49Code.GDCoinsObjects1= [];
gdjs._49Code.GDCoinsObjects2= [];
gdjs._49Code.GDPlatform_9595GroundObjects1= [];
gdjs._49Code.GDPlatform_9595GroundObjects2= [];
gdjs._49Code.GDNewSprite4Objects1= [];
gdjs._49Code.GDNewSprite4Objects2= [];
gdjs._49Code.GDNewSprite5Objects1= [];
gdjs._49Code.GDNewSprite5Objects2= [];
gdjs._49Code.GDNewSprite6Objects1= [];
gdjs._49Code.GDNewSprite6Objects2= [];
gdjs._49Code.GDspikeObjects1= [];
gdjs._49Code.GDspikeObjects2= [];
gdjs._49Code.GDNewSprite7Objects1= [];
gdjs._49Code.GDNewSprite7Objects2= [];
gdjs._49Code.GDNewSprite8Objects1= [];
gdjs._49Code.GDNewSprite8Objects2= [];
gdjs._49Code.GDNewSprite3Objects1= [];
gdjs._49Code.GDNewSprite3Objects2= [];
gdjs._49Code.GDpipeObjects1= [];
gdjs._49Code.GDpipeObjects2= [];
gdjs._49Code.GDStacyObjects1= [];
gdjs._49Code.GDStacyObjects2= [];
gdjs._49Code.GDShadedDarkJoystickObjects1= [];
gdjs._49Code.GDShadedDarkJoystickObjects2= [];
gdjs._49Code.GDNewSpriteObjects1= [];
gdjs._49Code.GDNewSpriteObjects2= [];
gdjs._49Code.GDNewSprite9Objects1= [];
gdjs._49Code.GDNewSprite9Objects2= [];
gdjs._49Code.GDMountain_9595dewObjects1= [];
gdjs._49Code.GDMountain_9595dewObjects2= [];
gdjs._49Code.GDNewSprite10Objects1= [];
gdjs._49Code.GDNewSprite10Objects2= [];
gdjs._49Code.GDJumpObjects1= [];
gdjs._49Code.GDJumpObjects2= [];
gdjs._49Code.GDTreeObjects1= [];
gdjs._49Code.GDTreeObjects2= [];
gdjs._49Code.GDPauseObjects1= [];
gdjs._49Code.GDPauseObjects2= [];
gdjs._49Code.GDNewTextObjects1= [];
gdjs._49Code.GDNewTextObjects2= [];
gdjs._49Code.GDNewSprite2Objects1= [];
gdjs._49Code.GDNewSprite2Objects2= [];
gdjs._49Code.GDNewSprite11Objects1= [];
gdjs._49Code.GDNewSprite11Objects2= [];
gdjs._49Code.GDNewSprite12Objects1= [];
gdjs._49Code.GDNewSprite12Objects2= [];
gdjs._49Code.GDNewSprite13Objects1= [];
gdjs._49Code.GDNewSprite13Objects2= [];
gdjs._49Code.GDspikenotvisiObjects1= [];
gdjs._49Code.GDspikenotvisiObjects2= [];
gdjs._49Code.GDBoomObjects1= [];
gdjs._49Code.GDBoomObjects2= [];
gdjs._49Code.GDNew3DBoxObjects1= [];
gdjs._49Code.GDNew3DBoxObjects2= [];
gdjs._49Code.GDLoadanimObjects1= [];
gdjs._49Code.GDLoadanimObjects2= [];
gdjs._49Code.GDNewSprite14Objects1= [];
gdjs._49Code.GDNewSprite14Objects2= [];
gdjs._49Code.GDBushesObjects1= [];
gdjs._49Code.GDBushesObjects2= [];
gdjs._49Code.GDNewSprite15Objects1= [];
gdjs._49Code.GDNewSprite15Objects2= [];
gdjs._49Code.GDSurpsObjects1= [];
gdjs._49Code.GDSurpsObjects2= [];
gdjs._49Code.GDNewSprite16Objects1= [];
gdjs._49Code.GDNewSprite16Objects2= [];
gdjs._49Code.GDDeathObjects1= [];
gdjs._49Code.GDDeathObjects2= [];
gdjs._49Code.GDmenublockObjects1= [];
gdjs._49Code.GDmenublockObjects2= [];


gdjs._49Code.mapOfGDgdjs_9546_959549Code_9546GDPlayerObjects1Objects = Hashtable.newFrom({"Player": gdjs._49Code.GDPlayerObjects1});
gdjs._49Code.mapOfGDgdjs_9546_959549Code_9546GDCoinsObjects1Objects = Hashtable.newFrom({"Coins": gdjs._49Code.GDCoinsObjects1});
gdjs._49Code.mapOfGDgdjs_9546_959549Code_9546GDPlayerObjects1Objects = Hashtable.newFrom({"Player": gdjs._49Code.GDPlayerObjects1});
gdjs._49Code.mapOfGDgdjs_9546_959549Code_9546GDNewSprite11Objects1Objects = Hashtable.newFrom({"NewSprite11": gdjs._49Code.GDNewSprite11Objects1});
gdjs._49Code.mapOfGDgdjs_9546_959549Code_9546GDPlayerObjects1Objects = Hashtable.newFrom({"Player": gdjs._49Code.GDPlayerObjects1});
gdjs._49Code.mapOfGDgdjs_9546_959549Code_9546GDNewSprite4Objects1Objects = Hashtable.newFrom({"NewSprite4": gdjs._49Code.GDNewSprite4Objects1});
gdjs._49Code.mapOfGDgdjs_9546_959549Code_9546GDPlayerObjects1Objects = Hashtable.newFrom({"Player": gdjs._49Code.GDPlayerObjects1});
gdjs._49Code.mapOfGDgdjs_9546_959549Code_9546GDNewSprite11Objects1Objects = Hashtable.newFrom({"NewSprite11": gdjs._49Code.GDNewSprite11Objects1});
gdjs._49Code.mapOfGDgdjs_9546_959549Code_9546GDPlayerObjects1Objects = Hashtable.newFrom({"Player": gdjs._49Code.GDPlayerObjects1});
gdjs._49Code.mapOfGDgdjs_9546_959549Code_9546GDNewSprite4Objects1Objects = Hashtable.newFrom({"NewSprite4": gdjs._49Code.GDNewSprite4Objects1});
gdjs._49Code.mapOfGDgdjs_9546_959549Code_9546GDPlayerObjects1Objects = Hashtable.newFrom({"Player": gdjs._49Code.GDPlayerObjects1});
gdjs._49Code.mapOfGDgdjs_9546_959549Code_9546GDspikeObjects1Objects = Hashtable.newFrom({"spike": gdjs._49Code.GDspikeObjects1});
gdjs._49Code.mapOfGDgdjs_9546_959549Code_9546GDPlayerObjects1Objects = Hashtable.newFrom({"Player": gdjs._49Code.GDPlayerObjects1});
gdjs._49Code.mapOfGDgdjs_9546_959549Code_9546GDspikeObjects1Objects = Hashtable.newFrom({"spike": gdjs._49Code.GDspikeObjects1});
gdjs._49Code.mapOfGDgdjs_9546_959549Code_9546GDPlayerObjects1Objects = Hashtable.newFrom({"Player": gdjs._49Code.GDPlayerObjects1});
gdjs._49Code.mapOfGDgdjs_9546_959549Code_9546GDPlatform_95959595GroundObjects1Objects = Hashtable.newFrom({"Platform_Ground": gdjs._49Code.GDPlatform_9595GroundObjects1});
gdjs._49Code.mapOfGDgdjs_9546_959549Code_9546GDPlayerObjects1Objects = Hashtable.newFrom({"Player": gdjs._49Code.GDPlayerObjects1});
gdjs._49Code.mapOfGDgdjs_9546_959549Code_9546GDPlatform_95959595GroundObjects1Objects = Hashtable.newFrom({"Platform_Ground": gdjs._49Code.GDPlatform_9595GroundObjects1});
gdjs._49Code.mapOfGDgdjs_9546_959549Code_9546GDPlayerObjects1Objects = Hashtable.newFrom({"Player": gdjs._49Code.GDPlayerObjects1});
gdjs._49Code.mapOfGDgdjs_9546_959549Code_9546GDspikeObjects1Objects = Hashtable.newFrom({"spike": gdjs._49Code.GDspikeObjects1});
gdjs._49Code.mapOfGDgdjs_9546_959549Code_9546GDPlayerObjects1Objects = Hashtable.newFrom({"Player": gdjs._49Code.GDPlayerObjects1});
gdjs._49Code.mapOfGDgdjs_9546_959549Code_9546GDNewSprite14Objects1Objects = Hashtable.newFrom({"NewSprite14": gdjs._49Code.GDNewSprite14Objects1});
gdjs._49Code.mapOfGDgdjs_9546_959549Code_9546GDPlayerObjects1Objects = Hashtable.newFrom({"Player": gdjs._49Code.GDPlayerObjects1});
gdjs._49Code.mapOfGDgdjs_9546_959549Code_9546GDNewSprite15Objects1Objects = Hashtable.newFrom({"NewSprite15": gdjs._49Code.GDNewSprite15Objects1});
gdjs._49Code.mapOfGDgdjs_9546_959549Code_9546GDPlayerObjects1Objects = Hashtable.newFrom({"Player": gdjs._49Code.GDPlayerObjects1});
gdjs._49Code.mapOfGDgdjs_9546_959549Code_9546GDspikeObjects1Objects = Hashtable.newFrom({"spike": gdjs._49Code.GDspikeObjects1});
gdjs._49Code.mapOfGDgdjs_9546_959549Code_9546GDPlayerObjects1Objects = Hashtable.newFrom({"Player": gdjs._49Code.GDPlayerObjects1});
gdjs._49Code.mapOfGDgdjs_9546_959549Code_9546GDspikeObjects1Objects = Hashtable.newFrom({"spike": gdjs._49Code.GDspikeObjects1});
gdjs._49Code.mapOfGDgdjs_9546_959549Code_9546GDPlayerObjects1Objects = Hashtable.newFrom({"Player": gdjs._49Code.GDPlayerObjects1});
gdjs._49Code.mapOfGDgdjs_9546_959549Code_9546GDDeathObjects1Objects = Hashtable.newFrom({"Death": gdjs._49Code.GDDeathObjects1});
gdjs._49Code.mapOfGDgdjs_9546_959549Code_9546GDPlayerObjects1Objects = Hashtable.newFrom({"Player": gdjs._49Code.GDPlayerObjects1});
gdjs._49Code.mapOfGDgdjs_9546_959549Code_9546GDmenublockObjects1Objects = Hashtable.newFrom({"menublock": gdjs._49Code.GDmenublockObjects1});
gdjs._49Code.mapOfGDgdjs_9546_959549Code_9546GDPlayerObjects1Objects = Hashtable.newFrom({"Player": gdjs._49Code.GDPlayerObjects1});
gdjs._49Code.mapOfGDgdjs_9546_959549Code_9546GDDeathObjects1Objects = Hashtable.newFrom({"Death": gdjs._49Code.GDDeathObjects1});
gdjs._49Code.mapOfGDgdjs_9546_959549Code_9546GDPlayerObjects1Objects = Hashtable.newFrom({"Player": gdjs._49Code.GDPlayerObjects1});
gdjs._49Code.mapOfGDgdjs_9546_959549Code_9546GDDeathObjects1Objects = Hashtable.newFrom({"Death": gdjs._49Code.GDDeathObjects1});
gdjs._49Code.mapOfGDgdjs_9546_959549Code_9546GDPlayerObjects1Objects = Hashtable.newFrom({"Player": gdjs._49Code.GDPlayerObjects1});
gdjs._49Code.mapOfGDgdjs_9546_959549Code_9546GDspikeObjects1Objects = Hashtable.newFrom({"spike": gdjs._49Code.GDspikeObjects1});
gdjs._49Code.eventsList0 = function(runtimeScene) {

{


let isConditionTrue_0 = false;
{
{gdjs.evtTools.camera.setCameraZoom(runtimeScene, 2.5, "", 0);
}
{gdjs.evtTools.camera.setCameraZoom(runtimeScene, 2.5, "Background", 0);
}
}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.runtimeScene.sceneJustBegins(runtimeScene);
if (isConditionTrue_0) {
}

}


{

gdjs.copyArray(runtimeScene.getObjects("Coins"), gdjs._49Code.GDCoinsObjects1);
gdjs.copyArray(runtimeScene.getObjects("Player"), gdjs._49Code.GDPlayerObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs._49Code.mapOfGDgdjs_9546_959549Code_9546GDPlayerObjects1Objects, gdjs._49Code.mapOfGDgdjs_9546_959549Code_9546GDCoinsObjects1Objects, false, runtimeScene, false);
if (isConditionTrue_0) {
/* Reuse gdjs._49Code.GDCoinsObjects1 */
{for(var i = 0, len = gdjs._49Code.GDCoinsObjects1.length ;i < len;++i) {
    gdjs._49Code.GDCoinsObjects1[i].deleteFromScene(runtimeScene);
}
}
{gdjs.evtTools.sound.playSound(runtimeScene, "Coin.wav", false, 100, 1);
}
}

}


{

gdjs.copyArray(runtimeScene.getObjects("Player"), gdjs._49Code.GDPlayerObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs._49Code.GDPlayerObjects1.length;i<l;++i) {
    if ( gdjs._49Code.GDPlayerObjects1[i].getBehavior("PlatformerObject").isOnFloor() ) {
        isConditionTrue_0 = true;
        gdjs._49Code.GDPlayerObjects1[k] = gdjs._49Code.GDPlayerObjects1[i];
        ++k;
    }
}
gdjs._49Code.GDPlayerObjects1.length = k;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs._49Code.GDPlayerObjects1.length;i<l;++i) {
    if ( !(gdjs._49Code.GDPlayerObjects1[i].getBehavior("PlatformerObject").isMovingEvenALittle()) ) {
        isConditionTrue_0 = true;
        gdjs._49Code.GDPlayerObjects1[k] = gdjs._49Code.GDPlayerObjects1[i];
        ++k;
    }
}
gdjs._49Code.GDPlayerObjects1.length = k;
}
if (isConditionTrue_0) {
/* Reuse gdjs._49Code.GDPlayerObjects1 */
{for(var i = 0, len = gdjs._49Code.GDPlayerObjects1.length ;i < len;++i) {
    gdjs._49Code.GDPlayerObjects1[i].getBehavior("Animation").setAnimationName("Idle");
}
}
}

}


{

gdjs.copyArray(runtimeScene.getObjects("Player"), gdjs._49Code.GDPlayerObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs._49Code.GDPlayerObjects1.length;i<l;++i) {
    if ( gdjs._49Code.GDPlayerObjects1[i].getBehavior("PlatformerObject").isMovingEvenALittle() ) {
        isConditionTrue_0 = true;
        gdjs._49Code.GDPlayerObjects1[k] = gdjs._49Code.GDPlayerObjects1[i];
        ++k;
    }
}
gdjs._49Code.GDPlayerObjects1.length = k;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs._49Code.GDPlayerObjects1.length;i<l;++i) {
    if ( gdjs._49Code.GDPlayerObjects1[i].getBehavior("PlatformerObject").isOnFloor() ) {
        isConditionTrue_0 = true;
        gdjs._49Code.GDPlayerObjects1[k] = gdjs._49Code.GDPlayerObjects1[i];
        ++k;
    }
}
gdjs._49Code.GDPlayerObjects1.length = k;
}
if (isConditionTrue_0) {
/* Reuse gdjs._49Code.GDPlayerObjects1 */
{for(var i = 0, len = gdjs._49Code.GDPlayerObjects1.length ;i < len;++i) {
    gdjs._49Code.GDPlayerObjects1[i].getBehavior("Animation").setAnimationName("Running");
}
}
}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.isKeyPressed(runtimeScene, "Left");
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("Player"), gdjs._49Code.GDPlayerObjects1);
{for(var i = 0, len = gdjs._49Code.GDPlayerObjects1.length ;i < len;++i) {
    gdjs._49Code.GDPlayerObjects1[i].getBehavior("Flippable").flipX(true);
}
}
}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.isKeyPressed(runtimeScene, "Right");
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("Player"), gdjs._49Code.GDPlayerObjects1);
{for(var i = 0, len = gdjs._49Code.GDPlayerObjects1.length ;i < len;++i) {
    gdjs._49Code.GDPlayerObjects1[i].getBehavior("Flippable").flipX(false);
}
}
}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.isKeyPressed(runtimeScene, "Left");
if (isConditionTrue_0) {
}

}


{


let isConditionTrue_0 = false;
{
}

}


{


let isConditionTrue_0 = false;
{
}

}


{

gdjs.copyArray(runtimeScene.getObjects("NewSprite11"), gdjs._49Code.GDNewSprite11Objects1);
gdjs.copyArray(runtimeScene.getObjects("Player"), gdjs._49Code.GDPlayerObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs._49Code.mapOfGDgdjs_9546_959549Code_9546GDPlayerObjects1Objects, gdjs._49Code.mapOfGDgdjs_9546_959549Code_9546GDNewSprite11Objects1Objects, false, runtimeScene, false);
if (isConditionTrue_0) {
{gdjs.evtTools.sound.playSound(runtimeScene, "TaDa.wav", false, 100, 1);
}
}

}


{

gdjs.copyArray(runtimeScene.getObjects("Player"), gdjs._49Code.GDPlayerObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs._49Code.GDPlayerObjects1.length;i<l;++i) {
    if ( gdjs._49Code.GDPlayerObjects1[i].getBehavior("PlatformerObject").isUsingControl("Left") ) {
        isConditionTrue_0 = true;
        gdjs._49Code.GDPlayerObjects1[k] = gdjs._49Code.GDPlayerObjects1[i];
        ++k;
    }
}
gdjs._49Code.GDPlayerObjects1.length = k;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs._49Code.GDPlayerObjects1.length;i<l;++i) {
    if ( !(gdjs._49Code.GDPlayerObjects1[i].getBehavior("PlatformerObject").isUsingControl("Right")) ) {
        isConditionTrue_0 = true;
        gdjs._49Code.GDPlayerObjects1[k] = gdjs._49Code.GDPlayerObjects1[i];
        ++k;
    }
}
gdjs._49Code.GDPlayerObjects1.length = k;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs._49Code.GDPlayerObjects1.length;i<l;++i) {
    if ( gdjs._49Code.GDPlayerObjects1[i].getBehavior("PlatformerObject").isUsingControl("Left") ) {
        isConditionTrue_0 = true;
        gdjs._49Code.GDPlayerObjects1[k] = gdjs._49Code.GDPlayerObjects1[i];
        ++k;
    }
}
gdjs._49Code.GDPlayerObjects1.length = k;
}
}
if (isConditionTrue_0) {
/* Reuse gdjs._49Code.GDPlayerObjects1 */
{for(var i = 0, len = gdjs._49Code.GDPlayerObjects1.length ;i < len;++i) {
    gdjs._49Code.GDPlayerObjects1[i].getBehavior("Flippable").flipX(false);
}
}
{for(var i = 0, len = gdjs._49Code.GDPlayerObjects1.length ;i < len;++i) {
    gdjs._49Code.GDPlayerObjects1[i].getBehavior("Flippable").flipX(false);
}
}
{for(var i = 0, len = gdjs._49Code.GDPlayerObjects1.length ;i < len;++i) {
    gdjs._49Code.GDPlayerObjects1[i].getBehavior("Flippable").flipX(true);
}
}
}

}


{

gdjs.copyArray(runtimeScene.getObjects("Player"), gdjs._49Code.GDPlayerObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs._49Code.GDPlayerObjects1.length;i<l;++i) {
    if ( gdjs._49Code.GDPlayerObjects1[i].getBehavior("PlatformerObject").isUsingControl("Right") ) {
        isConditionTrue_0 = true;
        gdjs._49Code.GDPlayerObjects1[k] = gdjs._49Code.GDPlayerObjects1[i];
        ++k;
    }
}
gdjs._49Code.GDPlayerObjects1.length = k;
if (isConditionTrue_0) {
/* Reuse gdjs._49Code.GDPlayerObjects1 */
{for(var i = 0, len = gdjs._49Code.GDPlayerObjects1.length ;i < len;++i) {
    gdjs._49Code.GDPlayerObjects1[i].getBehavior("Flippable").flipX(false);
}
}
}

}


{

gdjs.copyArray(runtimeScene.getObjects("Jump"), gdjs._49Code.GDJumpObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs._49Code.GDJumpObjects1.length;i<l;++i) {
    if ( gdjs._49Code.GDJumpObjects1[i].getBehavior("ButtonFSM").IsPressed(null) ) {
        isConditionTrue_0 = true;
        gdjs._49Code.GDJumpObjects1[k] = gdjs._49Code.GDJumpObjects1[i];
        ++k;
    }
}
gdjs._49Code.GDJumpObjects1.length = k;
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("Player"), gdjs._49Code.GDPlayerObjects1);
{for(var i = 0, len = gdjs._49Code.GDPlayerObjects1.length ;i < len;++i) {
    gdjs._49Code.GDPlayerObjects1[i].getBehavior("PlatformerObject").simulateJumpKey();
}
}
}

}


{

gdjs.copyArray(runtimeScene.getObjects("NewSprite4"), gdjs._49Code.GDNewSprite4Objects1);
gdjs.copyArray(runtimeScene.getObjects("Player"), gdjs._49Code.GDPlayerObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs._49Code.mapOfGDgdjs_9546_959549Code_9546GDPlayerObjects1Objects, gdjs._49Code.mapOfGDgdjs_9546_959549Code_9546GDNewSprite4Objects1Objects, false, runtimeScene, false);
if (isConditionTrue_0) {
/* Reuse gdjs._49Code.GDPlayerObjects1 */
{for(var i = 0, len = gdjs._49Code.GDPlayerObjects1.length ;i < len;++i) {
    gdjs._49Code.GDPlayerObjects1[i].getBehavior("PlatformerObject").simulateRightKey();
}
}
}

}


{

gdjs.copyArray(runtimeScene.getObjects("NewSprite11"), gdjs._49Code.GDNewSprite11Objects1);
gdjs.copyArray(runtimeScene.getObjects("Player"), gdjs._49Code.GDPlayerObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs._49Code.mapOfGDgdjs_9546_959549Code_9546GDPlayerObjects1Objects, gdjs._49Code.mapOfGDgdjs_9546_959549Code_9546GDNewSprite11Objects1Objects, false, runtimeScene, false);
if (isConditionTrue_0) {
{gdjs.evtTools.runtimeScene.replaceScene(runtimeScene, "2", false);
}
}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.runtimeScene.sceneJustBegins(runtimeScene);
if (isConditionTrue_0) {
{gdjs.evtTools.sound.playMusicOnChannel(runtimeScene, "levelshironew.mp3", 2, true, 100, 1);
}
}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.runtimeScene.sceneJustBegins(runtimeScene);
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("NewSprite10"), gdjs._49Code.GDNewSprite10Objects1);
{for(var i = 0, len = gdjs._49Code.GDNewSprite10Objects1.length ;i < len;++i) {
    gdjs._49Code.GDNewSprite10Objects1[i].hide();
}
}
}

}


{


let isConditionTrue_0 = false;
{
}

}


{

gdjs.copyArray(runtimeScene.getObjects("Player"), gdjs._49Code.GDPlayerObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs._49Code.GDPlayerObjects1.length;i<l;++i) {
    if ( gdjs._49Code.GDPlayerObjects1[i].getBehavior("PlatformerObject").isJumping() ) {
        isConditionTrue_0 = true;
        gdjs._49Code.GDPlayerObjects1[k] = gdjs._49Code.GDPlayerObjects1[i];
        ++k;
    }
}
gdjs._49Code.GDPlayerObjects1.length = k;
if (isConditionTrue_0) {
/* Reuse gdjs._49Code.GDPlayerObjects1 */
{for(var i = 0, len = gdjs._49Code.GDPlayerObjects1.length ;i < len;++i) {
    gdjs._49Code.GDPlayerObjects1[i].getBehavior("Animation").setAnimationName("Jumping jacks");
}
}
}

}


{

gdjs.copyArray(runtimeScene.getObjects("Player"), gdjs._49Code.GDPlayerObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs._49Code.GDPlayerObjects1.length;i<l;++i) {
    if ( gdjs._49Code.GDPlayerObjects1[i].getBehavior("PlatformerObject").isFalling() ) {
        isConditionTrue_0 = true;
        gdjs._49Code.GDPlayerObjects1[k] = gdjs._49Code.GDPlayerObjects1[i];
        ++k;
    }
}
gdjs._49Code.GDPlayerObjects1.length = k;
if (isConditionTrue_0) {
/* Reuse gdjs._49Code.GDPlayerObjects1 */
{for(var i = 0, len = gdjs._49Code.GDPlayerObjects1.length ;i < len;++i) {
    gdjs._49Code.GDPlayerObjects1[i].getBehavior("Animation").setAnimationName("Fall");
}
}
}

}


{


let isConditionTrue_0 = false;
{
}

}


{

gdjs.copyArray(runtimeScene.getObjects("Pause"), gdjs._49Code.GDPauseObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs._49Code.GDPauseObjects1.length;i<l;++i) {
    if ( gdjs._49Code.GDPauseObjects1[i].getBehavior("ButtonFSM").IsPressed(null) ) {
        isConditionTrue_0 = true;
        gdjs._49Code.GDPauseObjects1[k] = gdjs._49Code.GDPauseObjects1[i];
        ++k;
    }
}
gdjs._49Code.GDPauseObjects1.length = k;
if (isConditionTrue_0) {
{gdjs.evtTools.runtimeScene.replaceScene(runtimeScene, "Settings", false);
}
}

}


{

gdjs.copyArray(runtimeScene.getObjects("NewSprite4"), gdjs._49Code.GDNewSprite4Objects1);
gdjs.copyArray(runtimeScene.getObjects("Player"), gdjs._49Code.GDPlayerObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs._49Code.mapOfGDgdjs_9546_959549Code_9546GDPlayerObjects1Objects, gdjs._49Code.mapOfGDgdjs_9546_959549Code_9546GDNewSprite4Objects1Objects, false, runtimeScene, false);
if (isConditionTrue_0) {
/* Reuse gdjs._49Code.GDNewSprite4Objects1 */
{for(var i = 0, len = gdjs._49Code.GDNewSprite4Objects1.length ;i < len;++i) {
    gdjs._49Code.GDNewSprite4Objects1[i].getBehavior("Animation").setAnimationName("cool");
}
}
}

}


{


let isConditionTrue_0 = false;
{
}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtsExt__Gamepads__C_Axis_pushed.func(runtimeScene, 1, "Left", "Any", null);
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("Jump"), gdjs._49Code.GDJumpObjects1);
gdjs.copyArray(runtimeScene.getObjects("ShadedDarkJoystick"), gdjs._49Code.GDShadedDarkJoystickObjects1);
{for(var i = 0, len = gdjs._49Code.GDShadedDarkJoystickObjects1.length ;i < len;++i) {
    gdjs._49Code.GDShadedDarkJoystickObjects1[i].deleteFromScene(runtimeScene);
}
}
{for(var i = 0, len = gdjs._49Code.GDJumpObjects1.length ;i < len;++i) {
    gdjs._49Code.GDJumpObjects1[i].deleteFromScene(runtimeScene);
}
}
}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.anyKeyPressed(runtimeScene);
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("Jump"), gdjs._49Code.GDJumpObjects1);
gdjs.copyArray(runtimeScene.getObjects("ShadedDarkJoystick"), gdjs._49Code.GDShadedDarkJoystickObjects1);
{for(var i = 0, len = gdjs._49Code.GDShadedDarkJoystickObjects1.length ;i < len;++i) {
    gdjs._49Code.GDShadedDarkJoystickObjects1[i].deleteFromScene(runtimeScene);
}
}
{for(var i = 0, len = gdjs._49Code.GDJumpObjects1.length ;i < len;++i) {
    gdjs._49Code.GDJumpObjects1[i].deleteFromScene(runtimeScene);
}
}
}

}


{

gdjs.copyArray(runtimeScene.getObjects("Player"), gdjs._49Code.GDPlayerObjects1);
gdjs.copyArray(runtimeScene.getObjects("spike"), gdjs._49Code.GDspikeObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.platform.isOnPlatform(gdjs._49Code.mapOfGDgdjs_9546_959549Code_9546GDPlayerObjects1Objects, "PlatformerObject", gdjs._49Code.mapOfGDgdjs_9546_959549Code_9546GDspikeObjects1Objects, false);
if (isConditionTrue_0) {
/* Reuse gdjs._49Code.GDPlayerObjects1 */
{for(var i = 0, len = gdjs._49Code.GDPlayerObjects1.length ;i < len;++i) {
    gdjs._49Code.GDPlayerObjects1[i].getBehavior("LinearMovement").SetSpeedY(-200, null);
}
}
}

}


{

gdjs.copyArray(runtimeScene.getObjects("Player"), gdjs._49Code.GDPlayerObjects1);
gdjs.copyArray(runtimeScene.getObjects("spike"), gdjs._49Code.GDspikeObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.platform.isOnPlatform(gdjs._49Code.mapOfGDgdjs_9546_959549Code_9546GDPlayerObjects1Objects, "PlatformerObject", gdjs._49Code.mapOfGDgdjs_9546_959549Code_9546GDspikeObjects1Objects, false);
if (isConditionTrue_0) {
/* Reuse gdjs._49Code.GDPlayerObjects1 */
{for(var i = 0, len = gdjs._49Code.GDPlayerObjects1.length ;i < len;++i) {
    gdjs._49Code.GDPlayerObjects1[i].getBehavior("LinearMovement").SetSpeedX(-100, null);
}
}
}

}


{

gdjs.copyArray(runtimeScene.getObjects("Platform_Ground"), gdjs._49Code.GDPlatform_9595GroundObjects1);
gdjs.copyArray(runtimeScene.getObjects("Player"), gdjs._49Code.GDPlayerObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.platform.isOnPlatform(gdjs._49Code.mapOfGDgdjs_9546_959549Code_9546GDPlayerObjects1Objects, "PlatformerObject", gdjs._49Code.mapOfGDgdjs_9546_959549Code_9546GDPlatform_95959595GroundObjects1Objects, false);
if (isConditionTrue_0) {
/* Reuse gdjs._49Code.GDPlayerObjects1 */
{for(var i = 0, len = gdjs._49Code.GDPlayerObjects1.length ;i < len;++i) {
    gdjs._49Code.GDPlayerObjects1[i].getBehavior("LinearMovement").SetSpeedX(0, null);
}
}
}

}


{


let isConditionTrue_0 = false;
{
}

}


{

gdjs.copyArray(runtimeScene.getObjects("Platform_Ground"), gdjs._49Code.GDPlatform_9595GroundObjects1);
gdjs.copyArray(runtimeScene.getObjects("Player"), gdjs._49Code.GDPlayerObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.platform.isOnPlatform(gdjs._49Code.mapOfGDgdjs_9546_959549Code_9546GDPlayerObjects1Objects, "PlatformerObject", gdjs._49Code.mapOfGDgdjs_9546_959549Code_9546GDPlatform_95959595GroundObjects1Objects, false);
if (isConditionTrue_0) {
/* Reuse gdjs._49Code.GDPlayerObjects1 */
{for(var i = 0, len = gdjs._49Code.GDPlayerObjects1.length ;i < len;++i) {
    gdjs._49Code.GDPlayerObjects1[i].getBehavior("LinearMovement").SetSpeedY(0, null);
}
}
}

}


{

gdjs.copyArray(runtimeScene.getObjects("Player"), gdjs._49Code.GDPlayerObjects1);
gdjs.copyArray(runtimeScene.getObjects("spike"), gdjs._49Code.GDspikeObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs._49Code.mapOfGDgdjs_9546_959549Code_9546GDPlayerObjects1Objects, gdjs._49Code.mapOfGDgdjs_9546_959549Code_9546GDspikeObjects1Objects, false, runtimeScene, false);
if (isConditionTrue_0) {
/* Reuse gdjs._49Code.GDPlayerObjects1 */
{for(var i = 0, len = gdjs._49Code.GDPlayerObjects1.length ;i < len;++i) {
    gdjs._49Code.GDPlayerObjects1[i].getBehavior("Animation").setAnimationName("Die");
}
}
}

}


{


let isConditionTrue_0 = false;
{
}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.runtimeScene.sceneJustBegins(runtimeScene);
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("Loadanim"), gdjs._49Code.GDLoadanimObjects1);
{for(var i = 0, len = gdjs._49Code.GDLoadanimObjects1.length ;i < len;++i) {
    gdjs._49Code.GDLoadanimObjects1[i].hide();
}
}
}

}


{

gdjs.copyArray(runtimeScene.getObjects("NewSprite14"), gdjs._49Code.GDNewSprite14Objects1);
gdjs.copyArray(runtimeScene.getObjects("Player"), gdjs._49Code.GDPlayerObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs._49Code.mapOfGDgdjs_9546_959549Code_9546GDPlayerObjects1Objects, gdjs._49Code.mapOfGDgdjs_9546_959549Code_9546GDNewSprite14Objects1Objects, false, runtimeScene, false);
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("Loadanim"), gdjs._49Code.GDLoadanimObjects1);
{for(var i = 0, len = gdjs._49Code.GDLoadanimObjects1.length ;i < len;++i) {
    gdjs._49Code.GDLoadanimObjects1[i].hide(false);
}
}
}

}


{

gdjs.copyArray(runtimeScene.getObjects("NewSprite15"), gdjs._49Code.GDNewSprite15Objects1);
gdjs.copyArray(runtimeScene.getObjects("Player"), gdjs._49Code.GDPlayerObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs._49Code.mapOfGDgdjs_9546_959549Code_9546GDPlayerObjects1Objects, gdjs._49Code.mapOfGDgdjs_9546_959549Code_9546GDNewSprite15Objects1Objects, false, runtimeScene, false);
if (isConditionTrue_0) {
{gdjs.evtTools.runtimeScene.replaceScene(runtimeScene, "1", false);
}
}

}


{


let isConditionTrue_0 = false;
{
}

}


{

gdjs.copyArray(runtimeScene.getObjects("Player"), gdjs._49Code.GDPlayerObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs._49Code.GDPlayerObjects1.length;i<l;++i) {
    if ( gdjs._49Code.GDPlayerObjects1[i].getAnimationFrame() == 1 ) {
        isConditionTrue_0 = true;
        gdjs._49Code.GDPlayerObjects1[k] = gdjs._49Code.GDPlayerObjects1[i];
        ++k;
    }
}
gdjs._49Code.GDPlayerObjects1.length = k;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs._49Code.GDPlayerObjects1.length;i<l;++i) {
    if ( gdjs._49Code.GDPlayerObjects1[i].getBehavior("Animation").getAnimationName() == "Jumping jacks" ) {
        isConditionTrue_0 = true;
        gdjs._49Code.GDPlayerObjects1[k] = gdjs._49Code.GDPlayerObjects1[i];
        ++k;
    }
}
gdjs._49Code.GDPlayerObjects1.length = k;
}
if (isConditionTrue_0) {
{gdjs.evtTools.sound.playSoundOnChannel(runtimeScene, "Jumbin.wav", 11, false, 100, 1);
}
}

}


{


let isConditionTrue_0 = false;
{
}

}


{

gdjs.copyArray(runtimeScene.getObjects("Player"), gdjs._49Code.GDPlayerObjects1);
gdjs.copyArray(runtimeScene.getObjects("spike"), gdjs._49Code.GDspikeObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs._49Code.mapOfGDgdjs_9546_959549Code_9546GDPlayerObjects1Objects, gdjs._49Code.mapOfGDgdjs_9546_959549Code_9546GDspikeObjects1Objects, false, runtimeScene, false);
if (isConditionTrue_0) {
/* Reuse gdjs._49Code.GDPlayerObjects1 */
{for(var i = 0, len = gdjs._49Code.GDPlayerObjects1.length ;i < len;++i) {
    gdjs._49Code.GDPlayerObjects1[i].getBehavior("SmoothCamera").SetUpwardSpeed(0, null);
}
}
{for(var i = 0, len = gdjs._49Code.GDPlayerObjects1.length ;i < len;++i) {
    gdjs._49Code.GDPlayerObjects1[i].getBehavior("SmoothCamera").SetLeftwardSpeed(0, null);
}
}
{for(var i = 0, len = gdjs._49Code.GDPlayerObjects1.length ;i < len;++i) {
    gdjs._49Code.GDPlayerObjects1[i].getBehavior("SmoothCamera").SetDownwardSpeedMax(0, null);
}
}
}

}


{

gdjs.copyArray(runtimeScene.getObjects("Player"), gdjs._49Code.GDPlayerObjects1);
gdjs.copyArray(runtimeScene.getObjects("spike"), gdjs._49Code.GDspikeObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs._49Code.mapOfGDgdjs_9546_959549Code_9546GDPlayerObjects1Objects, gdjs._49Code.mapOfGDgdjs_9546_959549Code_9546GDspikeObjects1Objects, false, runtimeScene, false);
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("NewSprite7"), gdjs._49Code.GDNewSprite7Objects1);
gdjs.copyArray(runtimeScene.getObjects("Platform_Ground"), gdjs._49Code.GDPlatform_9595GroundObjects1);
{for(var i = 0, len = gdjs._49Code.GDPlatform_9595GroundObjects1.length ;i < len;++i) {
    gdjs._49Code.GDPlatform_9595GroundObjects1[i].activateBehavior("Platform", false);
}
}
{for(var i = 0, len = gdjs._49Code.GDNewSprite7Objects1.length ;i < len;++i) {
    gdjs._49Code.GDNewSprite7Objects1[i].activateBehavior("Platform", false);
}
}
}

}


{

gdjs.copyArray(runtimeScene.getObjects("Death"), gdjs._49Code.GDDeathObjects1);
gdjs.copyArray(runtimeScene.getObjects("Player"), gdjs._49Code.GDPlayerObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs._49Code.mapOfGDgdjs_9546_959549Code_9546GDPlayerObjects1Objects, gdjs._49Code.mapOfGDgdjs_9546_959549Code_9546GDDeathObjects1Objects, false, runtimeScene, false);
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("NewSprite10"), gdjs._49Code.GDNewSprite10Objects1);
{for(var i = 0, len = gdjs._49Code.GDNewSprite10Objects1.length ;i < len;++i) {
    gdjs._49Code.GDNewSprite10Objects1[i].hide(false);
}
}
}

}


{

gdjs.copyArray(runtimeScene.getObjects("Player"), gdjs._49Code.GDPlayerObjects1);
gdjs.copyArray(runtimeScene.getObjects("menublock"), gdjs._49Code.GDmenublockObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs._49Code.mapOfGDgdjs_9546_959549Code_9546GDPlayerObjects1Objects, gdjs._49Code.mapOfGDgdjs_9546_959549Code_9546GDmenublockObjects1Objects, false, runtimeScene, false);
if (isConditionTrue_0) {
{gdjs.evtTools.runtimeScene.replaceScene(runtimeScene, "1", false);
}
}

}


{

gdjs.copyArray(runtimeScene.getObjects("NewSprite10"), gdjs._49Code.GDNewSprite10Objects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs._49Code.GDNewSprite10Objects1.length;i<l;++i) {
    if ( gdjs._49Code.GDNewSprite10Objects1[i].isVisible() ) {
        isConditionTrue_0 = true;
        gdjs._49Code.GDNewSprite10Objects1[k] = gdjs._49Code.GDNewSprite10Objects1[i];
        ++k;
    }
}
gdjs._49Code.GDNewSprite10Objects1.length = k;
if (isConditionTrue_0) {
{gdjs.evtTools.sound.playSoundOnChannel(runtimeScene, "oof.mp3", 16, false, 50, 1);
}
}

}


{

gdjs.copyArray(runtimeScene.getObjects("Death"), gdjs._49Code.GDDeathObjects1);
gdjs.copyArray(runtimeScene.getObjects("Player"), gdjs._49Code.GDPlayerObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs._49Code.mapOfGDgdjs_9546_959549Code_9546GDPlayerObjects1Objects, gdjs._49Code.mapOfGDgdjs_9546_959549Code_9546GDDeathObjects1Objects, false, runtimeScene, false);
if (isConditionTrue_0) {
/* Reuse gdjs._49Code.GDPlayerObjects1 */
{for(var i = 0, len = gdjs._49Code.GDPlayerObjects1.length ;i < len;++i) {
    gdjs._49Code.GDPlayerObjects1[i].getBehavior("Animation").setAnimationName("Die");
}
}
{for(var i = 0, len = gdjs._49Code.GDPlayerObjects1.length ;i < len;++i) {
    gdjs._49Code.GDPlayerObjects1[i].getBehavior("Animation").pauseAnimation();
}
}
}

}


{

gdjs.copyArray(runtimeScene.getObjects("Death"), gdjs._49Code.GDDeathObjects1);
gdjs.copyArray(runtimeScene.getObjects("Player"), gdjs._49Code.GDPlayerObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs._49Code.mapOfGDgdjs_9546_959549Code_9546GDPlayerObjects1Objects, gdjs._49Code.mapOfGDgdjs_9546_959549Code_9546GDDeathObjects1Objects, false, runtimeScene, false);
if (isConditionTrue_0) {
{gdjs.evtTools.sound.stopMusicOnChannel(runtimeScene, 2);
}
}

}


{

gdjs.copyArray(runtimeScene.getObjects("Player"), gdjs._49Code.GDPlayerObjects1);
gdjs.copyArray(runtimeScene.getObjects("spike"), gdjs._49Code.GDspikeObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs._49Code.mapOfGDgdjs_9546_959549Code_9546GDPlayerObjects1Objects, gdjs._49Code.mapOfGDgdjs_9546_959549Code_9546GDspikeObjects1Objects, false, runtimeScene, false);
if (isConditionTrue_0) {
/* Reuse gdjs._49Code.GDPlayerObjects1 */
{for(var i = 0, len = gdjs._49Code.GDPlayerObjects1.length ;i < len;++i) {
    gdjs._49Code.GDPlayerObjects1[i].getBehavior("PlatformerObject").ignoreDefaultControls(true);
}
}
}

}


};

gdjs._49Code.func = function(runtimeScene) {
runtimeScene.getOnceTriggers().startNewFrame();

gdjs._49Code.GDPlayerObjects1.length = 0;
gdjs._49Code.GDPlayerObjects2.length = 0;
gdjs._49Code.GDCoinsObjects1.length = 0;
gdjs._49Code.GDCoinsObjects2.length = 0;
gdjs._49Code.GDPlatform_9595GroundObjects1.length = 0;
gdjs._49Code.GDPlatform_9595GroundObjects2.length = 0;
gdjs._49Code.GDNewSprite4Objects1.length = 0;
gdjs._49Code.GDNewSprite4Objects2.length = 0;
gdjs._49Code.GDNewSprite5Objects1.length = 0;
gdjs._49Code.GDNewSprite5Objects2.length = 0;
gdjs._49Code.GDNewSprite6Objects1.length = 0;
gdjs._49Code.GDNewSprite6Objects2.length = 0;
gdjs._49Code.GDspikeObjects1.length = 0;
gdjs._49Code.GDspikeObjects2.length = 0;
gdjs._49Code.GDNewSprite7Objects1.length = 0;
gdjs._49Code.GDNewSprite7Objects2.length = 0;
gdjs._49Code.GDNewSprite8Objects1.length = 0;
gdjs._49Code.GDNewSprite8Objects2.length = 0;
gdjs._49Code.GDNewSprite3Objects1.length = 0;
gdjs._49Code.GDNewSprite3Objects2.length = 0;
gdjs._49Code.GDpipeObjects1.length = 0;
gdjs._49Code.GDpipeObjects2.length = 0;
gdjs._49Code.GDStacyObjects1.length = 0;
gdjs._49Code.GDStacyObjects2.length = 0;
gdjs._49Code.GDShadedDarkJoystickObjects1.length = 0;
gdjs._49Code.GDShadedDarkJoystickObjects2.length = 0;
gdjs._49Code.GDNewSpriteObjects1.length = 0;
gdjs._49Code.GDNewSpriteObjects2.length = 0;
gdjs._49Code.GDNewSprite9Objects1.length = 0;
gdjs._49Code.GDNewSprite9Objects2.length = 0;
gdjs._49Code.GDMountain_9595dewObjects1.length = 0;
gdjs._49Code.GDMountain_9595dewObjects2.length = 0;
gdjs._49Code.GDNewSprite10Objects1.length = 0;
gdjs._49Code.GDNewSprite10Objects2.length = 0;
gdjs._49Code.GDJumpObjects1.length = 0;
gdjs._49Code.GDJumpObjects2.length = 0;
gdjs._49Code.GDTreeObjects1.length = 0;
gdjs._49Code.GDTreeObjects2.length = 0;
gdjs._49Code.GDPauseObjects1.length = 0;
gdjs._49Code.GDPauseObjects2.length = 0;
gdjs._49Code.GDNewTextObjects1.length = 0;
gdjs._49Code.GDNewTextObjects2.length = 0;
gdjs._49Code.GDNewSprite2Objects1.length = 0;
gdjs._49Code.GDNewSprite2Objects2.length = 0;
gdjs._49Code.GDNewSprite11Objects1.length = 0;
gdjs._49Code.GDNewSprite11Objects2.length = 0;
gdjs._49Code.GDNewSprite12Objects1.length = 0;
gdjs._49Code.GDNewSprite12Objects2.length = 0;
gdjs._49Code.GDNewSprite13Objects1.length = 0;
gdjs._49Code.GDNewSprite13Objects2.length = 0;
gdjs._49Code.GDspikenotvisiObjects1.length = 0;
gdjs._49Code.GDspikenotvisiObjects2.length = 0;
gdjs._49Code.GDBoomObjects1.length = 0;
gdjs._49Code.GDBoomObjects2.length = 0;
gdjs._49Code.GDNew3DBoxObjects1.length = 0;
gdjs._49Code.GDNew3DBoxObjects2.length = 0;
gdjs._49Code.GDLoadanimObjects1.length = 0;
gdjs._49Code.GDLoadanimObjects2.length = 0;
gdjs._49Code.GDNewSprite14Objects1.length = 0;
gdjs._49Code.GDNewSprite14Objects2.length = 0;
gdjs._49Code.GDBushesObjects1.length = 0;
gdjs._49Code.GDBushesObjects2.length = 0;
gdjs._49Code.GDNewSprite15Objects1.length = 0;
gdjs._49Code.GDNewSprite15Objects2.length = 0;
gdjs._49Code.GDSurpsObjects1.length = 0;
gdjs._49Code.GDSurpsObjects2.length = 0;
gdjs._49Code.GDNewSprite16Objects1.length = 0;
gdjs._49Code.GDNewSprite16Objects2.length = 0;
gdjs._49Code.GDDeathObjects1.length = 0;
gdjs._49Code.GDDeathObjects2.length = 0;
gdjs._49Code.GDmenublockObjects1.length = 0;
gdjs._49Code.GDmenublockObjects2.length = 0;

gdjs._49Code.eventsList0(runtimeScene);
gdjs._49Code.GDPlayerObjects1.length = 0;
gdjs._49Code.GDPlayerObjects2.length = 0;
gdjs._49Code.GDCoinsObjects1.length = 0;
gdjs._49Code.GDCoinsObjects2.length = 0;
gdjs._49Code.GDPlatform_9595GroundObjects1.length = 0;
gdjs._49Code.GDPlatform_9595GroundObjects2.length = 0;
gdjs._49Code.GDNewSprite4Objects1.length = 0;
gdjs._49Code.GDNewSprite4Objects2.length = 0;
gdjs._49Code.GDNewSprite5Objects1.length = 0;
gdjs._49Code.GDNewSprite5Objects2.length = 0;
gdjs._49Code.GDNewSprite6Objects1.length = 0;
gdjs._49Code.GDNewSprite6Objects2.length = 0;
gdjs._49Code.GDspikeObjects1.length = 0;
gdjs._49Code.GDspikeObjects2.length = 0;
gdjs._49Code.GDNewSprite7Objects1.length = 0;
gdjs._49Code.GDNewSprite7Objects2.length = 0;
gdjs._49Code.GDNewSprite8Objects1.length = 0;
gdjs._49Code.GDNewSprite8Objects2.length = 0;
gdjs._49Code.GDNewSprite3Objects1.length = 0;
gdjs._49Code.GDNewSprite3Objects2.length = 0;
gdjs._49Code.GDpipeObjects1.length = 0;
gdjs._49Code.GDpipeObjects2.length = 0;
gdjs._49Code.GDStacyObjects1.length = 0;
gdjs._49Code.GDStacyObjects2.length = 0;
gdjs._49Code.GDShadedDarkJoystickObjects1.length = 0;
gdjs._49Code.GDShadedDarkJoystickObjects2.length = 0;
gdjs._49Code.GDNewSpriteObjects1.length = 0;
gdjs._49Code.GDNewSpriteObjects2.length = 0;
gdjs._49Code.GDNewSprite9Objects1.length = 0;
gdjs._49Code.GDNewSprite9Objects2.length = 0;
gdjs._49Code.GDMountain_9595dewObjects1.length = 0;
gdjs._49Code.GDMountain_9595dewObjects2.length = 0;
gdjs._49Code.GDNewSprite10Objects1.length = 0;
gdjs._49Code.GDNewSprite10Objects2.length = 0;
gdjs._49Code.GDJumpObjects1.length = 0;
gdjs._49Code.GDJumpObjects2.length = 0;
gdjs._49Code.GDTreeObjects1.length = 0;
gdjs._49Code.GDTreeObjects2.length = 0;
gdjs._49Code.GDPauseObjects1.length = 0;
gdjs._49Code.GDPauseObjects2.length = 0;
gdjs._49Code.GDNewTextObjects1.length = 0;
gdjs._49Code.GDNewTextObjects2.length = 0;
gdjs._49Code.GDNewSprite2Objects1.length = 0;
gdjs._49Code.GDNewSprite2Objects2.length = 0;
gdjs._49Code.GDNewSprite11Objects1.length = 0;
gdjs._49Code.GDNewSprite11Objects2.length = 0;
gdjs._49Code.GDNewSprite12Objects1.length = 0;
gdjs._49Code.GDNewSprite12Objects2.length = 0;
gdjs._49Code.GDNewSprite13Objects1.length = 0;
gdjs._49Code.GDNewSprite13Objects2.length = 0;
gdjs._49Code.GDspikenotvisiObjects1.length = 0;
gdjs._49Code.GDspikenotvisiObjects2.length = 0;
gdjs._49Code.GDBoomObjects1.length = 0;
gdjs._49Code.GDBoomObjects2.length = 0;
gdjs._49Code.GDNew3DBoxObjects1.length = 0;
gdjs._49Code.GDNew3DBoxObjects2.length = 0;
gdjs._49Code.GDLoadanimObjects1.length = 0;
gdjs._49Code.GDLoadanimObjects2.length = 0;
gdjs._49Code.GDNewSprite14Objects1.length = 0;
gdjs._49Code.GDNewSprite14Objects2.length = 0;
gdjs._49Code.GDBushesObjects1.length = 0;
gdjs._49Code.GDBushesObjects2.length = 0;
gdjs._49Code.GDNewSprite15Objects1.length = 0;
gdjs._49Code.GDNewSprite15Objects2.length = 0;
gdjs._49Code.GDSurpsObjects1.length = 0;
gdjs._49Code.GDSurpsObjects2.length = 0;
gdjs._49Code.GDNewSprite16Objects1.length = 0;
gdjs._49Code.GDNewSprite16Objects2.length = 0;
gdjs._49Code.GDDeathObjects1.length = 0;
gdjs._49Code.GDDeathObjects2.length = 0;
gdjs._49Code.GDmenublockObjects1.length = 0;
gdjs._49Code.GDmenublockObjects2.length = 0;


return;

}

gdjs['_49Code'] = gdjs._49Code;
