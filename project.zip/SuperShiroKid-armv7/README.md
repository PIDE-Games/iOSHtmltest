# Super Shiro Kid – armv7 + arm64 build (iOS 9+)

A thin WKWebView wrapper around the game's `www/` folder, built as a 32-bit + 64-bit
binary with a deployment target of iOS 9.0.

## Important
- **GitHub-hosted runners cannot build armv7 / iOS 9.** They only have Xcode 16+.
  Xcode 13.x (or older) is required. The workflow therefore uses `runs-on: [self-hosted, macOS]`,
  i.e. a Mac of yours with Xcode 13.4.1 installed and registered as a runner
  (Repo → Settings → Actions → Runners → New self-hosted runner).
- The IPA is **unsigned**. Sign it afterwards with Sideloadly / AltStore / zsign.
- You can also build locally:
  ```
  brew install xcodegen && xcodegen generate
  xcodebuild -project SuperShiroKid.xcodeproj -scheme SuperShiroKid -configuration Release -sdk iphoneos CODE_SIGNING_ALLOWED=NO build
  ```

## Run
Actions tab → "Build IPA (armv7 + arm64)" → Run workflow → download the artifact.
