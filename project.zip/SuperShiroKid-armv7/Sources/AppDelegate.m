#import "AppDelegate.h"
#import <WebKit/WebKit.h>

#pragma clang diagnostic ignored "-Wdeprecated-declarations"

@interface GameViewController : UIViewController
@property (strong, nonatomic) WKWebView *web;
@end

@implementation GameViewController

- (void)loadView {
    WKWebViewConfiguration *cfg = [[WKWebViewConfiguration alloc] init];
    cfg.allowsInlineMediaPlayback = YES;
    cfg.mediaPlaybackRequiresUserAction = NO;

    // Needed so the game's local XHR/fetch of www/ assets works from file://
    @try {
        [cfg.preferences setValue:@YES forKey:@"allowFileAccessFromFileURLs"];
        [cfg setValue:@YES forKey:@"allowUniversalAccessFromFileURLs"];
    } @catch (NSException *e) {}

    self.web = [[WKWebView alloc] initWithFrame:CGRectZero configuration:cfg];
    self.web.scrollView.scrollEnabled = NO;
    self.web.scrollView.bounces = NO;
    self.web.opaque = NO;
    self.web.backgroundColor = [UIColor blackColor];
    self.web.scrollView.backgroundColor = [UIColor blackColor];
    self.view = self.web;
}

- (void)viewDidLoad {
    [super viewDidLoad];
    NSURL *www = [[NSBundle mainBundle] URLForResource:@"www" withExtension:nil];
    NSURL *index = [www URLByAppendingPathComponent:@"index.html"];
    [self.web loadFileURL:index allowingReadAccessToURL:www];
}

- (BOOL)prefersStatusBarHidden { return YES; }
- (UIInterfaceOrientationMask)supportedInterfaceOrientations { return UIInterfaceOrientationMaskLandscape; }
- (BOOL)shouldAutorotate { return YES; }

@end

@implementation AppDelegate

- (BOOL)application:(UIApplication *)application didFinishLaunchingWithOptions:(NSDictionary *)launchOptions {
    self.window = [[UIWindow alloc] initWithFrame:[UIScreen mainScreen].bounds];
    self.window.rootViewController = [[GameViewController alloc] init];
    self.window.backgroundColor = [UIColor blackColor];
    [self.window makeKeyAndVisible];
    return YES;
}

@end
